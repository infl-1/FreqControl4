package com.example.speedtool

import android.app.Activity
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private val dir = "/data/local/tmp"
    private lateinit var spinner: Spinner
    private lateinit var label: TextView
    private lateinit var log: TextView
    private var speed = 2.0
    private val pkgs = mutableListOf<String>()

    // ألعاب أونلاين تنحظر فيها الحسابات: الأداة ترفض تشتغل عليها
    private val blocked = listOf("callofduty", "codm", "com.tencent.ig", "com.pubg", "freefire")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.TOP
        }
        spinner = Spinner(this)
        val refresh = Button(this).apply { text = "تحديث قائمة التطبيقات الشغالة"; setOnClickListener { loadRunning() } }
        label = TextView(this).apply { textSize = 22f; text = "السرعة: x2.0" }
        val bar = SeekBar(this).apply {
            max = 78
            progress = 18
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    speed = 0.2 + p * 0.1
                    label.text = "السرعة: x%.1f".format(speed)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { writeSpeed() }
            })
        }
        val start = Button(this).apply { text = "ابدأ التسريع"; setOnClickListener { start() } }
        val stop = Button(this).apply { text = "إيقاف"; setOnClickListener { stop() } }
        log = TextView(this).apply { textSize = 12f }
        val tip = TextView(this).apply {
            textSize = 12f
            text = "ضع frida-inject (arm64) في /data/local/tmp.\nشغّل التطبيق أولاً ثم حدّثه من القائمة."
        }
        listOf(refresh, spinner, label, bar, start, stop, tip, log).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
        loadRunning()
    }

    private fun loadRunning() {
        log.text = "جاري التحميل..."
        Thread {
            try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "ps -A -o NAME"))
                val names = p.inputStream.bufferedReader().readLines()
                    .map { it.trim().substringBefore(':') }.toSet()
                p.waitFor()
                val pm = packageManager
                val apps = pm.getInstalledApplications(0)
                    .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
                    .filter { it.packageName != packageName && it.packageName in names }
                    .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
                runOnUiThread {
                    pkgs.clear()
                    pkgs.addAll(apps.map { it.packageName })
                    val items = apps.map { "${pm.getApplicationLabel(it)}  (${it.packageName})" }
                    spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
                    log.text = if (items.isEmpty()) "ما لقيت تطبيقات شغالة (تأكد من الروت)" else "تم: ${items.size} تطبيق"
                }
            } catch (e: Exception) {
                runOnUiThread { log.text = "فشل: ${e.message}" }
            }
        }.start()
    }

    private fun su(cmd: String, show: Boolean = true) = Thread {
        try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val out = p.inputStream.bufferedReader().readText() +
                      p.errorStream.bufferedReader().readText()
            p.waitFor()
            if (show) runOnUiThread { log.text = out.ifBlank { "تم" } }
        } catch (e: Exception) {
            runOnUiThread { log.text = "فشل: لا يوجد روت؟ ${e.message}" }
        }
    }.start()

    private fun writeSpeed() =
        su("echo %.2f > $dir/speed.txt; chmod 644 $dir/speed.txt".format(speed), false)

    private fun start() {
        val i = spinner.selectedItemPosition
        if (i < 0 || i >= pkgs.size) { log.text = "اختر تطبيقًا من القائمة"; return }
        val name = pkgs[i]
        if (blocked.any { name.contains(it, ignoreCase = true) }) {
            log.text = "هذا تطبيق أونلاين وفيه حظر للحسابات، الأداة ترفض تشتغل عليه."
            return
        }
        val tmp = File(filesDir, "speed.js")
        assets.open("speed.js").use { inp -> tmp.outputStream().use { o -> inp.copyTo(o) } }
        su(
            "pkill -f frida-inject; " +
            "cp ${tmp.absolutePath} $dir/speed.js; chmod 644 $dir/speed.js; " +
            "echo %.2f > $dir/speed.txt; chmod 644 $dir/speed.txt; " +
            "chmod 755 $dir/frida-inject; " +
            "nohup $dir/frida-inject -n $name -s $dir/speed.js > $dir/frida.log 2>&1 & " +
            "sleep 2; cat $dir/frida.log".format(speed)
        )
    }

    private fun stop() = su("pkill -f frida-inject; echo 1.0 > $dir/speed.txt")
}
