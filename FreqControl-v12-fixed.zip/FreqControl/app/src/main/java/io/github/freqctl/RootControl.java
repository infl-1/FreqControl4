package io.github.freqctl;

import android.content.ContentResolver;
import android.content.Context;
import android.provider.Settings;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Installs and talks to the root helper script (assets/freqctl.sh). The script controls the CPU
 * clusters through cpufreq sysfs and runs the thermal guard. It keeps running without the app and is
 * started again at boot from /data/adb/service.d (Magisk, KernelSU, APatch).
 *
 * <p>The app never edits the script's state directly: it writes a small config file and signals the script,
 * which re-reads it at once.
 */
public final class RootControl {
    private static final String DIR = "/data/adb/freqctl";
    private static final String SERVICE_D = "/data/adb/service.d";
    static final String SCRIPT = DIR + "/freqctl.sh";
    private static final long TIMEOUT_MS = 30_000L;

    private RootControl() {
    }

    /** Blocking. Installs the script, writes the config and (re)starts the helper. */
    public static boolean install(Context context) {
        try {
            File script = copyAsset(context, "freqctl.sh");
            File config = writeConfig(context);
            String launcher = "#!/system/bin/sh\\nsh " + SCRIPT + " start\\n";
            // The helper is only replaced (and restarted) when the script changed: opening the app must not
            // interrupt the guard. "start" on a running helper just tells it to re-read the config.
            String src = RootShell.quote(script.getAbsolutePath());
            String command = "mkdir -p " + DIR + " " + SERVICE_D
                    + " && cp " + RootShell.quote(config.getAbsolutePath()) + " " + DIR + "/config"
                    + " && chmod 600 " + DIR + "/config"
                    + " && { cmp -s " + src + " " + SCRIPT + " || { cp " + src + " " + SCRIPT
                    + " && chmod 755 " + SCRIPT + " && sh " + SCRIPT + " stop; }; }"
                    + " && printf '" + launcher + "' > " + SERVICE_D + "/freqctl.sh"
                    + " && chmod 755 " + SERVICE_D + "/freqctl.sh"
                    + " && sh " + SCRIPT + " start";
            return RootShell.run(command, TIMEOUT_MS).exitCode == 0;
        } catch (IOException e) {
            return false;
        }
    }

    /** Blocking. Pushes the current settings to the helper and makes sure it is running. */
    public static boolean sync(Context context) {
        try {
            File config = writeConfig(context);
            String command = "mkdir -p " + DIR
                    + " && cp " + RootShell.quote(config.getAbsolutePath()) + " " + DIR + "/config"
                    + " && chmod 600 " + DIR + "/config"
                    + " && sh " + SCRIPT + " start";
            return RootShell.run(command, TIMEOUT_MS).exitCode == 0;
        } catch (IOException e) {
            return false;
        }
    }

    /** Blocking. Reboots the phone through root. */
    public static boolean reboot() {
        return RootShell.run("sync; svc power reboot || reboot", 10_000L).exitCode == 0;
    }

    /** The helper's config: shell variable assignments, sourced by the script. */
    static String buildConfig(ContentResolver resolver) {
        StringBuilder sb = new StringBuilder();
        sb.append("GUARD_EN=").append(Settings.Global.getInt(resolver, Domain.KEY_GUARD_ENABLED, 1)).append('\n');
        sb.append("GUARD_CORE_EN=").append(Settings.Global.getInt(resolver, Domain.KEY_GUARD_CORE_EN, 1)).append('\n');
        sb.append("GUARD_CORE=").append(Settings.Global.getInt(resolver, Domain.KEY_GUARD_CORE, Domain.DEFAULT_GUARD_CORE)).append('\n');
        sb.append("GUARD_AP_EN=").append(Settings.Global.getInt(resolver, Domain.KEY_GUARD_AP_EN, 0)).append('\n');
        sb.append("GUARD_AP=").append(Settings.Global.getInt(resolver, Domain.KEY_GUARD_AP, Domain.DEFAULT_GUARD_AP)).append('\n');
        sb.append("GUARD_BATT=").append(Settings.Global.getInt(resolver, Domain.KEY_GUARD_BATT, Domain.DEFAULT_GUARD_BATT)).append('\n');
        for (Domain domain : Domain.values()) {
            if (domain.mechanism != Domain.Mechanism.ROOT_SYSFS) {
                continue;
            }
            String name = domain.shellName();
            sb.append(name).append("_EN=").append(Settings.Global.getInt(resolver, domain.keyEnabled(), 0)).append('\n');
            sb.append(name).append("_MIN=").append(Settings.Global.getInt(resolver, domain.keyMin(), 0)).append('\n');
            sb.append(name).append("_MAX=").append(Settings.Global.getInt(resolver, domain.keyMax(), 0)).append('\n');
        }
        return sb.toString();
    }

    private static File writeConfig(Context context) throws IOException {
        File file = new File(context.getCacheDir(), "freqctl.conf");
        try (OutputStream out = new FileOutputStream(file)) {
            out.write(buildConfig(context.getContentResolver()).getBytes("UTF-8"));
        }
        file.setReadable(true, false);
        return file;
    }

    private static File copyAsset(Context context, String name) throws IOException {
        File file = new File(context.getCacheDir(), name);
        try (InputStream in = context.getAssets().open(name); OutputStream out = new FileOutputStream(file)) {
            byte[] buffer = new byte[4096];
            int read;
            while ((read = in.read(buffer)) > 0) {
                out.write(buffer, 0, read);
            }
        }
        file.setReadable(true, false);
        return file;
    }
}
