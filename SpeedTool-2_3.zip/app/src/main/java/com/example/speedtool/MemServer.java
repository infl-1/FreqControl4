package com.example.speedtool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * محرك البحث وتعديل القيم في الذاكرة (كود أصلي مكتوب من الصفر).
 *
 * يشتغل بصلاحية root خارج اللعبة عبر app_process:
 *   su -c "CLASSPATH=base.apk app_process /system/bin com.example.speedtool.MemServer"
 * فما يحقن شي داخل اللعبة (أقل احتمال للكراش). يقرأ ويكتب في /proc/PID/mem.
 * الواجهة تكلمه بأسطر نصية عبر stdin / stdout، وكل أمر ينتهي بسطر واحد: "OK ..." أو "ERR ...".
 * (قد يسبقه أسطر بيانات "R ..." وأسطر تقدم "PROG n").
 *
 * الأوامر:
 *   attach PID               attachpkg PACKAGE  (يدور على العملية بالاسم ويربط؛ لو نفس العملية ما يمسح النتائج)
 *   scan TYPE MODE A B MASK     MODE: eq | rng | unk       MASK مثل A,Ca,Cb,Cd,Jh,O
 *   next MODE A B               MODE: eq ne rng chg unch inc dec incby decby
 *   list OFFSET COUNT
 *   get TYPE ADDR            getmany TYPE:ADDR TYPE:ADDR ...
 *   set TYPE ADDR VALUE      setall VALUE LIMIT
 *   freeze TYPE ADDR VALUE   unfreeze ADDR   unfreezeall
 *   info   clear   quit
 * TYPE: i8 i16 i32 i64 f32 f64
 */
public final class MemServer {
    private static final int PAGE = 4096;
    private static final int CHUNK = 1 << 20;            // نقرأ الذاكرة على دفعات 1MB
    private static final int CAP = 4_000_000;            // أقصى عدد نتائج نخزنها
    private static final long SNAP_MAX = 2L << 30;       // أقصى حجم لقطة (بحث القيمة المجهولة)
    private static final long SLOT_MAX = 400_000_000L;
    private static final String SNAP_PATH = "/data/local/tmp/stmem.snap";

    private static final int I8 = 1, I16 = 2, I32 = 3, I64 = 4, F32 = 5, F64 = 6;
    private static final int M_EQ = 1, M_NE = 2, M_RNG = 3, M_CHG = 4, M_UNCH = 5, M_INC = 6, M_DEC = 7,
            M_INCBY = 8, M_DECBY = 9, M_UNK = 10;

    private static PrintStream OUT;

    // ---------------------------------------------------------------- الحالة
    private int pid = -1;
    private FileChannel mem;
    private int type = I32;
    private int size = 4;

    // وضع القائمة: نتائج (عنوان + قيمة خام)
    private long[] addrs = new long[0];
    private long[] vals = new long[0];
    private int n = 0;

    // وضع اللقطة (بحث بقيمة مجهولة): لقطة على القرص + خريطة بتات للمرشحين
    private boolean snapMode = false;
    private FileChannel snap;
    private List<Reg> snapRegs;
    private long[] snapFileOff;
    private long[] snapSlotBase;
    private BitSet cand;
    private long snapCount = 0;

    private final Map<Long, Fz> frozen = new LinkedHashMap<Long, Fz>();
    private final byte[] buf = new byte[CHUNK];

    private static final class Fz {
        int type;
        long raw;
        int fails;
    }

    private static final class Reg {
        long start, end;
        String perms = "", path = "", tag = "O";
    }

    private static final class Op {
        long la, lb;
        double da, db;
    }

    // ---------------------------------------------------------------- الإدخال والإخراج
    private static synchronized void out(String s) {
        OUT.print(s);
        OUT.print('\n');
        OUT.flush();
        if (OUT.checkError()) System.exit(0);       // الواجهة ماتت
    }

    public static void main(String[] args) throws Exception {
        OUT = new PrintStream(new FileOutputStream(FileDescriptor.out), false, "UTF-8");
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(FileDescriptor.in), "UTF-8"));
        MemServer s = new MemServer();
        s.startFreezer();
        String line;
        while ((line = in.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;
            String[] t = line.split("\\s+");
            try {
                if (!s.dispatch(t)) break;
            } catch (Throwable e) {
                if (e instanceof OutOfMemoryError) s.resetResults();
                String m = e.getMessage();
                out("ERR " + (m == null ? e.toString() : m));
            }
        }
        s.closeAll();
        System.exit(0);
    }

    private boolean dispatch(String[] t) throws Exception {
        String c = t[0];
        switch (c) {
            case "ping": out("OK"); break;
            case "attach": cmdAttach(Integer.parseInt(arg(t, 1))); break;
            case "attachpkg": cmdAttachPkg(arg(t, 1)); break;
            case "scan": cmdScan(t); break;
            case "next": cmdNext(t); break;
            case "list": cmdList(Integer.parseInt(arg(t, 1)), Integer.parseInt(arg(t, 2))); break;
            case "get": cmdGet(t); break;
            case "getmany": cmdGetMany(t); break;
            case "set": cmdSet(t); break;
            case "setall": cmdSetAll(t); break;
            case "freeze": cmdFreeze(t); break;
            case "unfreeze": {
                synchronized (frozen) { frozen.remove(hex(arg(t, 1), 16)); }
                out("OK");
                break;
            }
            case "unfreezeall": synchronized (frozen) { frozen.clear(); } out("OK"); break;
            case "info": cmdInfo(); break;
            case "clear": resetResults(); out("OK"); break;
            case "quit": return false;
            default: out("ERR أمر غير معروف: " + c);
        }
        return true;
    }

    /** يقرأ رقم hex (بدون Long.parseUnsignedLong لأنها تحتاج أندرويد 8+ ونحن ندعم 7). */
    private static long hex(String s, int radix) {
        return new java.math.BigInteger(s, radix).longValue();
    }

    private static String arg(String[] t, int i) {
        if (i >= t.length) throw new IllegalArgumentException("ناقص باراميتر");
        return t[i];
    }

    // ---------------------------------------------------------------- الأنواع والقيم
    private static int typeOf(String s) {
        switch (s) {
            case "i8": return I8;
            case "i16": return I16;
            case "i32": return I32;
            case "i64": return I64;
            case "f32": return F32;
            case "f64": return F64;
            default: throw new IllegalArgumentException("نوع غير معروف: " + s);
        }
    }

    private static int sizeOf(int t) {
        switch (t) {
            case I8: return 1;
            case I16: return 2;
            case I32: case F32: return 4;
            default: return 8;
        }
    }

    private static boolean isFloat(int t) { return t == F32 || t == F64; }

    private static int modeOf(String s) {
        switch (s) {
            case "eq": return M_EQ;
            case "ne": return M_NE;
            case "rng": return M_RNG;
            case "chg": return M_CHG;
            case "unch": return M_UNCH;
            case "inc": return M_INC;
            case "dec": return M_DEC;
            case "incby": return M_INCBY;
            case "decby": return M_DECBY;
            case "unk": return M_UNK;
            default: throw new IllegalArgumentException("نمط غير معروف: " + s);
        }
    }

    /** القيمة الخام (little-endian) من مصفوفة بايتات؛ الأعداد الصحيحة تمتد بالإشارة. */
    private static long rawAt(byte[] b, int p, int sz) {
        switch (sz) {
            case 1:
                return b[p];
            case 2:
                return (short) ((b[p] & 0xFF) | (b[p + 1] << 8));
            case 4:
                return (b[p] & 0xFF) | ((b[p + 1] & 0xFF) << 8) | ((b[p + 2] & 0xFF) << 16) | (b[p + 3] << 24);
            default: {
                int lo = (b[p] & 0xFF) | ((b[p + 1] & 0xFF) << 8) | ((b[p + 2] & 0xFF) << 16) | (b[p + 3] << 24);
                int hi = (b[p + 4] & 0xFF) | ((b[p + 5] & 0xFF) << 8) | ((b[p + 6] & 0xFF) << 16) | (b[p + 7] << 24);
                return (lo & 0xFFFFFFFFL) | ((long) hi << 32);
            }
        }
    }

    private static long narrow(int t, long v) {
        switch (t) {
            case I8: return (byte) v;
            case I16: return (short) v;
            case I32: return (int) v;
            default: return v;
        }
    }

    private static double decF(int t, long raw) {
        return t == F32 ? (double) Float.intBitsToFloat((int) raw) : Double.longBitsToDouble(raw);
    }

    private static String fmt(int t, long raw) {
        switch (t) {
            case F32: return Float.toString(Float.intBitsToFloat((int) raw));
            case F64: return Double.toString(Double.longBitsToDouble(raw));
            default: return Long.toString(raw);
        }
    }

    private static long parseInt(String s) {
        s = s.trim();
        boolean neg = s.startsWith("-");
        String u = neg ? s.substring(1) : s;
        long v;
        if (u.startsWith("0x") || u.startsWith("0X")) v = hex(u.substring(2), 16);
        else v = Long.parseLong(u);
        return neg ? -v : v;
    }

    private static Op parseOp(int t, String a, String b) {
        Op op = new Op();
        try {
            if (isFloat(t)) {
                op.da = Double.parseDouble(a);
                op.db = (b == null || b.equals("-")) ? op.da : Double.parseDouble(b);
                if (op.db < op.da) { double x = op.da; op.da = op.db; op.db = x; }
            } else {
                op.la = narrow(t, parseInt(a));
                op.lb = (b == null || b.equals("-")) ? op.la : narrow(t, parseInt(b));
                if (op.lb < op.la) { long x = op.la; op.la = op.lb; op.lb = x; }
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("قيمة غير صالحة لهذا النوع");
        }
        return op;
    }

    private static long rawOf(int t, Op op) {
        switch (t) {
            case F32: return Float.floatToRawIntBits((float) op.da);
            case F64: return Double.doubleToRawLongBits(op.da);
            default: return op.la;
        }
    }

    /** يطبّق شرط البحث على قيمة جديدة (وقديمة للأنماط النسبية). */
    private static boolean test(int mode, int t, long oldRaw, long newRaw, Op op) {
        if (isFloat(t)) {
            double nw = decF(t, newRaw);
            if (Double.isNaN(nw)) return false;
            double o = decF(t, oldRaw);
            switch (mode) {
                case M_EQ: return t == F32 ? (float) nw == (float) op.da : nw == op.da;
                case M_NE: return t == F32 ? (float) nw != (float) op.da : nw != op.da;
                case M_RNG: return nw >= op.da && nw <= op.db;
                case M_CHG: return newRaw != oldRaw;
                case M_UNCH: return newRaw == oldRaw;
                case M_INC: return nw > o;
                case M_DEC: return nw < o;
                case M_INCBY: return t == F32 ? (float) nw == (float) (o + op.da) : nw == o + op.da;
                case M_DECBY: return t == F32 ? (float) nw == (float) (o - op.da) : nw == o - op.da;
                default: return false;
            }
        }
        switch (mode) {
            case M_EQ: return newRaw == op.la;
            case M_NE: return newRaw != op.la;
            case M_RNG: return newRaw >= op.la && newRaw <= op.lb;
            case M_CHG: return newRaw != oldRaw;
            case M_UNCH: return newRaw == oldRaw;
            case M_INC: return newRaw > oldRaw;
            case M_DEC: return newRaw < oldRaw;
            case M_INCBY: return newRaw == narrow(t, oldRaw + op.la);
            case M_DECBY: return newRaw == narrow(t, oldRaw - op.la);
            default: return false;
        }
    }

    private static boolean needsOp(int mode) {
        return mode == M_EQ || mode == M_NE || mode == M_RNG || mode == M_INCBY || mode == M_DECBY;
    }

    // ---------------------------------------------------------------- قراءة وكتابة الذاكرة
    private void cmdAttach(int p) throws Exception {
        closeAll();
        File f = new File("/proc/" + p + "/mem");
        if (!new File("/proc/" + p).exists()) throw new IllegalStateException("العملية غير موجودة");
        try {
            mem = new RandomAccessFile(f, "rw").getChannel();
        } catch (Exception e) {
            throw new IllegalStateException("تعذر فتح ذاكرة العملية (روت؟ SELinux؟): " + e.getMessage());
        }
        pid = p;
        resetResults();
        int c = 0;
        for (Reg r : readMaps()) if (!r.tag.equals("-") && r.perms.charAt(1) == 'w') c++;
        out("OK " + c + " " + p);
    }

    /** يلقى عملية التطبيق بالاسم (cmdline) ويربطها. لو هي نفس العملية المربوطة نخلي النتائج كما هي. */
    private void cmdAttachPkg(String pkg) throws Exception {
        int found = -1;
        String[] names = new File("/proc").list();
        if (names != null) {
            for (String nm : names) {
                if (nm.isEmpty() || nm.charAt(0) < '0' || nm.charAt(0) > '9') continue;
                FileInputStream fi = null;
                try {
                    fi = new FileInputStream("/proc/" + nm + "/cmdline");
                    byte[] b = new byte[300];
                    int r = fi.read(b);
                    if (r <= 0) continue;
                    int e = 0;
                    while (e < r && b[e] != 0) e++;
                    if (new String(b, 0, e, "UTF-8").equals(pkg)) {
                        int pidv = Integer.parseInt(nm);
                        if (found < 0 || pidv < found) found = pidv;
                    }
                } catch (Exception ex) {
                    // العملية اختفت أو ما نقدر نقرأها
                } finally {
                    if (fi != null) try { fi.close(); } catch (Exception ex) { }
                }
            }
        }
        if (found < 0) throw new IllegalStateException("اللعبة غير شغّالة، افتحها أولًا");
        if (mem != null && pid == found) { out("OK same " + found); return; }
        cmdAttach(found);
    }

    private void requireMem() {
        if (mem == null) throw new IllegalStateException("لا توجد لعبة مرتبطة (attach)");
    }

    private boolean readFully(long addr, byte[] b, int off, int len) {
        try {
            ByteBuffer bb = ByteBuffer.wrap(b, off, len);
            while (bb.hasRemaining()) {
                int r = mem.read(bb, addr + (bb.position() - off));
                if (r <= 0) return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** يقرأ دفعة؛ يرجّع null لو كلها سليمة، وإلا خريطة بالصفحات السليمة. */
    private boolean[] readChunk(long addr, int len, byte[] b) {
        if (readFully(addr, b, 0, len)) return null;
        boolean[] ok = new boolean[(len + PAGE - 1) / PAGE];
        for (int p = 0; p < ok.length; p++) {
            int off = p * PAGE;
            ok[p] = readFully(addr + off, b, off, Math.min(PAGE, len - off));
        }
        return ok;
    }

    private void writeRaw(long addr, int t, long raw) throws Exception {
        int sz = sizeOf(t);
        byte[] b = new byte[sz];
        for (int i = 0; i < sz; i++) b[i] = (byte) (raw >>> (8 * i));
        ByteBuffer bb = ByteBuffer.wrap(b);
        int done = 0;
        while (bb.hasRemaining()) {
            int w = mem.write(bb, addr + done);
            if (w <= 0) throw new java.io.IOException("فشلت الكتابة");
            done += w;
        }
    }

    private long parseRaw(int t, String s) {
        Op op = parseOp(t, s, null);
        return rawOf(t, op);
    }

    // ---------------------------------------------------------------- خريطة الذاكرة
    private List<Reg> readMaps() throws Exception {
        List<Reg> list = new ArrayList<Reg>();
        java.io.BufferedReader rd = new java.io.BufferedReader(new java.io.FileReader("/proc/" + pid + "/maps"));
        try {
            String line;
            Reg prev = null;
            while ((line = rd.readLine()) != null) {
                String[] f = line.split("\\s+", 6);
                if (f.length < 2) continue;
                int d = f[0].indexOf('-');
                if (d < 0) continue;
                Reg r = new Reg();
                r.start = hex(f[0].substring(0, d), 16);
                r.end = hex(f[0].substring(d + 1), 16);
                r.perms = f[1];
                r.path = f.length >= 6 ? f[5].trim() : "";
                r.tag = classify(r, prev);
                list.add(r);
                prev = r;
            }
        } finally {
            rd.close();
        }
        return list;
    }

    /** تصنيف المناطق مثل جيم جاردن: A, Ca, Cb, Cd, Jh, O  ("-" = نتجاهلها). */
    private static String classify(Reg r, Reg prev) {
        String p = r.path;
        if (r.perms.length() < 3 || r.perms.charAt(0) != 'r') return "-";
        if (p.startsWith("/dev/") && !p.startsWith("/dev/ashmem/dalvik")) return "-";   // ذاكرة درايفرات/GPU
        if (p.startsWith("[vvar") || p.equals("[vdso]") || p.equals("[vsyscall]")) return "-";
        if (p.contains("jit-code-cache") || p.contains("data-code-cache")) return "-";
        if (p.contains("dalvik-")) return "Jh";
        if (p.equals("[heap]") || p.contains("libc_malloc") || p.contains("scudo")) return "Ca";
        if (p.contains(".bss")) return "Cb";
        if (p.isEmpty()) {
            if (prev != null && prev.end == r.start && prev.path.endsWith(".so")) return "Cb";
            return "A";
        }
        if (p.startsWith("[anon:")) return "A";
        if (p.startsWith("[stack")) return "O";
        if (p.startsWith("/") && (p.endsWith(".so") || p.contains(".so.") || p.startsWith("/data/app"))) return "Cd";
        return "O";
    }

    private List<Reg> scanRegions(Set<String> mask) throws Exception {
        List<Reg> res = new ArrayList<Reg>();
        for (Reg r : readMaps()) {
            if (r.tag.equals("-") || r.perms.charAt(1) != 'w') continue;
            if (!mask.contains(r.tag)) continue;
            res.add(r);
        }
        return res;
    }

    private String tagAt(List<Reg> all, long addr) {
        for (Reg r : all) if (addr >= r.start && addr < r.end) return r.tag.equals("-") ? "?" : r.tag;
        return "?";
    }

    // ---------------------------------------------------------------- البحث الأول
    private void resetResults() {
        n = 0;
        addrs = new long[0];
        vals = new long[0];
        leaveSnap();
    }

    private void leaveSnap() {
        snapMode = false;
        cand = null;
        snapRegs = null;
        snapCount = 0;
        try { if (snap != null) snap.close(); } catch (Exception e) { }
        snap = null;
        new File(SNAP_PATH).delete();
    }

    private void add(long a, long v) {
        if (n == addrs.length) {
            int cap = Math.min(CAP, Math.max(1 << 16, n * 2));
            addrs = java.util.Arrays.copyOf(addrs, cap);
            vals = java.util.Arrays.copyOf(vals, cap);
        }
        addrs[n] = a;
        vals[n] = v;
        n++;
    }

    private int lastPct = -1;

    private void progress(long done, long total) {
        int pct = total <= 0 ? 100 : (int) (done * 100 / total);
        if (pct != lastPct && pct % 3 == 0) {
            lastPct = pct;
            out("PROG " + pct);
        }
    }

    private void cmdScan(String[] t) throws Exception {
        requireMem();
        int ty = typeOf(arg(t, 1));
        int mode = modeOf(arg(t, 2));
        String a = arg(t, 3), b = arg(t, 4);
        Set<String> mask = new HashSet<String>(java.util.Arrays.asList(arg(t, 5).split(",")));
        if (mode != M_EQ && mode != M_RNG && mode != M_UNK) throw new IllegalArgumentException("نمط البحث الأول: eq / rng / unk");
        resetResults();
        type = ty;
        size = sizeOf(ty);
        List<Reg> regs = scanRegions(mask);
        if (regs.isEmpty()) throw new IllegalStateException("ما فيه مناطق ذاكرة مطابقة للاختيار");
        long total = 0;
        for (Reg r : regs) total += r.end - r.start;
        lastPct = -1;

        if (mode == M_UNK) {
            scanUnknown(regs, total);
            return;
        }
        Op op = parseOp(ty, a, b);
        long target = rawOf(ty, op);
        boolean trunc = false;
        long done = 0;
        outer:
        for (Reg r : regs) {
            long rlen = r.end - r.start;
            for (long off = 0; off < rlen; off += CHUNK) {
                int len = (int) Math.min(CHUNK, rlen - off);
                long base = r.start + off;
                boolean[] ok = readChunk(base, len, buf);
                for (int p = 0; p + size <= len; p += size) {
                    if (ok != null && !ok[p / PAGE]) continue;
                    long raw = rawAt(buf, p, size);
                    boolean hit = mode == M_EQ ? raw == target : test(M_RNG, ty, 0, raw, op);
                    if (hit) {
                        add(base + p, raw);
                        if (n >= CAP) { trunc = true; break outer; }
                    }
                }
                done += len;
                progress(done, total);
            }
        }
        out("OK " + n + " list" + (trunc ? " TRUNC" : ""));
    }

    private void scanUnknown(List<Reg> regs, long total) throws Exception {
        if (total > SNAP_MAX) throw new IllegalStateException("الذاكرة المختارة كبيرة (" + (total >> 20) + "MB)؛ قلّل المناطق أو استخدم قيمة محددة");
        long slots = total / size;
        if (slots > SLOT_MAX) throw new IllegalStateException("عدد الخانات كبير؛ قلّل المناطق أو اختر نوع أكبر");
        new File(SNAP_PATH).delete();
        snap = new RandomAccessFile(SNAP_PATH, "rw").getChannel();
        snapRegs = regs;
        snapFileOff = new long[regs.size()];
        snapSlotBase = new long[regs.size()];
        cand = new BitSet((int) slots);
        cand.set(0, (int) slots);
        long fo = 0, sb = 0, done = 0;
        for (int i = 0; i < regs.size(); i++) {
            Reg r = regs.get(i);
            long rlen = r.end - r.start;
            snapFileOff[i] = fo;
            snapSlotBase[i] = sb;
            for (long off = 0; off < rlen; off += CHUNK) {
                int len = (int) Math.min(CHUNK, rlen - off);
                boolean[] ok = readChunk(r.start + off, len, buf);
                ByteBuffer wb = ByteBuffer.wrap(buf, 0, len);
                long pos = fo + off;
                while (wb.hasRemaining()) pos += snap.write(wb, pos);
                if (ok != null) {
                    for (int pg = 0; pg < ok.length; pg++) {
                        if (ok[pg]) continue;
                        long s0 = sb + (off + (long) pg * PAGE) / size;
                        long s1 = sb + (off + Math.min((long) (pg + 1) * PAGE, len)) / size;
                        cand.clear((int) s0, (int) s1);
                    }
                }
                done += len;
                progress(done, total);
            }
            fo += rlen;
            sb += rlen / size;
        }
        snapMode = true;
        snapCount = cand.cardinality();
        out("OK " + snapCount + " snap");
    }

    // ---------------------------------------------------------------- البحث التالي
    private final class BlockReader {
        private final byte[] b = new byte[65536];
        private final boolean[] pageOk = new boolean[16];
        private long base = -1;
        long raw;

        boolean read(long addr, int sz) {
            if (base < 0 || addr < base || addr >= base + 65536) load(addr & ~0xFFFFL);
            int off = (int) (addr - base);
            if (!pageOk[off >> 12]) return false;
            raw = rawAt(b, off, sz);
            return true;
        }

        private void load(long nb) {
            base = nb;
            if (readFully(nb, b, 0, 65536)) {
                java.util.Arrays.fill(pageOk, true);
                return;
            }
            for (int p = 0; p < 16; p++) pageOk[p] = readFully(nb + p * PAGE, b, p * PAGE, PAGE);
        }
    }

    private void cmdNext(String[] t) throws Exception {
        requireMem();
        if (!snapMode && n == 0) throw new IllegalStateException("ما فيه نتائج؛ ابدأ بحثًا أولًا");
        int mode = modeOf(arg(t, 1));
        if (mode == M_UNK) throw new IllegalArgumentException("unk للبحث الأول فقط");
        Op op = needsOp(mode) ? parseOp(type, arg(t, 2), t.length > 3 ? t[3] : null) : null;
        lastPct = -1;
        if (snapMode) { nextSnap(mode, op); return; }

        BlockReader br = new BlockReader();
        int w = 0;
        for (int i = 0; i < n; i++) {
            if (!br.read(addrs[i], size)) continue;               // العنوان ما عاد مقروء: نحذفه
            if (test(mode, type, vals[i], br.raw, op)) {
                addrs[w] = addrs[i];
                vals[w] = br.raw;
                w++;
            }
            if ((i & 0xFFFF) == 0) progress(i, n);
        }
        n = w;
        out("OK " + n + " list");
    }

    private void nextSnap(int mode, Op op) throws Exception {
        long total = 0;
        for (Reg r : snapRegs) total += r.end - r.start;
        byte[] old = new byte[CHUNK];
        long[] na = new long[1 << 16];
        long[] nv = new long[1 << 16];
        int cnt = 0;
        boolean overflow = false;
        long done = 0;
        for (int i = 0; i < snapRegs.size(); i++) {
            Reg r = snapRegs.get(i);
            long rlen = r.end - r.start;
            for (long off = 0; off < rlen; off += CHUNK) {
                int len = (int) Math.min(CHUNK, rlen - off);
                long base = r.start + off;
                long sb = snapSlotBase[i] + off / size;
                int slots = len / size;
                int nextSet = cand.nextSetBit((int) sb);
                if (nextSet < 0 || nextSet >= sb + slots) { done += len; progress(done, total); continue; }   // ما بقي مرشحين هنا
                boolean[] ok = readChunk(base, len, buf);
                ByteBuffer rb = ByteBuffer.wrap(old, 0, len);
                long pos = snapFileOff[i] + off;
                while (rb.hasRemaining()) {
                    int rr = snap.read(rb, pos);
                    if (rr <= 0) throw new java.io.IOException("فشلت قراءة اللقطة");
                    pos += rr;
                }
                for (int k = nextSet; k >= 0 && k < sb + slots; k = cand.nextSetBit(k + 1)) {
                    int p = (int) (k - sb) * size;
                    if (ok != null && !ok[p / PAGE]) { cand.clear(k); continue; }
                    long nw = rawAt(buf, p, size);
                    if (test(mode, type, rawAt(old, p, size), nw, op)) {
                        if (!overflow) {
                            if (cnt == na.length) {
                                int cap = Math.min(CAP, cnt * 2);
                                na = java.util.Arrays.copyOf(na, cap);
                                nv = java.util.Arrays.copyOf(nv, cap);
                            }
                            na[cnt] = base + p;
                            nv[cnt] = nw;
                            cnt++;
                            if (cnt >= CAP) overflow = true;
                        }
                    } else {
                        cand.clear(k);
                    }
                }
                done += len;
                progress(done, total);
            }
        }
        if (!overflow) {
            leaveSnap();
            addrs = na;
            vals = nv;
            n = cnt;
            out("OK " + n + " list");
            return;
        }
        // ما زالت النتائج كثيرة: نبقى على اللقطة ونحدّثها بالقيم الحالية (المقارنة الجاية نسبةً لهذي القراءة)
        for (int i = 0; i < snapRegs.size(); i++) {
            Reg r = snapRegs.get(i);
            long rlen = r.end - r.start;
            for (long off = 0; off < rlen; off += CHUNK) {
                int len = (int) Math.min(CHUNK, rlen - off);
                long sb = snapSlotBase[i] + off / size;
                int nextSet = cand.nextSetBit((int) sb);
                if (nextSet < 0 || nextSet >= sb + len / size) continue;
                boolean[] ok = readChunk(r.start + off, len, buf);
                if (ok != null) continue;                         // دفعة فيها صفحات ميتة: نخلي القديم
                ByteBuffer wb = ByteBuffer.wrap(buf, 0, len);
                long pos = snapFileOff[i] + off;
                while (wb.hasRemaining()) pos += snap.write(wb, pos);
            }
        }
        snapCount = cand.cardinality();
        out("OK " + snapCount + " snap");
    }

    // ---------------------------------------------------------------- عرض النتائج وتعديلها
    private void cmdList(int off, int cnt) throws Exception {
        requireMem();
        if (snapMode) throw new IllegalStateException("النتائج كثيرة (" + snapCount + ")؛ ضيّق البحث أولًا");
        List<Reg> all = readMaps();
        BlockReader br = new BlockReader();
        int end = Math.min(n, off + cnt);
        for (int i = Math.max(0, off); i < end; i++) {
            String v = br.read(addrs[i], size) ? fmt(type, br.raw) : "??";
            boolean fz;
            synchronized (frozen) { fz = frozen.containsKey(addrs[i]); }
            out("R " + Long.toHexString(addrs[i]) + " " + v + " " + tagAt(all, addrs[i]) + " " + (fz ? 1 : 0));
        }
        out("OK " + n);
    }

    private void cmdGet(String[] t) throws Exception {
        requireMem();
        int ty = typeOf(arg(t, 1));
        long a = hex(arg(t, 2), 16);
        byte[] b = new byte[8];
        if (!readFully(a, b, 0, sizeOf(ty))) throw new IllegalStateException("العنوان غير مقروء");
        out("OK " + fmt(ty, rawAt(b, 0, sizeOf(ty))));
    }

    private void cmdGetMany(String[] t) throws Exception {
        requireMem();
        StringBuilder sb = new StringBuilder("OK");
        byte[] b = new byte[8];
        for (int i = 1; i < t.length; i++) {
            String[] p = t[i].split(":");
            String v = "??";
            try {
                int ty = typeOf(p[0]);
                long a = hex(p[1], 16);
                if (readFully(a, b, 0, sizeOf(ty))) v = fmt(ty, rawAt(b, 0, sizeOf(ty)));
            } catch (Exception e) { }
            sb.append(' ').append(v);
        }
        out(sb.toString());
    }

    private void cmdSet(String[] t) throws Exception {
        requireMem();
        int ty = typeOf(arg(t, 1));
        long a = hex(arg(t, 2), 16);
        writeRaw(a, ty, parseRaw(ty, arg(t, 3)));
        synchronized (frozen) {
            Fz f = frozen.get(a);
            if (f != null) { f.raw = parseRaw(ty, t[3]); f.type = ty; }   // لو مجمّد نحدّث القيمة المجمّدة
        }
        out("OK");
    }

    private void cmdSetAll(String[] t) throws Exception {
        requireMem();
        if (snapMode || n == 0) throw new IllegalStateException("ما فيه قائمة نتائج للتعديل");
        long raw = parseRaw(type, arg(t, 1));
        int limit = t.length > 2 ? Integer.parseInt(t[2]) : n;
        int ok = 0;
        for (int i = 0; i < n && i < limit; i++) {
            try { writeRaw(addrs[i], type, raw); ok++; } catch (Exception e) { }
        }
        out("OK " + ok);
    }

    private void cmdFreeze(String[] t) throws Exception {
        requireMem();
        int ty = typeOf(arg(t, 1));
        long a = hex(arg(t, 2), 16);
        Fz f = new Fz();
        f.type = ty;
        f.raw = parseRaw(ty, arg(t, 3));
        writeRaw(a, ty, f.raw);
        synchronized (frozen) { frozen.put(a, f); }
        out("OK");
    }

    private void cmdInfo() {
        int fz;
        synchronized (frozen) { fz = frozen.size(); }
        out("OK " + (snapMode ? snapCount : n) + " " + (snapMode ? "snap" : n > 0 ? "list" : "none") + " " + fz);
    }

    // ---------------------------------------------------------------- التجميد
    private void startFreezer() {
        Thread th = new Thread(new Runnable() {
            public void run() {
                while (true) {
                    try { Thread.sleep(30); } catch (InterruptedException e) { return; }
                    if (mem == null) continue;
                    List<Map.Entry<Long, Fz>> items;
                    synchronized (frozen) {
                        if (frozen.isEmpty()) continue;
                        items = new ArrayList<Map.Entry<Long, Fz>>(frozen.entrySet());
                    }
                    for (Map.Entry<Long, Fz> e : items) {
                        Fz f = e.getValue();
                        try {
                            writeRaw(e.getKey(), f.type, f.raw);
                            f.fails = 0;
                        } catch (Exception ex) {
                            if (++f.fails > 50) synchronized (frozen) { frozen.remove(e.getKey()); }
                        }
                    }
                }
            }
        });
        th.setDaemon(true);
        th.start();
    }

    private void closeAll() {
        synchronized (frozen) { frozen.clear(); }
        leaveSnap();
        try { if (mem != null) mem.close(); } catch (Exception e) { }
        mem = null;
        pid = -1;
        n = 0;
    }
}
