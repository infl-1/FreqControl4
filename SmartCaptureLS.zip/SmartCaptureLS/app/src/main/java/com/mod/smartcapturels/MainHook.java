package com.mod.smartcapturels;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Runs inside system_server (module scope: "System Framework").
 *
 * The modded SmartCapture is signed with another key, so the system never grants it the
 * signature-level permissions the screen recorder needs (CAPTURE_VIDEO_OUTPUT,
 * READ_FRAME_BUFFER, INTERACT_ACROSS_USERS, MANAGE_ACTIVITY_TASKS, window types that need
 * INTERNAL_SYSTEM_WINDOW, ...). This hook answers PERMISSION_GRANTED for permission checks of
 * that ONE package when the system would have answered DENIED.
 *
 * Nothing else is touched: other packages, and checks that are already granted, are unchanged.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "[SCMOD] ";
    private static final String TARGET = "com.samsung.android.app.smartcapture";

    /**
     * true  : every denied permission check of TARGET is answered GRANTED (same effect as running
     *         with the system uid, but only for this package).
     * false : only the permissions listed in LIST below.
     */
    private static final boolean GRANT_ALL = true;

    private static final Set<String> LIST = new HashSet<>(Arrays.asList(
            "android.permission.CAPTURE_VIDEO_OUTPUT",
            "android.permission.CAPTURE_SECURE_VIDEO_OUTPUT",
            "android.permission.READ_FRAME_BUFFER",
            "com.samsung.android.permission.READ_FRAME_BUFFER_IGNORE_POLICY",
            "android.permission.MANAGE_MEDIA_PROJECTION",
            "android.permission.INTERACT_ACROSS_USERS",
            "android.permission.INTERACT_ACROSS_USERS_FULL",
            "android.permission.MANAGE_ACTIVITY_TASKS",
            "android.permission.SET_PROCESS_LIMIT",
            "android.permission.STATUS_BAR",
            "android.permission.INTERNAL_SYSTEM_WINDOW",
            "android.permission.WRITE_SECURE_SETTINGS",
            "android.permission.READ_PHONE_STATE",
            "com.samsung.android.permission.EXTRACT_SMARTCLIP_DATA"
    ));

    private static final int PER_USER_RANGE = 100000;
    private static final int FIRST_APPLICATION_UID = 10000;
    private static final long RELOOKUP_MS = 60_000L;

    private static final Set<String> LOGGED = ConcurrentHashMap.newKeySet();
    private static final ThreadLocal<Boolean> IN_LOOKUP = new ThreadLocal<>();

    private static volatile ClassLoader sLoader;
    private static volatile int sTargetAppId = -1;
    private static volatile long sLastLookup = 0L;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // system_server is reported as package "android"
        if (!"android".equals(lpparam.packageName)) return;
        sLoader = lpparam.classLoader;

        String[] classes = {
                "com.android.server.pm.permission.PermissionManagerServiceImpl",
                "com.android.server.pm.permission.PermissionManagerService",
                "com.android.server.pm.permission.PermissionManagerService$PermissionManagerServiceInternalImpl",
        };
        String[] methods = {"checkUidPermission", "checkPermission"};

        int hooked = 0;
        for (String cn : classes) {
            Class<?> c = XposedHelpers.findClassIfExists(cn, lpparam.classLoader);
            if (c == null) continue;
            for (String mn : methods) {
                try {
                    Set<?> s = XposedBridge.hookAllMethods(c, mn, CHECK_HOOK);
                    int n = s == null ? 0 : s.size();
                    hooked += n;
                    XposedBridge.log(TAG + "hooked " + n + " x " + cn + "#" + mn);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "hook failed " + cn + "#" + mn + " : " + t);
                }
            }
        }
        if (hooked == 0) {
            XposedBridge.log(TAG + "NOTHING hooked: PermissionManagerServiceImpl not found on this ROM."
                    + " Send this log line to the developer.");
        } else {
            XposedBridge.log(TAG + "ready, target=" + TARGET + " grantAll=" + GRANT_ALL);
        }
    }

    private static final XC_MethodHook CHECK_HOOK = new XC_MethodHook() {
        @Override
        protected void afterHookedMethod(MethodHookParam p) {
            try {
                Object r = p.getResult();
                if (!(r instanceof Integer) || ((Integer) r) == 0) return;   // already granted

                Object[] a = p.args;
                if (a == null || a.length < 2) return;
                String name = p.method.getName();

                String perm = null;
                boolean isTarget = false;

                if ("checkUidPermission".equals(name)) {
                    // (int uid, String perm [, device])   or   (String perm, int uid)
                    Integer uid = null;
                    for (Object o : a) {
                        if (uid == null && o instanceof Integer) uid = (Integer) o;
                        else if (perm == null && o instanceof String) perm = (String) o;
                    }
                    if (uid == null || perm == null) return;
                    isTarget = isTargetUid(uid);
                } else {
                    // (String pkg, String perm, ..., int userId)   or   (String perm, String pkg, int userId)
                    if (!(a[0] instanceof String) || !(a[1] instanceof String)) return;
                    String s0 = (String) a[0], s1 = (String) a[1];
                    if (TARGET.equals(s0)) { isTarget = true; perm = s1; }
                    else if (TARGET.equals(s1)) { isTarget = true; perm = s0; }
                }

                if (!isTarget || perm == null) return;
                if (!GRANT_ALL && !LIST.contains(perm)) return;

                p.setResult(0);   // PackageManager.PERMISSION_GRANTED
                if (LOGGED.add(perm)) XposedBridge.log(TAG + "granted " + perm + " to " + TARGET);
            } catch (Throwable t) {
                // never break the system's permission checks
            }
        }
    };

    /** true when the (any-user) uid belongs to the target package. Only called on denied checks. */
    private static boolean isTargetUid(int uid) {
        int appId = uid % PER_USER_RANGE;
        if (appId < FIRST_APPLICATION_UID) return false;       // root / system / shell: not ours

        long now = System.currentTimeMillis();
        if (sTargetAppId < 0 || now - sLastLookup > RELOOKUP_MS) {
            lookupTargetAppId(now);
        }
        return appId == sTargetAppId;
    }

    private static void lookupTargetAppId(long now) {
        if (Boolean.TRUE.equals(IN_LOOKUP.get())) return;       // no recursion
        IN_LOOKUP.set(Boolean.TRUE);
        try {
            sLastLookup = now;
            ClassLoader cl = sLoader;
            Class<?> ls = XposedHelpers.findClass("com.android.server.LocalServices", cl);
            Class<?> pmi = XposedHelpers.findClassIfExists("android.content.pm.PackageManagerInternal", cl);
            if (pmi == null) pmi = XposedHelpers.findClassIfExists("com.android.server.pm.PackageManagerInternal", cl);
            if (pmi == null) return;
            Object svc = XposedHelpers.callStaticMethod(ls, "getService", pmi);
            if (svc == null) return;

            int uid;
            try {
                uid = (Integer) XposedHelpers.callMethod(svc, "getPackageUid", TARGET, 0L, 0);   // flags: long (Android 13+)
            } catch (Throwable t) {
                uid = (Integer) XposedHelpers.callMethod(svc, "getPackageUid", TARGET, 0, 0);    // flags: int (older)
            }
            if (uid >= 0) {
                int appId = uid % PER_USER_RANGE;
                if (appId != sTargetAppId) {
                    sTargetAppId = appId;
                    XposedBridge.log(TAG + "target appId=" + appId);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "uid lookup failed: " + t);
        } finally {
            IN_LOOKUP.set(Boolean.FALSE);
        }
    }
}
