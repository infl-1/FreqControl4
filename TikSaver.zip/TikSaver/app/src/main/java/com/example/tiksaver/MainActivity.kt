package com.example.tiksaver

import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var linkInput: EditText
    private lateinit var downloadBtn: Button
    private lateinit var updateBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    private var ready = false
    private val urlRegex = Regex("""https?://\S+""")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        linkInput = findViewById(R.id.linkInput)
        downloadBtn = findViewById(R.id.downloadBtn)
        updateBtn = findViewById(R.id.updateBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.pasteBtn).setOnClickListener { pasteFromClipboard() }
        downloadBtn.setOnClickListener { startDownload() }
        updateBtn.setOnClickListener { updateEngine() }

        // لو جاء الرابط من زر "مشاركة" في تيك توك
        if (intent?.action == Intent.ACTION_SEND) {
            extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT))?.let { linkInput.setText(it) }
        }

        initEngine()
    }

    // ---------- المحرك ----------

    private fun initEngine() {
        busy(true)
        status.text = "جاري تجهيز المحرك (أول مرة فقط، ممكن ياخذ شوي)..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().init(applicationContext)
                }
                ready = true
                status.text = "جاهز ✅"
            } catch (e: Exception) {
                status.text = "تعذر تجهيز المحرك: ${e.message}"
            } finally {
                busy(false)
            }
        }
    }

    private fun updateEngine() {
        busy(true)
        status.text = "جاري تحديث المحرك..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().updateYoutubeDL(applicationContext)
                }
                status.text = "تم تحديث المحرك ✅"
            } catch (e: Exception) {
                status.text = "فشل التحديث، تأكد من الإنترنت"
            } finally {
                busy(false)
            }
        }
    }

    // ---------- التحميل ----------

    private fun startDownload() {
        val url = extractUrl(linkInput.text.toString())
        if (url == null || !isTikTok(url)) {
            status.text = "الرابط غير صالح، الصق رابط تيك توك"
            return
        }
        linkInput.setText(url)
        busy(true, determinate = true)
        status.text = "جاري التحميل..."

        lifecycleScope.launch {
            try {
                val file = downloadVideo(url)
                withContext(Dispatchers.IO) {
                    saveToGallery(file)
                    file.delete()
                }
                status.text = "تم الحفظ في المعرض (Movies/TikSaver) ✅"
            } catch (e: Exception) {
                status.text = "فشل التحميل. تأكد من الرابط، أو اضغط «تحديث المحرك» وحاول مرة ثانية."
            } finally {
                busy(false)
            }
        }
    }

    private suspend fun downloadVideo(url: String): File = withContext(Dispatchers.IO) {
        val dir = File(cacheDir, "dl").apply {
            deleteRecursively()
            mkdirs()
        }
        val request = YoutubeDLRequest(url)
        request.addOption("-o", "${dir.absolutePath}/%(id)s.%(ext)s")
        request.addOption("-f", "best") // أعلى جودة ملف واحد (فيديو + صوت)
        request.addOption("--no-playlist")

        YoutubeDL.getInstance().execute(request, "tiktok-download") { p, _, _ ->
            runOnUiThread { progress.progress = p.toInt().coerceIn(0, 100) }
        }

        dir.listFiles()?.firstOrNull {
            it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl")
        } ?: throw IOException("لم يتم العثور على الملف")
    }

    private fun saveToGallery(file: File) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "tiktok_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TikSaver")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri: Uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("تعذر إنشاء الملف في المعرض")

        resolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        } ?: throw IOException("تعذر الكتابة في المعرض")

        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
    }

    // ---------- أدوات مساعدة ----------

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString()
        val url = extractUrl(text)
        if (url != null) linkInput.setText(url) else status.text = "ما لقيت رابط في الحافظة"
    }

    private fun extractUrl(text: String?): String? = text?.let { urlRegex.find(it)?.value }

    private fun isTikTok(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        return host == "tiktok.com" || host.endsWith(".tiktok.com")
    }

    private fun busy(on: Boolean, determinate: Boolean = false) {
        progress.visibility = if (on) View.VISIBLE else View.GONE
        progress.isIndeterminate = !determinate
        progress.progress = 0
        downloadBtn.isEnabled = !on && ready
        updateBtn.isEnabled = !on
    }
}
