package io.github.freqctl.hook;

import android.content.Context;
import android.os.IBinder;
import android.os.SystemClock;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import io.github.freqctl.extras.ExtraSettings;

/**
 * Runs inside Samsung's Game Optimizing Service (com.samsung.android.game.gos).
 *
 * <p>GOS is the part of Game Booster that lowers CPU/GPU limits while a game is running. This hook
 * does not disable GOS: it skips the calls that cap frequencies, one switch per path, so the rest of
 * GOS (game list, Game Launcher, categories, notifications, the FPS overlay) keeps working.
 *
 * <p>Targets GOS 4.4.00.30. What the analysis of that build showed:
 * <ul>
 *   <li>The IPM / SPA engine is native ({@code libipm.so}). The Java methods {@code Ipm.setControllerMax*}
 *       and {@code Ipm.setMaxFreqs} are only an API for Java callers: while the engine runs, it applies its
 *       own maximums natively, through Samsung's frequency manager ({@code ICustomFrequencyManager}:
 *       acquireDVFSLock, acquire, requestGPU / requestCPUCore / requestSysBus, acquireSiopMaxlock). Hooking
 *       only those Java methods therefore had no effect on a running game.</li>
 *   <li>The Java side of GOS sets its own maximums through {@code selibrary.SeDvfsInterfaceImpl}
 *       (setDvfsValue / acquire, resource type in {@code mType}), which end up in {@code SemDvfsManager}.</li>
 *   <li>Game SDK levels ({@code feature.externalsdk.n / .o}): setCpuLevel / setGpuLevel.</li>
 * </ul>
 *
 * <p>So the "block caps" switch now also blocks at those two lower layers, and only for MAX resource types.
 * Minimum / boost requests are left alone. Every cap block is released while the FreqControl thermal guard
 * is tripped. Each hook is installed on its own and a missing one is only logged. The diagnostics switch
 * writes a periodic summary of what GOS asked for to the LSPosed log, so a wrong guess can be corrected.
 */
final class GosHook {
    static final String PACKAGE = "com.samsung.android.game.gos";

    private static final String IPM = PACKAGE + ".ipm.Ipm";
    private static final String CONTROLLER_TYPE = PACKAGE + ".ipm.ControllerType";
    private static final String SDK_SPA = PACKAGE + ".feature.externalsdk.n";
    private static final String SDK_SSRM = PACKAGE + ".feature.externalsdk.o";
    private static final String SE_DVFS = PACKAGE + ".selibrary.SeDvfsInterfaceImpl";
    private static final String SE_DVFS_125 = PACKAGE + ".selibrary.SeDvfsInterfaceSE125";
    private static final String SEM_DVFS = "com.samsung.android.os.SemDvfsManager";
    private static final String CFM = "android.os.CustomFrequencyManager";
    private static final String ICFM_PROXY = "android.os.ICustomFrequencyManager$Stub$Proxy";
    private static final String ICFM_STUB = "android.os.ICustomFrequencyManager$Stub";

    /** Log only the first few blocked calls of each kind, so the LSPosed log stays readable. */
    private static final int LOG_LIMIT = 5;
    private static final long DUMP_EVERY_MS = 30_000L;
    private static final long CACHE_MS = 1_000L;

    private GosHook() {
    }

    static void install(ClassLoader classLoader) {
        // IPM engine, stricter switch: do not let it start at all (this also stops its FPS statistics).
        hook(classLoader, IPM, "startNative", ExtraSettings.K_GOS_IPM, null);
        hook(classLoader, IPM, "startSpaIfPossible", ExtraSettings.K_GOS_IPM, Boolean.FALSE, String.class);

        // IPM Java API (only reached by Java callers, kept for completeness).
        hook(classLoader, IPM, "setControllerMax", ExtraSettings.K_GOS_CAPS, null, CONTROLLER_TYPE, Long.class);
        hook(classLoader, IPM, "setControllerMaxLevelAsPercentage", ExtraSettings.K_GOS_CAPS, null,
                CONTROLLER_TYPE, Float.class);
        hook(classLoader, IPM, "setMaxFreqs", ExtraSettings.K_GOS_CAPS, null, long.class, long.class);

        // Game SDK performance levels: report success without passing the level on.
        for (String className : new String[]{SDK_SPA, SDK_SSRM}) {
            hook(classLoader, className, "e", ExtraSettings.K_GOS_LEVELS, Boolean.TRUE, int.class); // setGpuLevel
            hook(classLoader, className, "h", ExtraSettings.K_GOS_LEVELS, Boolean.TRUE, int.class); // setCpuLevel
        }

        // The layers a running engine really goes through.
        installCapHooks(classLoader);
        installBinderDiagnostics(classLoader);
    }

    // ================================================================== cap hooks

    private static void installCapHooks(ClassLoader cl) {
        final Types sem = types(cl, SEM_DVFS);
        final Types cfm = types(cl, CFM);

        // 1) GOS's own Java side: SeDvfsInterfaceImpl(mType).setDvfsValue / acquire.
        for (String className : new String[]{SE_DVFS, SE_DVFS_125}) {
            hookAll(cl, className, "setDvfsValue", new CapHook("SeDvfs.setDvfsValue", Kind.SE, sem, false));
            hookAll(cl, className, "acquire", new CapHook("SeDvfs.acquire", Kind.SE, sem, false));
        }

        // 2) Framework SemDvfsManager used directly (addResourceValue first, acquire after).
        hookAll(cl, SEM_DVFS, "addResourceValue", new CapHook("SemDvfsManager.addResourceValue", Kind.SEM_ADD, sem, false));
        semAcquireHook = new CapHook("SemDvfsManager.acquire", Kind.SEM_ACQUIRE, sem, false);
        hookAll(cl, SEM_DVFS, "acquire", semAcquireHook);

        // 3) Samsung's frequency manager: what the native IPM engine calls through JNI.
        for (String className : new String[]{ICFM_PROXY, CFM}) {
            for (String method : new String[]{"acquireDVFSLock", "acquire", "requestGPU", "requestCPUCore",
                    "requestSysBus"}) {
                hookAll(cl, className, method, new CapHook(shortName(className) + "." + method, Kind.CFM, cfm, false));
            }
            hookAll(cl, className, "acquireSiopMaxlock",
                    new CapHook(shortName(className) + ".acquireSiopMaxlock", Kind.CFM, cfm, true));
        }
    }

    private static String shortName(String className) {
        return className.substring(className.lastIndexOf('.') + 1);
    }

    /**
     * Hooks every CONCRETE method of that name declared in the class. hookAllMethods() throws on the first abstract
     * overload and leaves the rest unhooked, which is what the log showed for SeDvfsInterfaceImpl.setDvfsValue
     * and SemDvfsManager.acquire.
     */
    private static void hookAll(ClassLoader cl, String className, String method, XC_MethodHook callback) {
        try {
            Class<?> c = XposedHelpers.findClass(className, cl);
            int hooked = hookConcrete(c, method, callback);
            if (hooked == 0) {
                XposedBridge.log("FreqCtl/GOS: " + shortName(className) + "." + method
                        + " has no concrete method here (hooked at run time on the real class when it appears)");
            }
        } catch (Throwable t) {
            XposedBridge.log("FreqCtl/GOS: could not hook " + shortName(className) + "." + method
                    + " (not in this build?): " + t);
        }
    }

    private static final Set<String> HOOKED = Collections.synchronizedSet(new HashSet<String>());

    /** Hooks the non-abstract methods called {@code method} declared by {@code c}; each (class, method) only once. */
    private static int hookConcrete(Class<?> c, String method, XC_MethodHook callback) {
        if (!HOOKED.add(c.getName() + "#" + method + "#" + System.identityHashCode(callback))) {
            return 1;
        }
        int hooked = 0;
        for (Method m : c.getDeclaredMethods()) {
            if (!m.getName().equals(method) || Modifier.isAbstract(m.getModifiers())) {
                continue;
            }
            try {
                XposedBridge.hookMethod(m, callback);
                hooked++;
            } catch (Throwable t) {
                XposedBridge.log("FreqCtl/GOS: could not hook " + c.getName() + "." + method + ": " + t);
            }
        }
        return hooked;
    }

    /** The hook for SemDvfsManager.acquire(); also put on the concrete subclass that really gets used. */
    private static volatile XC_MethodHook semAcquireHook;

    private enum Kind {SE, SEM_ADD, SEM_ACQUIRE, CFM}

    /** MAX / MIN resource-type constants of one framework class, read at runtime so no number is hard-coded. */
    private static final class Types {
        final String name;
        private final Set<Integer> max = new HashSet<>();
        private final Set<Integer> min = new HashSet<>();
        final String dump;

        Types(String name, Class<?> c) {
            this.name = name;
            StringBuilder sb = new StringBuilder();
            if (c != null) {
                for (Field f : c.getDeclaredFields()) {
                    String n = f.getName();
                    if (!Modifier.isStatic(f.getModifiers()) || f.getType() != int.class
                            || !(n.startsWith("TYPE_") || n.startsWith("FREQUENCY_"))) {
                        continue;
                    }
                    try {
                        f.setAccessible(true);
                        int v = f.getInt(null);
                        if (n.contains("MAX")) {
                            max.add(v);
                            sb.append(" MAX:").append(n).append('=').append(v);
                        } else if (n.contains("MIN")) {
                            min.add(v);
                            sb.append(" MIN:").append(n).append('=').append(v);
                        }
                    } catch (Throwable ignored) {
                        // field not readable: skip it
                    }
                }
            }
            dump = sb.toString();
        }

        /** A value that is a MAX type and not also a MIN type (ambiguous values are left alone). */
        boolean isCap(int v) {
            return max.contains(v) && !min.contains(v);
        }

        boolean known() {
            return !max.isEmpty();
        }
    }

    private static Types types(ClassLoader cl, String className) {
        Class<?> c = null;
        try {
            c = XposedHelpers.findClass(className, cl);
        } catch (Throwable t) {
            XposedBridge.log("FreqCtl/GOS: " + className + " not found: " + t);
        }
        Types t = new Types(className, c);
        if (!t.known()) {
            XposedBridge.log("FreqCtl/GOS: no MAX type constants in " + className
                    + ", cap blocking through it is disabled");
        } else {
            XposedBridge.log("FreqCtl/GOS: " + shortName(className) + " types:" + t.dump);
        }
        return t;
    }

    private static final Map<Object, Boolean> CAP_INSTANCES = Collections.synchronizedMap(new WeakHashMap<>());

    private static final class CapHook extends XC_MethodHook {
        private final String label;
        private final Kind kind;
        private final Types types;
        private final boolean always;

        CapHook(String label, Kind kind, Types types, boolean always) {
            this.label = label;
            this.kind = kind;
            this.types = types;
            this.always = always;
        }

        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            try {
                boolean cap = isCap(param);
                if (kind == Kind.SEM_ADD && param.thisObject != null && semAcquireHook != null) {
                    // acquire() is abstract on SemDvfsManager: hook it on the class that is really in use
                    hookConcrete(param.thisObject.getClass(), "acquire", semAcquireHook);
                }
                if (kind == Kind.SEM_ADD) {
                    // remember which SemDvfsManager instance carries a cap, so its acquire() can be skipped
                    if (cap) {
                        CAP_INSTANCES.put(param.thisObject, Boolean.TRUE);
                    } else {
                        CAP_INSTANCES.remove(param.thisObject);
                    }
                }
                boolean block = cap && capsOn();
                note(label, block ? "BLOCKED" : (cap ? "cap-but-switch-off" : "passed"), param.args);
                if (block) {
                    skip(param);
                }
            } catch (Throwable t) {
                note(label, "error " + t, param.args);
            }
        }

        private boolean isCap(MethodHookParam param) {
            if (always) {
                return true;
            }
            switch (kind) {
                case SE: {
                    int type = intField(param.thisObject, "mType");
                    return type != Integer.MIN_VALUE && types.isCap(type);
                }
                case SEM_ACQUIRE:
                    return CAP_INSTANCES.containsKey(param.thisObject);
                case SEM_ADD:
                case CFM:
                default: {
                    Integer first = firstInt(param.args);
                    return first != null && types.isCap(first);
                }
            }
        }

        private void skip(MethodHookParam param) {
            // only void methods can be skipped safely with a null result
            if (param.method instanceof Method && ((Method) param.method).getReturnType() == void.class) {
                param.setResult(null);
            }
        }
    }

    private static Integer firstInt(Object[] args) {
        if (args == null) {
            return null;
        }
        for (Object a : args) {
            if (a instanceof Integer) {
                return (Integer) a;
            }
        }
        return null;
    }

    private static int intField(Object o, String name) {
        for (Class<?> c = o == null ? null : o.getClass(); c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f.getInt(o);
            } catch (NoSuchFieldException e) {
                // try the superclass
            } catch (Throwable t) {
                return Integer.MIN_VALUE;
            }
        }
        return Integer.MIN_VALUE;
    }

    // ================================================================== diagnostics

    private static final ConcurrentHashMap<String, AtomicInteger> COUNTS = new ConcurrentHashMap<>();
    private static volatile long lastDump;

    private static void note(String label, String verdict, Object[] args) {
        if (setting(ExtraSettings.K_GOS_DEBUG, 0) != 1) {
            return;
        }
        String key = label + " -> " + verdict;
        int n = COUNTS.computeIfAbsent(key, k -> new AtomicInteger()).incrementAndGet();
        if (n <= 3) {
            XposedBridge.log("FreqCtl/GOS: " + key + " args=" + describe(args));
        }
        long now = SystemClock.elapsedRealtime();
        if (now - lastDump > DUMP_EVERY_MS) {
            lastDump = now;
            List<String> keys = new ArrayList<>(COUNTS.keySet());
            Collections.sort(keys);
            StringBuilder sb = new StringBuilder("FreqCtl/GOS: summary since boot of GOS\n");
            for (String k : keys) {
                sb.append("  ").append(COUNTS.get(k).get()).append("x ").append(k).append('\n');
            }
            XposedBridge.log(sb.toString());
        }
    }

    private static String describe(Object[] args) {
        if (args == null) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < args.length; i++) {
            Object a = args[i];
            if (i > 0) {
                sb.append(", ");
            }
            if (a instanceof int[]) {
                int[] arr = (int[]) a;
                sb.append("int[").append(arr.length).append("]{");
                for (int k = 0; k < Math.min(arr.length, 6); k++) {
                    sb.append(k > 0 ? "," : "").append(arr[k]);
                }
                sb.append('}');
            } else if (a instanceof IBinder) {
                sb.append("IBinder");
            } else {
                sb.append(a);
            }
        }
        return sb.append(']').toString();
    }

    /** With diagnostics on, names every binder call GOS makes to the frequency manager / SDHMS / SSRM. */
    private static void installBinderDiagnostics(ClassLoader cl) {
        try {
            Class<?> proxy = XposedHelpers.findClass("android.os.BinderProxy", cl);
            XposedBridge.hookAllMethods(proxy, "transact", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (setting(ExtraSettings.K_GOS_DEBUG, 0) != 1) {
                        return;
                    }
                    try {
                        String d = ((IBinder) param.thisObject).getInterfaceDescriptor();
                        if (d == null || !(d.contains("CustomFrequency") || d.contains("sdhms")
                                || d.contains("Ssrm") || d.contains("SemGame"))) {
                            return;
                        }
                        int code = (Integer) param.args[0];
                        note("binder " + d + "#" + transactionName(d, code), "seen", null);
                    } catch (Throwable ignored) {
                        // diagnostics only
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("FreqCtl/GOS: binder diagnostics unavailable: " + t);
        }
    }

    private static volatile Map<Integer, String> icfmCodes;

    private static String transactionName(String descriptor, int code) {
        if (!descriptor.contains("CustomFrequencyManager")) {
            return String.valueOf(code);
        }
        Map<Integer, String> codes = icfmCodes;
        if (codes == null) {
            codes = new HashMap<>();
            try {
                Class<?> stub = XposedHelpers.findClass(ICFM_STUB, null);
                for (Field f : stub.getDeclaredFields()) {
                    if (f.getName().startsWith("TRANSACTION_") && f.getType() == int.class) {
                        f.setAccessible(true);
                        codes.put(f.getInt(null), f.getName().substring("TRANSACTION_".length()));
                    }
                }
            } catch (Throwable ignored) {
                // names stay numeric
            }
            icfmCodes = codes;
        }
        String n = codes.get(code);
        return n != null ? n : String.valueOf(code);
    }

    // ================================================================== plain method blocks

    /**
     * @param result what the skipped method returns (null for void)
     * @param params parameter types, as Class objects or class names
     */
    private static void hook(ClassLoader classLoader, String className, String method, String key,
                             Object result, Object... params) {
        final String label = className.substring(className.lastIndexOf('.') + 1) + "." + method;
        try {
            Object[] args = new Object[params.length + 1];
            System.arraycopy(params, 0, args, 0, params.length);
            args[params.length] = new Block(key, label, result);
            XposedHelpers.findAndHookMethod(className, classLoader, method, args);
        } catch (Throwable t) {
            XposedBridge.log("FreqCtl/GOS: could not hook " + label + " (GOS version differs?)");
            XposedBridge.log(t);
        }
    }

    private static final class Block extends XC_MethodHook {
        private final String key;
        private final String label;
        private final Object result;
        private final AtomicInteger blocked = new AtomicInteger();

        Block(String key, String label, Object result) {
            this.key = key;
            this.label = label;
            this.result = result;
        }

        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            if (!enabled(key)) {
                return;
            }
            param.setResult(result);
            if (blocked.incrementAndGet() <= LOG_LIMIT) {
                XposedBridge.log("FreqCtl/GOS: skipped " + label);
            }
            note(label, "BLOCKED", param.args);
        }
    }

    // ================================================================== settings

    private static final class Cached {
        final int value;
        final long at;

        Cached(int value, long at) {
            this.value = value;
            this.at = at;
        }
    }

    private static final ConcurrentHashMap<String, Cached> CACHE = new ConcurrentHashMap<>();
    private static volatile Context appContext;

    /** Settings.Global value, cached for a second: some of these calls happen many times a second. */
    private static int setting(String key, int def) {
        long now = SystemClock.uptimeMillis();
        Cached c = CACHE.get(key);
        if (c != null && now - c.at < CACHE_MS) {
            return c.value;
        }
        int v = def;
        try {
            Context ctx = appContext;
            if (ctx == null) {
                Object app = XposedHelpers.callStaticMethod(
                        XposedHelpers.findClass("android.app.ActivityThread", null), "currentApplication");
                if (app instanceof Context) {
                    ctx = (Context) app;
                    appContext = ctx;
                }
            }
            if (ctx != null) {
                v = ExtraSettings.get(ctx, key, def);
            }
        } catch (Throwable t) {
            v = def;
        }
        CACHE.put(key, new Cached(v, now));
        return v;
    }

    private static boolean tripped() {
        return setting(ExtraSettings.K_GUARD, 0) == 1;
    }

    /** Frequency-cap blocking is released while the thermal guard is tripped. */
    private static boolean capsOn() {
        return setting(ExtraSettings.K_GOS_CAPS, 0) == 1 && !tripped();
    }

    /** Reads the switch the UI wrote. Any failure means "off": GOS then behaves as stock. */
    private static boolean enabled(String key) {
        if (setting(key, 0) != 1) {
            return false;
        }
        boolean releasedByGuard = ExtraSettings.K_GOS_CAPS.equals(key) || ExtraSettings.K_GOS_LEVELS.equals(key);
        return !(releasedByGuard && tripped());
    }
}
