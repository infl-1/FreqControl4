package com.example.speedtool

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var params: WindowManager.LayoutParams
    private val ui = Handler(Looper.getMainLooper())
    private var watchdog: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // السرعة بالأعداد الصحيحة: 0.2 .. 8.0 بخطوة 0.1 بدون تراكم أخطاء الكسور
    private fun speedOf(progress: Int) = (2 + progress) / 10.0
    private fun progressOf(speed: Double) = (Math.round(speed * 10).toInt() - 2).coerceIn(0, 78)

    /** خدمة أمامية: بدونها أندرويد يقتل الأيقونة العائمة بعد ما التطبيق يروح للخلفية. */
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Speed Tool", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
                      else Notification.Builder(this)
        val notif = builder
            .setContentTitle("Speed Tool")
            .setContentText("الأيقونة العائمة شغّالة")
            .setSmallIcon(android.R.drawable.ic_media_ff)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notif)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val bubble = TextView(this).apply {
            text = "⚡"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC1565C0.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }
        val panel = buildPanel()
        panel.visibility = View.GONE
        root.addView(bubble)
        root.addView(panel)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8); y = dp(120)
        }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = params.x; startY = params.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) moved = true
                    if (moved) {
                        params.x = startX + dx; params.y = startY + dy
                        wm.updateViewLayout(root, params)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        panel.visibility =
                            if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                    }
                }
            }
            true
        }
        wm.addView(root, params)
    }

    private fun buildPanel(): LinearLayout {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0xEE202124.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(dp(240), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val appBtn = Button(this).apply {
            transformationMethod = null
            textSize = 12f
            text = Engine.pkg ?: "اختر التطبيق ▼"
        }
        val modeBtn = Button(this).apply { transformationMethod = null; textSize = 11f }
        fun modeText() {
            modeBtn.text = if (Engine.mode == "libc") "الوضع: ساعة النظام (ألعاب عادية)" else "الوضع: تلقائي (Unity)"
        }
        val pk0 = Engine.pkg
        if (pk0 != null) Engine.mode = Engine.modeFor(applicationContext, pk0)
        modeText()
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val listScroll = ScrollView(this).apply {
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(180))
            addView(listBox)
        }
        val label = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 18f
            text = "السرعة: x%.1f".format(java.util.Locale.US, Engine.speed)
        }
        val bar = SeekBar(this).apply {
            max = 78
            progress = progressOf(Engine.speed)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, pr: Int, u: Boolean) {
                    label.text = "السرعة: x%.1f".format(java.util.Locale.US, speedOf(pr))
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    Engine.updateSpeed(speedOf(s?.progress ?: 0))
                }
            })
        }
        val status = TextView(this).apply { setTextColor(Color.GRAY); textSize = 10f }
        val toggle = Button(this)
        fun refresh() { toggle.text = if (Engine.running) "إيقاف" else "ابدأ التسريع" }
        refresh()

        fun choose(a: Engine.App) {
            listScroll.visibility = View.GONE
            if (Engine.isBlocked(a.pkg)) {
                status.text = "هذا تطبيق أونلاين وفيه حظر للحسابات، الأداة ترفض تشتغل عليه."
                return
            }
            if (Engine.running) Engine.stop()
            Engine.pkg = a.pkg
            Engine.mode = Engine.modeFor(applicationContext, a.pkg)
            modeText()
            appBtn.text = a.label
            status.text = "تم اختيار: " + a.pkg
            refresh()
        }

        modeBtn.setOnClickListener {
            val pk = Engine.pkg
            if (Engine.running) {
                status.text = "أوقف التسريع أول، ثم غيّر الوضع"
            } else {
                Engine.mode = if (Engine.mode == "libc") "auto" else "libc"
                if (pk != null) Engine.saveMode(applicationContext, pk, Engine.mode)
                modeText()
                status.text = "الوضع يتطبق عند الضغط على ابدأ التسريع"
            }
        }

        appBtn.setOnClickListener {
            if (listScroll.visibility == View.VISIBLE) {
                listScroll.visibility = View.GONE
            } else {
                status.text = "جاري تحميل القائمة..."
                Engine.listRunning(applicationContext) { apps ->
                    listBox.removeAllViews()
                    if (apps.isEmpty()) {
                        status.text = "ما لقيت تطبيقات شغالة (تأكد من الروت وإن اللعبة شغالة)"
                    } else {
                        apps.forEach { a ->
                            val row = LinearLayout(this).apply {
                                orientation = LinearLayout.HORIZONTAL
                                gravity = Gravity.CENTER_VERTICAL
                                setPadding(dp(6), dp(6), dp(6), dp(6))
                                setOnClickListener { choose(a) }
                            }
                            val img = ImageView(this).apply {
                                layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
                                if (a.icon != null) setImageDrawable(a.icon)
                            }
                            val texts = LinearLayout(this).apply {
                                orientation = LinearLayout.VERTICAL
                                setPadding(dp(8), 0, 0, 0)
                                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                            }
                            texts.addView(TextView(this).apply {
                                text = a.label
                                setTextColor(Color.WHITE)
                                textSize = 13f
                                maxLines = 1
                            })
                            texts.addView(TextView(this).apply {
                                text = a.pkg
                                setTextColor(Color.LTGRAY)
                                textSize = 10f
                                maxLines = 1
                                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                            })
                            row.addView(img)
                            row.addView(texts)
                            listBox.addView(row)
                        }
                        status.text = ""
                        listScroll.visibility = View.VISIBLE
                    }
                }
            }
        }

        toggle.setOnClickListener {
            if (Engine.running) {
                Engine.stop { status.text = "تم الإيقاف"; refresh() }
            } else {
                Engine.speed = speedOf(bar.progress)
                status.text = "جاري التشغيل..."
                Engine.start(applicationContext) { msg -> status.text = msg; refresh() }
            }
            refresh()
        }
        val close = Button(this).apply {
            text = "إغلاق الأيقونة"
            setOnClickListener { stopSelf() }
        }
        listOf(appBtn, listScroll, modeBtn, label, bar, toggle, status, close).forEach { p.addView(it) }

        // لو اللعبة أُغلقت يموت الحاقن؛ نكتشفه ونرجّع الواجهة وSELinux بدل ما نقول "شغّال" وهو ميّت
        val w = object : Runnable {
            override fun run() {
                if (Engine.running && System.currentTimeMillis() - Engine.startedAt > 8000) {
                    Engine.alive { ok ->
                        if (!ok && Engine.running) {
                            Engine.stop()
                            status.text = "الحاقن توقف (اللعبة أُغلقت؟). افتحها واضغط ابدأ من جديد."
                            refresh()
                        }
                    }
                }
                ui.postDelayed(this, 10000)
            }
        }
        watchdog = w
        ui.postDelayed(w, 10000)
        return p
    }

    override fun onDestroy() {
        watchdog?.let { ui.removeCallbacks(it) }
        if (Engine.running) Engine.stop()          // يرجّع السرعة وSELinux
        try { wm.removeView(root) } catch (e: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "speedtool_overlay"
    }
}
