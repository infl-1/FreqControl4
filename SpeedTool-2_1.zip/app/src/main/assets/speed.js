'use strict';
// السرعة تُقرأ من الملف كل 300ms.
// وضعان:
//  1) ألعاب Unity (IL2CPP أو Mono): نضبط Time.timeScale من خيط اللعبة الرئيسي. ما نلمس ساعة النظام،
//     لأن تزييفها يخرّب توقيت الإطارات (Swappy/vsync) فتصير اللعبة "تقطّع" بدون ما تتسرّع.
//  2) باقي الألعاب (أو لو فشل وضع Unity): نغيّر الوقت اللي يشوفه كود اللعبة فقط (libc).
const PATH = '/data/local/tmp/speed.txt';
const FIX_WAITS = true;     // وضع libc: يحوّل مهلات الانتظار المطلقة (cond/sem/mutex) من المزيّف للحقيقي
const DIAG = false;          // تشخيص: يسجّل من وين اللعبة تاخذ وقتها (يطلع في السجل أسطر DIAG). خله false لما تخلص
const FIX_SLEEPS = true;    // وضع libc: يقسم النوم النسبي (nanosleep/usleep) على السرعة
function readMode() {
  try { return File.readAllText('/data/local/tmp/mode.txt').trim(); } catch (e) { return 'auto'; }
}
const MODE = readMode();               // auto = Unity timeScale إذا لقى Unity، غير كذا libc | libc = إجبار ساعة النظام
const UNITY_MODE = MODE !== 'libc';
console.log('speed.js v2.1 (active-source detect, per-source clocks, no loader lock) mode=' + MODE);
let speed = 1.0;
let engaged = false;        // يصير true أول ما تتغير السرعة عن 1.0؛ قبلها ما نلمس أي شي (وضع libc)
let useLibc = true;         // true = نزيّف ساعة النظام
let calls = 0, failedRead = false, failedHook = false;
let unityPending = false, unityPendingSince = 0;

function logHookError(e) {
  if (!failedHook) { failedHook = true; console.log('hook error: ' + e); }
}

function exp(mod, name) {
  try { const a = mod.findExportByName(name); if (a) return a; } catch (e) {}
  try { return mod.getExportByName(name); } catch (e) {}
  return null;
}
function findExp(name) {
  try { if (Module.findExportByName) { const a = Module.findExportByName(null, name); if (a) return a; } } catch (e) {}
  try { const m = Process.getModuleByName('libc.so'); return exp(m, name); } catch (e) {}
  return null;
}

// ================= وضع Unity: Time.timeScale =================
function detectUnity() {
  if (!UNITY_MODE) return null;
  try {
    const il = Process.findModuleByName('libil2cpp.so');
    if (il) return { kind: 'il2cpp', lib: il };
    const mono = Process.enumerateModules().find(function (m) { return /^libmono.*\.so$/.test(m.name); });
    if (mono) return { kind: 'mono', lib: mono };
  } catch (e) { console.log('detect error: ' + e); }
  return null;
}
const unity = detectUnity();
if (unity) useLibc = false;
console.log('backend=' + (unity ? unity.kind : 'libc'));

const U = { ready: false, ok: false, fails: 0, mainTid: 0, inApply: false, gaveUp: false };
let tsSet = NULL, tsGet = NULL, invokeNF = null;
let icSet = null, icGet = null;   // دوال icall الأصلية (احتياط لما اللعبة تقصّ set_timeScale من الكود المُدار)
const fbuf = Memory.alloc(16), argv = Memory.alloc(16), excBuf = Memory.alloc(16);
const keepStr = [];
function K(s) { const p = Memory.allocUtf8String(s); keepStr.push(p); return p; }
function nf(lib, name, ret, args) {
  const a = exp(lib, name);
  if (!a) throw new Error('missing export ' + name);
  return new NativeFunction(a, ret, args);
}

function giveUp(why) {
  if (U.gaveUp) return;
  U.gaveUp = true; unityPending = false; useLibc = true;
  console.log('unity mode off (' + why + ') -> libc time hooks');
}

function resolveUnity() {
  const lib = unity.lib;
  let klass = NULL, meth;
  if (unity.kind === 'il2cpp') {
    const dom = nf(lib, 'il2cpp_domain_get', 'pointer', [])();
    const getAsms = nf(lib, 'il2cpp_domain_get_assemblies', 'pointer', ['pointer', 'pointer']);
    const asmImg = nf(lib, 'il2cpp_assembly_get_image', 'pointer', ['pointer']);
    const clsFrom = nf(lib, 'il2cpp_class_from_name', 'pointer', ['pointer', 'pointer', 'pointer']);
    meth = nf(lib, 'il2cpp_class_get_method_from_name', 'pointer', ['pointer', 'pointer', 'int']);
    invokeNF = nf(lib, 'il2cpp_runtime_invoke', 'pointer', ['pointer', 'pointer', 'pointer', 'pointer']);
    const sz = Memory.alloc(8);
    sz.writeU64(0);
    const arr = getAsms(dom, sz);
    const n = Number(sz.readU64());
    for (let i = 0; i < n && klass.isNull(); i++) {
      const img = asmImg(arr.add(i * Process.pointerSize).readPointer());
      klass = clsFrom(img, K('UnityEngine'), K('Time'));
    }
  } else {
    const nameNew = nf(lib, 'mono_assembly_name_new', 'pointer', ['pointer']);
    const loaded = nf(lib, 'mono_assembly_loaded', 'pointer', ['pointer']);
    const asmImg = nf(lib, 'mono_assembly_get_image', 'pointer', ['pointer']);
    const clsFrom = nf(lib, 'mono_class_from_name', 'pointer', ['pointer', 'pointer', 'pointer']);
    meth = nf(lib, 'mono_class_get_method_from_name', 'pointer', ['pointer', 'pointer', 'int']);
    invokeNF = nf(lib, 'mono_runtime_invoke', 'pointer', ['pointer', 'pointer', 'pointer', 'pointer']);
    const names = ['UnityEngine.CoreModule', 'UnityEngine'];
    for (let i = 0; i < names.length && klass.isNull(); i++) {
      const an = nameNew(K(names[i]));
      if (an.isNull()) continue;
      const asm = loaded(an);
      if (asm.isNull()) continue;
      klass = clsFrom(asmImg(asm), K('UnityEngine'), K('Time'));
    }
  }
  if (!klass.isNull()) {
    tsSet = meth(klass, K('set_timeScale'), 1);
    tsGet = meth(klass, K('get_timeScale'), 0);
  }
  if (tsSet.isNull()) {
    // Unity يقصّ الدوال اللي ما يستخدمها كود اللعبة، فنروح للدالة الأصلية في المحرك مباشرة
    if (unity.kind === 'il2cpp') {
      if (!klass.isNull()) dumpTimeMethods(lib, klass);
      if (resolveIcalls(lib)) { console.log('unity: using icall Time.set_timeScale'); return; }
    }
    throw new Error((klass.isNull() ? 'UnityEngine.Time class not found' : 'set_timeScale not found') + ' (icall also failed)');
  }
}

// تشخيص: يطبع الدوال اللي فعلاً موجودة في كلاس Time (عشان نعرف وش اللي انقصّ)
function dumpTimeMethods(lib, klass) {
  try {
    const getM = nf(lib, 'il2cpp_class_get_methods', 'pointer', ['pointer', 'pointer']);
    const mName = nf(lib, 'il2cpp_method_get_name', 'pointer', ['pointer']);
    const it = Memory.alloc(Process.pointerSize);
    it.writePointer(NULL);
    const names = [];
    for (let i = 0; i < 300; i++) {
      const m = getM(klass, it);
      if (m.isNull()) break;
      names.push(mName(m).readCString());
    }
    console.log('Time methods: ' + names.length + ' | ' + names.filter(function (n) { return /scale|delta|fixed/i.test(n); }).join(','));
  } catch (e) { console.log('dump methods failed: ' + e); }
}

function resolveIcalls(lib) {
  try {
    const r = exp(lib, 'il2cpp_resolve_icall');
    if (!r) { console.log('icall: il2cpp_resolve_icall export missing'); return false; }
    const resolve = new NativeFunction(r, 'pointer', ['pointer']);
    const find = function (names) {
      for (let i = 0; i < names.length; i++) {
        let p = NULL;
        try { p = resolve(K(names[i])); } catch (e) { console.log('icall error ' + names[i] + ': ' + e); }
        console.log('icall ' + names[i] + ' -> ' + (p && !p.isNull() ? 'found' : 'null'));
        if (p && !p.isNull()) return p;
      }
      return NULL;
    };
    const s = find(['UnityEngine.Time::set_timeScale', 'UnityEngine.Time::set_timeScale(System.Single)']);
    if (s.isNull()) return false;
    const g = find(['UnityEngine.Time::get_timeScale', 'UnityEngine.Time::get_timeScale()']);
    icSet = new NativeFunction(s, 'void', ['float']);
    icGet = g.isNull() ? null : new NativeFunction(g, 'float', []);
    return true;
  } catch (e) {
    console.log('icall resolve failed: ' + e);
    return false;
  }
}

function callStatic(m, v) {
  excBuf.writePointer(NULL);
  let a = NULL;
  if (v !== undefined) { fbuf.writeFloat(v); argv.writePointer(fbuf); a = argv; }
  const r = invokeNF(m, NULL, a, excBuf);
  if (!excBuf.readPointer().isNull()) throw new Error('managed exception');
  return r;
}
function setTS(v) {
  if (icSet) { icSet(v); return; }
  callStatic(tsSet, v);
}
function readTS() {
  if (icSet) return icGet ? icGet() : NaN;
  if (tsGet.isNull()) return NaN;
  const r = callStatic(tsGet);
  return r.isNull() ? NaN : r.add(2 * Process.pointerSize).readFloat();
}

function applyUnity() {
  U.inApply = true;
  try {
    if (!U.ready) { resolveUnity(); U.ready = true; console.log('unity(' + unity.kind + '): timeScale resolved'); }
    const cur = readTS();
    if (!(Math.abs(cur - speed) < 0.001)) {
      setTS(speed);
      if (cur === cur || U.lastLog !== speed) {   // بدون getter ما نكرر نفس السطر في السجل
        console.log('timeScale ' + cur.toFixed(2) + ' -> ' + speed + ' (now ' + readTS().toFixed(2) + ')');
        U.lastLog = speed;
      }
    }
    U.ok = true; U.fails = 0; unityPending = false;
  } catch (e) {
    console.log('unity apply failed: ' + e);
    if (++U.fails >= 3) giveUp('apply failed');
  } finally {
    U.inApply = false;
  }
}

// نشغّل الضبط من الخيط الرئيسي للعبة (Unity ما يسمح بـ Time.timeScale من خيوط ثانية)
const tnames = {};
function nameOf(tid) {
  let n = tnames[tid];
  if (n === undefined) {
    try { n = File.readAllText('/proc/self/task/' + tid + '/comm').trim(); } catch (e) { n = ''; }
    tnames[tid] = n;
  }
  return n;
}
function onUnityCall(tid) {
  if (!U.mainTid) {
    if (nameOf(tid).indexOf('UnityMain') === 0) U.mainTid = tid;
    else if (Date.now() - unityPendingSince > 3000) {
      U.mainTid = tid;
      console.log('main thread guess tid=' + tid + ' name=' + nameOf(tid));
    }
  }
  if (tid === U.mainTid) applyUnity();
}

if (unity) {
  const hk = exp(unity.lib, unity.kind === 'il2cpp' ? 'il2cpp_runtime_invoke' : 'mono_runtime_invoke');
  if (hk) {
    Interceptor.attach(hk, {
      onEnter(args) {
        if (!unityPending || U.inApply || U.gaveUp) return;
        onUnityCall(this.threadId);
      }
    });
    console.log('unity hook: ' + (unity.kind === 'il2cpp' ? 'il2cpp_runtime_invoke' : 'mono_runtime_invoke'));
  } else {
    giveUp('no runtime_invoke export');
  }
  // نعيد التحقق كل ثانية (اللعبة ممكن ترجّع timeScale لـ 1 لما توقف/تفتح قائمة)
  setInterval(function () {
    if (U.gaveUp || !engaged) return;
    if (!unityPending) { unityPending = true; unityPendingSince = Date.now(); }
    else if (!U.ok && Date.now() - unityPendingSince > 8000) giveUp('no main-thread callback');
  }, 1000);
}

// ================= قراءة السرعة =================
function readSpeed() {
  let txt = null;
  try {
    txt = File.readAllText(PATH);
  } catch (e) {
    try { const f = new File(PATH, 'r'); txt = f.readLine(); f.close(); }
    catch (e2) {
      if (!failedRead) { failedRead = true; console.log('read speed file failed: ' + e2); }
      return;
    }
  }
  const v = parseFloat(txt);
  if (v >= 0.01 && v <= 100 && v !== speed) {
    speed = v;
    if (v !== 1.0) engaged = true;
    if (unity && !U.gaveUp && engaged) {
      if (!unityPending) unityPendingSince = Date.now();
      unityPending = true;
    }
    console.log('speed=' + speed);
  }
}
readSpeed();
setInterval(readSpeed, 300);

// ================= وضع libc (للألعاب غير Unity) =================
// كل استدعاء وقت نصنّف مصدره من عنوان الرجوع إلى: A تطبيق | J Java | S نظام | O أخرى (JIT/ذاكرة بلا ملف) | x نواة (ما تتزيّف أبداً).
// التصنيف من جدول /proc/self/maps نبنيه بأنفسنا: Process.findModuleByAddress كان ياخذ قفل اللودر (dl_iterate_phdr) داخل الهوك،
// ولو خيط ثاني يحمّل مكتبة (وبنّائها تستدعي clock_gettime) يصير قفل متبادل فتعلق اللعبة/تكرّش.
const SKIP_MOD = /^lib(eossdk|fmod|curl|ssl|crypto|websockets|firebase|crashlytics|sentry|agora|okhttp|conscrypt)/i;
const gameCache = new Map();
function isGamePath(p) {
  return p.indexOf('/data/app/') === 0 || p.indexOf('/data/data/') === 0 || p.indexOf('/data/user/') === 0;
}
// Java: JNI لـ System.nanoTime و SystemClock، وكود Java المترجم للتطبيق (odex/oat/vdex)
const JAVA_MODS = /^(libopenjdk|libopenjdkjvm|libjavacore|libandroid_runtime)\.so$/;
const JAVA_CODE = /\.(odex|oat|vdex|art)$/;
// نواة النظام: حتى لو اخترت System ما نزيّف وقتها. ART/libc/اللودر يتعطلون، ومكتبات الرسوم (libgui/EGL/درايفر GPU)
// تمرّر ختم وقت الإطار لـ SurfaceFlinger: ختم مزيّف قدّام الحقيقي = الإطارات تتأجل وتتجمد اللعبة.
const CORE_PATH = /^\/(vendor|odm)\//;
const CORE_APEX = /^\/apex\/com\.android\.(runtime|art|i18n|conscrypt)\//;
const CORE_NAME = /^(libc|libm|libdl|libc\+\+|libart.*|libdexfile.*|libnativeloader|libnativebridge|libnativehelper|libbase|libcutils|libutils|liblog|libbinder.*|libgui|libui|libEGL.*|libGLES.*|libvulkan.*|libhwui|libandroid|libnativewindow|libsync|libhardware|libhidl.*|libgralloc.*|libandroidfw)\.so$|^linker(64)?$/i;
function classify(path) {
  if (!path || path.charAt(0) !== '/' || path.indexOf('/memfd:') === 0) return 'O';
  const name = path.substring(path.lastIndexOf('/') + 1);
  if (isGamePath(path)) {
    if (JAVA_CODE.test(name)) return 'J';
    if (SKIP_MOD.test(name)) return 'x';        // صوت/شبكة/SDK خارجي: وقت حقيقي دايماً
    return 'A';
  }
  if (JAVA_MODS.test(name)) return 'J';
  if (CORE_PATH.test(path) || CORE_APEX.test(path) || CORE_NAME.test(name)) return 'x';
  return 'S';
}
let ranges = [];             // [[بداية، نهاية، تصنيف]] مرتّبة، للكود التنفيذي فقط
let rangesAt = 0, rangesSig = '';
const MAPS_RE = /^([0-9a-f]+)-([0-9a-f]+)\s+(\S{4})\s+\S+\s+\S+\s+\S+\s*(.*)$/;
function loadRanges() {
  rangesAt = Date.now();
  let txt;
  try { txt = File.readAllText('/proc/self/maps'); } catch (e) { return; }
  const out = [];
  const lines = txt.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const m = MAPS_RE.exec(lines[i]);
    if (!m || m[3].charAt(2) !== 'x') continue;
    const s = parseInt(m[1], 16), e = parseInt(m[2], 16), code = classify(m[4]);
    const last = out.length ? out[out.length - 1] : null;
    if (last && last[1] === s && last[2] === code) last[1] = e; else out.push([s, e, code]);
  }
  const sig = out.length + ':' + (out.length ? out[out.length - 1][1] : 0);
  ranges = out;
  if (sig !== rangesSig) { rangesSig = sig; gameCache.clear(); }
}
function findRange(a) {
  let lo = 0, hi = ranges.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1, r = ranges[mid];
    if (a < r[0]) hi = mid - 1; else if (a >= r[1]) lo = mid + 1; else return r[2];
  }
  return null;
}
function catOf(ra) {
  const key = ra.toString();
  const hit = gameCache.get(key);
  if (hit !== undefined) return hit;
  const a = parseInt(key, 16);
  let r = findRange(a);
  if (r === null && Date.now() - rangesAt > 300) { loadRanges(); r = findRange(a); }
  const v = r === null ? 'O' : r;
  if (gameCache.size > 50000) gameCache.clear();
  gameCache.set(key, v);
  return v;
}
loadRanges();
setInterval(loadRanges, 2000);

let catOn = { A: true, J: false, S: false, O: false };
let catsTxt = '';
const touched = { A: false, J: false, S: false, O: false };   // مصدر تزيّف مرة: يبقى على ساعته المزيّفة (يكمل بسرعة 1x) بدل ما يقفز للحقيقي
function readCats() {
  try {
    const t = File.readAllText('/data/local/tmp/cats.txt').trim();
    if (t === catsTxt) return;
    catsTxt = t;
    catOn = { A: t.indexOf('A') >= 0, J: t.indexOf('J') >= 0, S: t.indexOf('S') >= 0, O: t.indexOf('O') >= 0 };
    console.log('cats=' + t);
  } catch (e) {}
}
readCats();
setInterval(readCats, 500);
// سرعة المصدر: المختار يتسرّع، وغير المختار يمشي بسرعة 1 (لكن من نفس ساعته فما يقفز الوقت لما تبدّل المصدر والحاقن حيّ)
function spFor(c) { return catOn[c] ? speed : 1; }

// ---- كشف المصادر النشطة: كم مرة بالثانية كل مصدر يقرأ الوقت (clock_gettime / gettimeofday). التطبيق يقرأ الملف ويلوّن المربعات.
const SEEN_PATH = '/data/local/tmp/seen.txt';
const seen = { A: 0, J: 0, S: 0, O: 0 };
let seenTick = Date.now(), seenFail = false, seenLogs = 0;
function writeSeen(t) {
  try { File.writeAllText(SEEN_PATH, t + '\n'); return; } catch (e) {}
  try { const f = new File(SEEN_PATH, 'w'); f.write(t + '\n'); f.close(); }
  catch (e2) { if (!seenFail) { seenFail = true; console.log('seen write failed: ' + e2); } }
}
setInterval(function () {
  const now = Date.now();
  const dt = Math.max(0.2, (now - seenTick) / 1000);
  seenTick = now;
  const txt = 'A=' + Math.round(seen.A / dt) + ' J=' + Math.round(seen.J / dt) + ' S=' + Math.round(seen.S / dt) + ' O=' + Math.round(seen.O / dt);
  seen.A = seen.J = seen.S = seen.O = 0;
  if (seenLogs++ < 3) console.log('seen: ' + txt);
  writeSeen(txt);
}, 1000);

// خيوط ومكتبات ما تخص منطق اللعبة (صوت، شبكة، SDK خارجي): نتركها على الوقت الحقيقي
// لأن تسريع ساعتها وتقصير نومها يخلي هذي الخيوط تلف أسرع بعدة أضعاف وتاكل المعالج (دروب فريم) وتخرّب مهلات الشبكة.
const SKIP_THREAD = /FMOD|HttpManager|FAsyncW|Libwebsockets|TBBG|OkHttp|Firebase|Crashlytics|AudioTrack|AudioOut/i;
const thrInfo = new Map();
function threadSkipped(tid) {
  let e = thrInfo.get(tid);
  if (e === undefined) {
    if (thrInfo.size > 5000) thrInfo.clear();
    e = { skip: false, n: 0 };
    thrInfo.set(tid, e);
  }
  if (e.n++ % 500 === 0) {            // نعيد قراءة الاسم كل 500 استدعاء (Unity تسمّي الخيوط بعد إنشائها)
    delete tnames[tid];
    e.skip = SKIP_THREAD.test(nameOf(tid));
  }
  return e.skip;
}
// يرجّع حرف المصدر لو لازم نزيّف هالاستدعاء، وإلا null. count=true يعدّ الاستدعاء للكشف (حتى قبل التسريع).
function pick(ra, tid, count) {
  const c = catOf(ra);
  if (count) seen[c === 'x' ? 'S' : c]++;
  if (c === 'x' || !engaged || !useLibc) return null;
  if (!catOn[c] && !touched[c]) return null;
  if (threadSkipped(tid)) return null;
  if (catOn[c]) touched[c] = true;
  return c;
}

// الوقت المزيّف: يحافظ على الاستمرارية لما تتغير السرعة، ولا يرجع للخلف أبداً
const st = {};
function virt(key, real, sp) {
  let s = st[key];
  if (!s) { s = { r: real, v: real, sp: sp, last: 0 }; st[key] = s; }
  if (s.sp !== sp) {
    s.v = s.v + (real - s.r) * s.sp;
    s.r = real;
    s.sp = sp;
  }
  let v = s.v + (real - s.r) * s.sp;
  if (v < s.last) v = s.last;
  s.last = v;
  return v;
}
// يقسم ثواني عشرية إلى [ثواني, كسر] والكسر لا يتجاوز scale-1 (تفادي tv_nsec = 1e9)
function split(v, scale) {
  const sec = Math.floor(v);
  let f = Math.floor((v - sec) * scale);
  if (f > scale - 1) f = scale - 1;
  if (f < 0) f = 0;
  return [sec, f];
}

const cg = findExp('clock_gettime');
if (cg) Interceptor.attach(cg, {
  onEnter(a) {
    this.cat = pick(this.returnAddress, this.threadId, true);
    if (this.cat !== null) { this.clk = a[0].toInt32(); this.ts = a[1]; }
  },
  onLeave(ret) {
    const c = this.cat;
    if (c === null || c === undefined) return;
    try {
      if (ret.toInt32() !== 0) return;
      const sec = Number(this.ts.readS64());
      const ns = Number(this.ts.add(8).readS64());
      const r = split(virt(c + this.clk, sec + ns / 1e9, spFor(c)), 1e9);
      this.ts.writeS64(r[0]);
      this.ts.add(8).writeS64(r[1]);
      if (calls++ < 3) console.log('clock_gettime hooked, cat=' + c + ' clk=' + this.clk + ' speed=' + speed);
    } catch (e) { logHookError(e); }
  }
});

const gt = findExp('gettimeofday');
if (gt) Interceptor.attach(gt, {
  onEnter(a) {
    this.cat = pick(this.returnAddress, this.threadId, true);
    if (this.cat !== null) this.tv = a[0];
  },
  onLeave(ret) {
    const c = this.cat;
    if (c === null || c === undefined) return;
    try {
      if (ret.toInt32() !== 0 || this.tv.isNull()) return;
      const sec = Number(this.tv.readS64());
      const us = Number(this.tv.add(8).readS64());
      const r = split(virt(c + '0', sec + us / 1e6, spFor(c)), 1e6);
      this.tv.writeS64(r[0]);
      this.tv.add(8).writeS64(r[1]);
    } catch (e) { logHookError(e); }
  }
});

// مهلات الانتظار المطلقة: اللعبة تحسبها من الوقت المزيّف لكن النواة تقارنها بالحقيقي.
// الحقيقي = الآن الحقيقي + (الموعد - الآن المزيّف) / السرعة
const realCg = cg ? new NativeFunction(cg, 'int', ['int', 'pointer']) : null;
let longWaitLogs = 0;
const zeroBy = {};            // تشخيص: كم انتظار انتهى فوراً (الموعد فات) لكل دالة، يتصفّر كل 5 ثواني
function pickClk(ab, c) {
  if (ab >= 1e9) return 0;                     // قيمة بحجم عصر يونكس = REALTIME
  // أقل من ذلك: MONOTONIC أو BOOTTIME، نختار الساعة اللي وقتها المزيّف أقرب للموعد
  const t1 = Memory.alloc(16), t7 = Memory.alloc(16);
  if (realCg(1, t1) !== 0 || realCg(7, t7) !== 0) return 1;
  const r1 = Number(t1.readS64()) + Number(t1.add(8).readS64()) / 1e9;
  const r7 = Number(t7.readS64()) + Number(t7.add(8).readS64()) / 1e9;
  const sp = spFor(c);
  return Math.abs(ab - virt(c + '1', r1, sp)) <= Math.abs(ab - virt(c + '7', r7, sp)) ? 1 : 7;
}
function fixAbs(ctx, args, idx, clkHint, fname, c) {
  try {
    const p = args[idx];
    if (!realCg || p.isNull()) return;
    const ab = Number(p.readS64()) + Number(p.add(8).readS64()) / 1e9;
    const clk = clkHint !== undefined && clkHint !== null ? clkHint : pickClk(ab, c);
    const t = Memory.alloc(16);
    if (realCg(clk, t) !== 0) return;
    const rn = Number(t.readS64()) + Number(t.add(8).readS64()) / 1e9;
    const sp = spFor(c);
    let remain = ab - virt(c + clk, rn, sp);
    if (remain < 0) { remain = 0; const zk = fname || '?'; zeroBy[zk] = (zeroBy[zk] || 0) + 1; }
    if (remain > 3 && longWaitLogs++ < 15) console.log('long wait: ' + (fname || '?') + ' cat=' + c + ' clk=' + clk + ' remain=' + remain.toFixed(1) + 's speed=' + speed);
    const out = split(rn + remain / sp, 1e9);
    t.writeS64(out[0]);
    t.add(8).writeS64(out[1]);
    args[idx] = t;
    ctx.keep = t;                               // يبقي المخزن حيّ لين يرجع الاستدعاء
  } catch (e) { logHookError(e); }
}
// نوم نسبي: المدة تُحسب من الوقت المزيّف لكنها تنتظر بالحقيقي، فنقسمها على السرعة
function fixRel(ctx, args, idx, c) {
  try {
    const p = args[idx];
    if (p.isNull()) return;
    const d = Number(p.readS64()) + Number(p.add(8).readS64()) / 1e9;
    const t = Memory.alloc(16);
    const out = split(d / spFor(c), 1e9);
    t.writeS64(out[0]);
    t.add(8).writeS64(out[1]);
    args[idx] = t;
    ctx.keep = t;
  } catch (e) { logHookError(e); }
}
if (FIX_WAITS) {
  // [الدالة، مكان مؤشر الموعد، الساعة: رقم ثابت أو {arg: مكان باراميتر الساعة} أو null = نخمّن]
  [['pthread_cond_timedwait', 2, null], ['pthread_cond_timedwait_monotonic_np', 2, 1],
   ['sem_timedwait', 1, null], ['sem_timedwait_monotonic_np', 1, 1],
   ['pthread_mutex_timedlock', 1, null], ['pthread_mutex_timedlock_monotonic_np', 1, 1],
   ['pthread_rwlock_timedrdlock', 1, null], ['pthread_rwlock_timedwrlock', 1, null],
   ['pthread_cond_clockwait', 3, { arg: 2 }], ['sem_clockwait', 2, { arg: 1 }],
   ['pthread_mutex_clocklock', 2, { arg: 1 }],
   ['pthread_rwlock_clockrdlock', 2, { arg: 1 }], ['pthread_rwlock_clockwrlock', 2, { arg: 1 }]
  ].forEach(function (e) {
    const a = findExp(e[0]);
    if (!a) return;
    Interceptor.attach(a, {
      onEnter(args) {
        const c = pick(this.returnAddress, this.threadId, false);
        if (c === null) return;
        let clk = e[2];
        if (clk !== null && typeof clk === 'object') clk = args[clk.arg].toInt32();
        fixAbs(this, args, e[1], clk, e[0], c);
      }
    });
    console.log(e[0] + ': hooked');
  });
}
// لو اللعبة علّقت: سطر "spin?" في السجل يعني خيوط تلف بدون ما تنام (انتظار موعده فات فيرجع فوراً) والدالة المسؤولة قدام الرقم
setInterval(function () {
  let tot = 0;
  const parts = [];
  Object.keys(zeroBy).forEach(function (k) { tot += zeroBy[k]; parts.push(k + '=' + zeroBy[k]); delete zeroBy[k]; });
  if (engaged && tot > 1000) console.log('spin? ' + tot + ' zero-length waits in 5s: ' + parts.join(' ') + ' | speed=' + speed + ' cats=' + catsTxt);
}, 5000);
if (FIX_SLEEPS) {
  const ns = findExp('nanosleep');
  if (ns) Interceptor.attach(ns, {
    onEnter(args) { const c = pick(this.returnAddress, this.threadId, false); if (c !== null) fixRel(this, args, 0, c); }
  });
  const us = findExp('usleep');
  if (us) Interceptor.attach(us, {
    onEnter(args) {
      const c = pick(this.returnAddress, this.threadId, false);
      if (c === null) return;
      try { args[0] = ptr(Math.max(0, Math.floor(args[0].toInt32() / spFor(c)))); } catch (e) { logHookError(e); }
    }
  });
  const cn = findExp('clock_nanosleep');
  if (cn) Interceptor.attach(cn, {
    onEnter(args) {
      const c = pick(this.returnAddress, this.threadId, false);
      if (c === null) return;
      if (args[1].toInt32() & 1) fixAbs(this, args, 2, args[0].toInt32(), 'clock_nanosleep', c);   // TIMER_ABSTIME
      else fixRel(this, args, 2, c);
    }
  });
  console.log('sleep hooks: ' + (ns ? 'nanosleep ' : '') + (us ? 'usleep ' : '') + (cn ? 'clock_nanosleep' : ''));
}

let presentFixes = 0;
// حماية الإطارات: Swappy داخل libunity يحسب وقت العرض من ساعة مزيّفة ويمرّره لـ eglPresentationTimeANDROID،
// فتتأجل الإطارات (SurfaceFlinger ينتظر الوقت الحقيقي) وتتجمد اللعبة. لو الختم قدّام الحقيقي بوضوح نرجّعه للحقيقي.
try {
  const egl = Process.findModuleByName('libEGL.so');
  const ep = egl ? exp(egl, 'eglPresentationTimeANDROID') : null;
  if (ep && realCg) {
    Interceptor.attach(ep, {
      onEnter(args) {
        try {
          if (!engaged || !useLibc) return;
          const c = catOf(this.returnAddress);
          if (c === 'x' || !touched[c]) return;
          const s = st[c + '1'];
          if (!s) return;
          const tNs = parseInt(args[2].toString(), 16);
          if (!(tNs > 0)) return;
          const t = Memory.alloc(16);
          if (realCg(1, t) !== 0) return;
          const rn = Number(t.readS64()) + Number(t.add(8).readS64()) / 1e9;
          const tSec = tNs / 1e9;
          if (tSec - rn <= 0.25) return;                       // ختم عادي (قريب من الآن)
          const mapped = s.r + (tSec - s.v) / s.sp;              // عكس الوقت المزيّف
          if (mapped >= rn - 0.5 && mapped <= rn + 1.0) {
            args[2] = ptr('0x' + Math.floor(mapped * 1e9).toString(16));
            if (presentFixes++ < 3) console.log('eglPresentationTime fixed (fake ahead by ' + (tSec - rn).toFixed(2) + 's)');
          }
        } catch (e) { logHookError(e); }
      }
    });
    console.log('eglPresentationTimeANDROID: hooked');
  }
} catch (e) { console.log('egl hook skipped: ' + e); }

// ================= تشخيص: من وين اللعبة تاخذ وقتها =================
// ما يغيّر أي شي، بس يعدّ الاستدعاءات: (الدالة / رقم الساعة) + (المكتبة اللي استدعتها) + [اسم الخيط].
// المكتبة اللي عليها * هي مكتبة اللعبة. الأرقام = استدعاء بالثانية خلال آخر 8 ثواني.
if (DIAG) (function () {
  const cnt = {};
  let tick = 0;
  const modCache = new Map();
  function modLabel(ra) {
    const k = ra.toString();
    let v = modCache.get(k);
    if (v !== undefined) return v;
    let m = null;
    try { m = Process.findModuleByAddress(ra); } catch (e) {}
    v = m ? (m.name + (isGamePath(m.path || '') ? '*' : '')) : '?';
    if (modCache.size > 20000) modCache.clear();
    modCache.set(k, v);
    return v;
  }
  function thr(tid) { return (nameOf(tid) || 't').replace(/\d+/g, '#'); }
  function hit(fn, extra, ctx) {
    const k = fn + (extra === undefined ? '' : '(' + extra + ')') + ' ' + modLabel(ctx.returnAddress) + ' [' + thr(ctx.threadId) + ']';
    cnt[k] = (cnt[k] || 0) + 1;
  }
  function findAny(name) {
    const a = findExp(name);
    if (a) return a;
    try {
      const mods = Process.enumerateModules();
      for (let i = 0; i < mods.length; i++) { const x = exp(mods[i], name); if (x) return x; }
    } catch (e) {}
    return null;
  }
  const found = [], missing = [];
  function watch(name, argFn) {
    const a = findAny(name);
    if (!a) { missing.push(name); return; }
    found.push(name);
    Interceptor.attach(a, {
      onEnter(args) {
        try {
          let x;
          if (argFn) { x = argFn(args); if (x === null) return; }
          hit(name, x, this);
        } catch (e) {}
      }
    });
  }
  const SYS = { 113: 'clock_gettime', 169: 'gettimeofday', 114: 'clock_getres', 101: 'nanosleep', 115: 'clock_nanosleep' };
  // مصادر الوقت
  watch('clock_gettime', function (a) { return a[0].toInt32(); });
  watch('gettimeofday');
  watch('time');
  watch('clock');
  watch('syscall', function (a) { const n = a[0].toInt32(); return SYS[n] ? 'sys:' + SYS[n] : null; });
  // مزامنة الإطارات والشاشة
  ['AChoreographer_getInstance', 'AChoreographer_postFrameCallback', 'AChoreographer_postFrameCallback64',
   'AChoreographer_postVsyncCallback', 'SwappyGL_swap', 'Swappy_swap', 'SwappyGL_setSwapIntervalNS',
   'SwappyVk_queuePresent', 'eglSwapBuffers', 'eglSwapBuffersWithDamageKHR', 'eglPresentationTimeANDROID',
   'vkQueuePresentKHR'].forEach(function (n) { watch(n); });
  // الانتظار والنوم (محدّد الإطارات غالباً يستخدمها)
  ['nanosleep', 'usleep', 'clock_nanosleep', 'pthread_cond_timedwait', 'pthread_cond_timedwait_monotonic_np',
   'sem_timedwait'].forEach(function (n) { watch(n); });
  // ساعة الصوت
  ['AAudioStream_getTimestamp', 'AAudioStream_getFramesRead', 'AAudioStream_getFramesWritten'].forEach(function (n) { watch(n); });

  try {
    const g = Process.enumerateModules().filter(function (m) { return isGamePath(m.path || ''); })
      .map(function (m) { return m.name; });
    console.log('DIAG game libs(' + g.length + '): ' + g.slice(0, 25).join(','));
  } catch (e) {}
  console.log('DIAG hooked: ' + found.join(','));
  console.log('DIAG missing: ' + missing.join(','));

  setInterval(function () {
    tick++;
    const keys = Object.keys(cnt);
    if (tick <= 6 || tick % 8 === 0) {
      keys.sort(function (a, b) { return cnt[b] - cnt[a]; });
      console.log('DIAG #' + tick + ' speed=' + speed + ' unity=' + (unity ? (U.gaveUp ? 'off' : 'on') : 'none'));
      for (let i = 0; i < keys.length && i < 12; i++) console.log('  ' + (cnt[keys[i]] / 8).toFixed(0) + '/s ' + keys[i]);
    }
    for (let i = 0; i < keys.length; i++) delete cnt[keys[i]];
  }, 8000);
})();

console.log('speed hook ready');
