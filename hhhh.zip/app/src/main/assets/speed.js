'use strict';
// يغيّر الوقت اللي تشوفه كود اللعبة فقط (مو النظام ولا ART ولا Frida نفسه).
// السرعة تُقرأ من الملف كل 300ms.
const PATH = '/data/local/tmp/speed.txt';
const FIX_WAITS = true;   // يحوّل مهلات الانتظار المطلقة (cond/sem/mutex) من الوقت المزيّف إلى الحقيقي
let speed = 1.0;
let engaged = false;      // يصير true أول ما تتغير السرعة عن 1.0؛ قبلها ما نلمس أي شي
let calls = 0, failedRead = false, failedHook = false;

function logHookError(e) {
  if (!failedHook) { failedHook = true; console.log('hook error: ' + e); }
}

function readSpeed() {
  let txt = null;
  try {
    txt = File.readAllText(PATH);
  } catch (e) {
    try { const f = new File(PATH, 'r'); txt = f.readLine(); f.close(); }
    catch (e2) {
      if (!failedRead) { failedRead = true; console.log('read speed file failed: ' + e2); }
      return;
    }
  }
  const v = parseFloat(txt);
  if (v > 0 && v <= 20 && v !== speed) {
    speed = v;
    if (v !== 1.0) engaged = true;
    console.log('speed=' + speed);
  }
}
readSpeed();
setInterval(readSpeed, 300);

function findExp(name) {
  try { if (Module.findExportByName) { const a = Module.findExportByName(null, name); if (a) return a; } } catch (e) {}
  try { const m = Process.getModuleByName('libc.so');
        if (m.findExportByName) { const a = m.findExportByName(name); if (a) return a; }
        if (m.getExportByName) return m.getExportByName(name); } catch (e) {}
  return null;
}

// ---- من هو "كود اللعبة"؟ المكتبات اللي مساراتها تحت /data/app أو /data/data أو /data/user.
// ART والنظام وFrida خارجها، فيشوفون الوقت الحقيقي دايماً (هذا اللي يمنع التجمد بعد دقائق).
const gameCache = new Map();
function isGamePath(p) {
  return p.indexOf('/data/app/') === 0 || p.indexOf('/data/data/') === 0 || p.indexOf('/data/user/') === 0;
}
function callerIsGame(ra) {
  const key = ra.toString();
  const hit = gameCache.get(key);
  if (hit !== undefined) return hit;
  const m = Process.findModuleByAddress(ra);
  if (m === null) return false;               // ذاكرة بلا مكتبة (JIT وغيره): نعتبره نظام ولا نخزّنه
  if (gameCache.size > 50000) gameCache.clear();
  const v = isGamePath(m.path || '');
  gameCache.set(key, v);
  return v;
}

// ---- الوقت المزيّف: يحافظ على الاستمرارية لما تتغير السرعة
const st = {};
function virt(key, real) {
  let s = st[key];
  if (!s) { s = { r: real, v: real, sp: speed }; st[key] = s; }
  if (s.sp !== speed) {
    s.v = s.v + (real - s.r) * s.sp;
    s.r = real;
    s.sp = speed;
  }
  return s.v + (real - s.r) * s.sp;
}
// يقسم ثواني عشرية إلى [ثواني, كسر] والكسر لا يتجاوز scale-1 (تفادي tv_nsec = 1e9)
function split(v, scale) {
  const sec = Math.floor(v);
  let f = Math.floor((v - sec) * scale);
  if (f > scale - 1) f = scale - 1;
  if (f < 0) f = 0;
  return [sec, f];
}

const cg = findExp('clock_gettime');
if (cg) Interceptor.attach(cg, {
  onEnter(a) {
    this.go = engaged && callerIsGame(this.returnAddress);
    if (this.go) { this.clk = a[0].toInt32(); this.ts = a[1]; }
  },
  onLeave(ret) {
    if (!this.go) return;
    try {
      if (ret.toInt32() !== 0) return;
      const sec = Number(this.ts.readS64());
      const ns = Number(this.ts.add(8).readS64());
      const r = split(virt('c' + this.clk, sec + ns / 1e9), 1e9);
      this.ts.writeS64(r[0]);
      this.ts.add(8).writeS64(r[1]);
      if (calls++ < 3) console.log('clock_gettime hooked, clk=' + this.clk + ' speed=' + speed);
    } catch (e) { logHookError(e); }
  }
});
console.log('clock_gettime: ' + cg);

const gt = findExp('gettimeofday');
if (gt) Interceptor.attach(gt, {
  onEnter(a) {
    this.go = engaged && callerIsGame(this.returnAddress);
    if (this.go) this.tv = a[0];
  },
  onLeave(ret) {
    if (!this.go) return;
    try {
      if (ret.toInt32() !== 0 || this.tv.isNull()) return;
      const sec = Number(this.tv.readS64());
      const us = Number(this.tv.add(8).readS64());
      const r = split(virt('tod', sec + us / 1e6), 1e6);
      this.tv.writeS64(r[0]);
      this.tv.add(8).writeS64(r[1]);
    } catch (e) { logHookError(e); }
  }
});
console.log('gettimeofday: ' + gt);

// ---- مهلات الانتظار المطلقة: اللعبة تحسبها من الوقت المزيّف لكن النواة تقارنها بالحقيقي.
// نحوّل الموعد: الحقيقي = الآن الحقيقي + (الموعد - الآن المزيّف) / السرعة
const realCg = cg ? new NativeFunction(cg, 'int', ['int', 'pointer']) : null;
function fixAbs(ctx, args, idx) {
  try {
    const p = args[idx];
    if (!realCg || p.isNull()) return;
    const ab = Number(p.readS64()) + Number(p.add(8).readS64()) / 1e9;
    const clk = ab < 1e9 ? 1 : 0;              // قيمة صغيرة = CLOCK_MONOTONIC، كبيرة = CLOCK_REALTIME
    const t = Memory.alloc(16);
    if (realCg(clk, t) !== 0) return;
    const rn = Number(t.readS64()) + Number(t.add(8).readS64()) / 1e9;
    let remain = ab - virt('c' + clk, rn);
    if (remain < 0) remain = 0;
    const out = split(rn + remain / speed, 1e9);
    t.writeS64(out[0]);
    t.add(8).writeS64(out[1]);
    args[idx] = t;
    ctx.keep = t;                               // يبقي المخزن حيّ لين يرجع الاستدعاء
  } catch (e) { logHookError(e); }
}
if (FIX_WAITS) {
  [['pthread_cond_timedwait', 2], ['pthread_cond_timedwait_monotonic_np', 2],
   ['sem_timedwait', 1], ['pthread_mutex_timedlock', 1],
   ['pthread_mutex_timedlock_monotonic_np', 1]].forEach(function (e) {
    const a = findExp(e[0]);
    if (!a) return;
    Interceptor.attach(a, {
      onEnter(args) { if (engaged && callerIsGame(this.returnAddress)) fixAbs(this, args, e[1]); }
    });
    console.log(e[0] + ': hooked');
  });
}
console.log('speed hook ready');
