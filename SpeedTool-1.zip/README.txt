البناء: افتح المجلد في Android Studio ثم Build > Build APK.
المتطلبات على الجوال: روت + ملف frida-inject لنفس إصدار frida (arm64) داخل /data/local/tmp.
لو اللعبة ما تتأثر: خلّ SELinux على Permissive، وافحص /data/local/tmp/frida.log.
