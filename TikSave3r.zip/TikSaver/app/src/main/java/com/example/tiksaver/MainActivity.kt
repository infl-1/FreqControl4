package com.example.tiksaver

import android.Manifest
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONTokener
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume

class MainActivity : AppCompatActivity() {

    private lateinit var linkInput: EditText
    private lateinit var downloadBtn: Button
    private lateinit var updateBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var webContainer: FrameLayout
    private lateinit var photoPanel: LinearLayout
    private lateinit var photoGrid: GridLayout
    private lateinit var selCount: TextView
    private lateinit var selectAllBtn: Button
    private lateinit var clearAllBtn: Button
    private lateinit var saveSelectedBtn: Button
    private lateinit var cancelPickBtn: Button

    private var ready = false
    private var photoRunning = false
    private var lastResolvedUrl: String? = null
    private var photoDebug: String = ""
    private val cookies = mutableMapOf<String, String>()

    private val urlRegex = Regex("""https?://\S+""")
    private val supportedDomains = listOf(
        "tiktok.com",
        "snapchat.com",
        "x.com", "twitter.com", "t.co",
        "youtube.com", "youtu.be"
    )

    private val userAgent =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    // سكربت يقرأ صور البوست من بيانات الصفحة داخل الـ WebView
    private val extractJs = """
        (function(){
          try {
            var e = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
            if (!e) return 'NODATA';
            var d = JSON.parse(e.textContent);
            function f(o){
              if (!o || typeof o !== 'object') return null;
              if (o.imagePost && o.imagePost.images && o.imagePost.images.length) return o;
              for (var k in o) { var r = f(o[k]); if (r) return r; }
              return null;
            }
            var it = f(d);
            if (!it) return 'NOIMG';
            var urls = it.imagePost.images.map(function(im){
              var l = (im.imageURL && im.imageURL.urlList) || (im.displayImage && im.displayImage.urlList) || [];
              var j = l.filter(function(u){ return u.indexOf('.jpeg') >= 0 || u.indexOf('.jpg') >= 0; });
              return j[0] || l[0] || '';
            });
            return JSON.stringify({id: String(it.id || ''), urls: urls});
          } catch (x) { return 'ERR:' + x; }
        })()
    """.trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        linkInput = findViewById(R.id.linkInput)
        downloadBtn = findViewById(R.id.downloadBtn)
        updateBtn = findViewById(R.id.updateBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        webContainer = findViewById(R.id.webContainer)
        photoPanel = findViewById(R.id.photoPanel)
        photoGrid = findViewById(R.id.photoGrid)
        selCount = findViewById(R.id.selCount)
        selectAllBtn = findViewById(R.id.selectAllBtn)
        clearAllBtn = findViewById(R.id.clearAllBtn)
        saveSelectedBtn = findViewById(R.id.saveSelectedBtn)
        cancelPickBtn = findViewById(R.id.cancelPickBtn)

        findViewById<Button>(R.id.pasteBtn).setOnClickListener { pasteFromClipboard() }
        downloadBtn.setOnClickListener { startDownload() }
        updateBtn.setOnClickListener { updateEngine() }

        // إذن الإشعارات (أندرويد 13+) عشان يظهر تقدم التحميل بالخلفية
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        // نتابع حالة التحميل اللي تشتغل في الخدمة
        lifecycleScope.launch {
            DownloadState.state.collect { render(it) }
        }

        handleShareIntent(intent)
        initEngine()
    }

    // لو التطبيق مفتوح وجاء رابط جديد من "مشاركة" ما نفتح نسخة ثانية، نستخدم نفس الشاشة
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    private fun handleShareIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT))?.let { linkInput.setText(it) }
        }
    }

    private fun render(s: DownloadState.State) {
        if (s.running) {
            busy(true, determinate = true)
            progress.progress = s.progress
            status.text = s.message
        } else if (s.message.isNotEmpty() && !photoRunning) {
            busy(false)
            status.text = s.message
        }
    }

    // ---------- المحرك ----------

    private fun initEngine() {
        busy(true)
        status.text = "جاري تجهيز المحرك (أول مرة فقط، ممكن ياخذ شوي)..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().init(applicationContext)
                    FFmpeg.getInstance().init(applicationContext)
                }
                ready = true
                status.text = "جاهز ✅"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status.text = "تعذر تجهيز المحرك: ${e.message}"
            } finally {
                busy(DownloadState.state.value.running)
            }
        }
    }

    private fun updateEngine() {
        busy(true)
        status.text = "جاري تحديث المحرك..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().updateYoutubeDL(applicationContext, YoutubeDL.UpdateChannel.STABLE)
                }
                status.text = "تم تحديث المحرك ✅"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status.text = "فشل التحديث، تأكد من الإنترنت"
            } finally {
                busy(DownloadState.state.value.running)
            }
        }
    }

    // ---------- التحميل ----------

    private fun startDownload() {
        val url = extractUrl(linkInput.text.toString())
        if (url == null || !isSupported(url)) {
            status.text = "الرابط غير مدعوم. المدعوم: تيك توك، سناب شات، X، يوتيوب"
            return
        }
        linkInput.setText(url)
        lastResolvedUrl = null
        photoDebug = ""
        busy(true, determinate = true)
        status.text = "جاري التحميل..."

        lifecycleScope.launch {
            var serviceStarted = false
            try {
                // تيك توك: نفتح البوست في WebView ونشوف إذا كان صور (سلايد شو)
                val photoPost = if (isTikTok(url)) {
                    photoRunning = true
                    findPhotoPostWebView(url)
                } else null

                if (photoPost != null) {
                    // ننزل الصور للذاكرة، نعرضها لك تختار منها، ثم نحفظ المحدد فقط
                    val images = withContext(Dispatchers.IO) { fetchImages(photoPost) }
                    if (images.all { it == null }) throw IOException("تعذر تحميل صور البوست")
                    val chosen = pickImages(images)
                    if (chosen == null || chosen.isEmpty()) {
                        status.text = "تم الإلغاء"
                    } else {
                        busy(true, determinate = true)
                        status.text = "جاري حفظ ${chosen.size} صور..."
                        val saved = withContext(Dispatchers.IO) { saveImages(photoPost, images, chosen) }
                        status.text = "تم حفظ $saved صور في المعرض (Pictures/TikSaver) ✅"
                    }
                } else {
                    // الفيديو يتحمل في خدمة أمامية، يكمل حتى لو طلعت من التطبيق
                    val hint = if (photoDebug == "VIDEO") "" else photoDebug
                    DownloadService.start(this@MainActivity, url, hint)
                    serviceStarted = true
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val reason = e.message?.lineSequence()?.firstOrNull { it.isNotBlank() }?.take(160)
                    ?: e.javaClass.simpleName
                val photoLine = if (photoDebug.isNotEmpty()) "\n[صور] $photoDebug" else ""
                status.text = "فشل التحميل.$photoLine\n[تفاصيل] $reason"
            } finally {
                photoRunning = false
                if (!serviceStarted) busy(false)
            }
        }
    }

    // ---------- بوستات الصور (تيك توك) ----------

    private class PhotoPost(val id: String, val imageUrls: List<String>)

    private class HttpResult(val body: ByteArray, val finalUrl: String)

    /**
     * يفتح البوست داخل WebView (متصفح حقيقي) ويقرأ الصور من بيانات الصفحة.
     * لو ظهر تحقق (كابتشا) يظهر الـ WebView تحت عشان تحله بنفسك.
     * يرجع null إذا كان فيديو عادي أو تعذر القراءة (والسبب في photoDebug).
     */
    private suspend fun findPhotoPostWebView(url: String): PhotoPost? {
        photoDebug = ""
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        CookieManager.getInstance().setAcceptCookie(true)

        var finished = false
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme?.lowercase()
                return scheme != "http" && scheme != "https"
            }

            override fun onPageStarted(view: WebView?, u: String?, favicon: Bitmap?) {
                finished = false
            }

            override fun onPageFinished(view: WebView?, u: String?) {
                if (u != null) lastResolvedUrl = u
                finished = true
            }
        }

        webContainer.removeAllViews()
        webContainer.addView(
            wv,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        try {
            wv.loadUrl(url)
            status.text = "جاري فتح البوست..."
            val start = SystemClock.elapsedRealtime()
            var shown = false

            while (true) {
                val isPhotoUrl = lastResolvedUrl?.contains("/photo/") == true
                val limit = if (isPhotoUrl) 75_000L else 20_000L
                if (SystemClock.elapsedRealtime() - start > limit) break
                delay(800)
                if (!finished) continue

                val result = evalJs(wv, extractJs)
                when {
                    result.startsWith("{") -> {
                        val obj = JSONObject(result)
                        val arr = obj.getJSONArray("urls")
                        val urls = (0 until arr.length()).map { arr.getString(it) }.filter { it.startsWith("http") }
                        if (urls.isEmpty()) {
                            photoDebug = "imagePost بدون روابط صور"
                            return null
                        }
                        photoDebug = "ok"
                        val id = obj.optString("id", "").ifEmpty { System.currentTimeMillis().toString() }
                        return PhotoPost(id, urls)
                    }
                    result == "NOIMG" -> {
                        photoDebug = "VIDEO"
                        return null
                    }
                    result.startsWith("ERR") -> {
                        photoDebug = result.take(120)
                        return null
                    }
                    else -> {
                        // NODATA: ممكن تحقق (كابتشا) أو الصفحة لسا تحمل
                        if (isPhotoUrl && !shown && SystemClock.elapsedRealtime() - start > 8_000) {
                            shown = true
                            setWebHeight(420)
                            status.text = "إذا ظهر تحقق (كابتشا) في الصفحة تحت، حلّه وانتظر..."
                        }
                    }
                }
            }
            photoDebug = "انتهى الوقت بدون بيانات (تحقق/كابتشا؟)"
            return null
        } finally {
            setWebHeight(1)
            webContainer.removeAllViews()
            wv.stopLoading()
            wv.destroy()
        }
    }

    private suspend fun evalJs(wv: WebView, js: String): String = suspendCancellableCoroutine { cont ->
        wv.evaluateJavascript(js) { raw ->
            val text = try {
                (JSONTokener(raw ?: "null").nextValue() as? String) ?: ""
            } catch (e: Exception) {
                ""
            }
            if (cont.isActive) cont.resume(text)
        }
    }

    private fun setWebHeight(dp: Int) {
        val lp = webContainer.layoutParams
        lp.height = (dp * resources.displayMetrics.density).toInt()
        webContainer.layoutParams = lp
    }

    /** ينزل كل صور البوست للذاكرة (للمعاينة). الصورة اللي تفشل ترجع null */
    private fun fetchImages(post: PhotoPost): List<ByteArray?> {
        cookies.clear()
        val total = post.imageUrls.size
        return post.imageUrls.mapIndexed { i, imageUrl ->
            val bytes = try {
                httpGet(imageUrl, referer = "https://www.tiktok.com/").body
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                progress.progress = ((i + 1) * 100) / total
                status.text = "جاري تجهيز المعاينة (${i + 1}/$total)..."
            }
            bytes
        }
    }

    /**
     * يعرض الصور في شبكة، كل صورة تنضغط عليها تحدد/تلغي. يرجع أرقام الصور المحددة أو null عند الإلغاء.
     */
    private suspend fun pickImages(images: List<ByteArray?>): List<Int>? =
        suspendCancellableCoroutine { cont ->
            val items = images.withIndex().filter { it.value != null }
            val selected = BooleanArray(items.size) { true }
            val dims = ArrayList<View>()
            val checks = ArrayList<View>()
            val size = (resources.displayMetrics.widthPixels - dp(48)) / 3 - dp(4)

            fun refresh() {
                var count = 0
                for (i in selected.indices) {
                    dims[i].visibility = if (selected[i]) View.GONE else View.VISIBLE
                    checks[i].visibility = if (selected[i]) View.VISIBLE else View.GONE
                    if (selected[i]) count++
                }
                selCount.text = "المحدد: $count من ${items.size}"
                saveSelectedBtn.isEnabled = count > 0
            }

            fun complete(result: List<Int>?) {
                photoPanel.visibility = View.GONE
                photoGrid.removeAllViews()
                if (cont.isActive) cont.resume(result)
            }

            photoGrid.removeAllViews()
            items.forEachIndexed { pos, item ->
                val cell = FrameLayout(this)

                val img = ImageView(this)
                img.scaleType = ImageView.ScaleType.CENTER_CROP
                img.setBackgroundColor(Color.DKGRAY)
                decodeThumb(item.value!!, size)?.let { img.setImageBitmap(it) }
                cell.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

                val dim = View(this)
                dim.setBackgroundColor(0xAA000000.toInt())
                cell.addView(dim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

                val check = TextView(this)
                check.text = "✓"
                check.textSize = 16f
                check.gravity = Gravity.CENTER
                check.setTextColor(Color.WHITE)
                check.setBackgroundColor(0xFF2E7D32.toInt())
                val checkLp = FrameLayout.LayoutParams(dp(28), dp(28), Gravity.TOP or Gravity.START)
                checkLp.setMargins(dp(4), dp(4), dp(4), dp(4))
                cell.addView(check, checkLp)

                dims.add(dim)
                checks.add(check)
                cell.setOnClickListener {
                    selected[pos] = !selected[pos]
                    refresh()
                }

                val lp = GridLayout.LayoutParams()
                lp.width = size
                lp.height = size
                lp.setMargins(dp(2), dp(2), dp(2), dp(2))
                photoGrid.addView(cell, lp)
            }

            selectAllBtn.setOnClickListener {
                selected.fill(true)
                refresh()
            }
            clearAllBtn.setOnClickListener {
                selected.fill(false)
                refresh()
            }
            saveSelectedBtn.setOnClickListener {
                complete(items.filterIndexed { i, _ -> selected[i] }.map { it.index })
            }
            cancelPickBtn.setOnClickListener { complete(null) }
            cont.invokeOnCancellation { photoPanel.post { photoPanel.visibility = View.GONE } }

            progress.visibility = View.GONE
            status.text = "اختر الصور اللي تبيها:"
            photoPanel.visibility = View.VISIBLE
            refresh()
        }

    private fun decodeThumb(bytes: ByteArray, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= target && bounds.outHeight / (sample * 2) >= target) {
            sample *= 2
        }
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    /** يحفظ الصور المحددة فقط في المعرض */
    private fun saveImages(post: PhotoPost, images: List<ByteArray?>, chosen: List<Int>): Int {
        var saved = 0
        chosen.forEach { idx ->
            val bytes = images[idx] ?: return@forEach
            val ext = imageExtension(post.imageUrls[idx])
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "tiktok_${post.id}_${"%02d".format(idx + 1)}.$ext")
                put(MediaStore.Images.Media.MIME_TYPE, imageMime(ext))
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TikSaver")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = contentResolver
            val uri: Uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("تعذر إنشاء الملف في المعرض")
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IOException("تعذر الكتابة في المعرض")
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            saved++

            val percent = (saved * 100) / chosen.size
            runOnUiThread { progress.progress = percent }
        }
        return saved
    }

    private fun imageExtension(url: String): String {
        val path = Uri.parse(url).path ?: return "jpg"
        val ext = path.substringAfterLast('.', "jpg").lowercase()
        return when {
            ext == "jpeg" -> "jpg"
            ext.length in 2..4 -> ext
            else -> "jpg"
        }
    }

    private fun imageMime(ext: String): String = when (ext) {
        "webp" -> "image/webp"
        "png" -> "image/png"
        "heic" -> "image/heic"
        else -> "image/jpeg"
    }

    /** GET بسيط مع تتبع التحويلات وحفظ الكوكيز بين الطلبات */
    private fun httpGet(startUrl: String, referer: String?): HttpResult {
        var current = startUrl
        repeat(10) {
            val conn = URL(current).openConnection() as HttpURLConnection
            try {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.setRequestProperty("User-Agent", userAgent)
                conn.setRequestProperty("Accept", "image/avif,image/webp,image/*,*/*;q=0.8")
                conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                if (referer != null) conn.setRequestProperty("Referer", referer)
                if (cookies.isNotEmpty()) {
                    conn.setRequestProperty("Cookie", cookies.entries.joinToString("; ") { "${it.key}=${it.value}" })
                }

                val code = conn.responseCode
                conn.headerFields
                    .filterKeys { it?.equals("set-cookie", ignoreCase = true) == true }
                    .values.flatten()
                    .forEach { header ->
                        val pair = header.substringBefore(';')
                        val name = pair.substringBefore('=').trim()
                        if (name.isNotEmpty()) cookies[name] = pair.substringAfter('=', "")
                    }

                if (code in 300..399) {
                    val location = conn.getHeaderField("Location") ?: throw IOException("redirect without location")
                    current = URL(URL(current), location).toString()
                } else {
                    if (code !in 200..299) throw IOException("HTTP $code")
                    return HttpResult(conn.inputStream.use { it.readBytes() }, current)
                }
            } finally {
                conn.disconnect()
            }
        }
        throw IOException("too many redirects")
    }

    private fun isTikTok(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        return host == "tiktok.com" || host.endsWith(".tiktok.com")
    }

    // ---------- أدوات مساعدة ----------

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString()
        val url = extractUrl(text)
        if (url != null) linkInput.setText(url) else status.text = "ما لقيت رابط في الحافظة"
    }

    private fun extractUrl(text: String?): String? = text?.let { urlRegex.find(it)?.value }

    private fun isSupported(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        return supportedDomains.any { host == it || host.endsWith(".$it") }
    }

    private fun busy(on: Boolean, determinate: Boolean = false) {
        progress.visibility = if (on) View.VISIBLE else View.GONE
        progress.isIndeterminate = !determinate
        progress.progress = 0
        downloadBtn.isEnabled = !on && ready
        updateBtn.isEnabled = !on
    }
}
