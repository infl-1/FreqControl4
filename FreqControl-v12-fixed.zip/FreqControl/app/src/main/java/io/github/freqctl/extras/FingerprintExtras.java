package io.github.freqctl.extras;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Application;
import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ColorFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Runs inside com.samsung.android.biometrics.app.setting (the under-display fingerprint UI).
 *
 * Why this version works where the first one did not (learned from the reference module's dex):
 *  1) the hooks run BEFORE Samsung's call and cancel it (setResult(null)); an "after" hook lets Samsung's own
 *     icon / async Lottie composition land on top of ours;
 *  2) a custom PNG is also put on the Lottie views (cancelAnimation + setImageBitmap) - the lock-screen icon is a
 *     LottieAnimationView, which is an ImageView, so it never went through the setImageResource path;
 *  3) a custom Lottie JSON is loaded with setAnimation(InputStream, key), then setProgress(0) +
 *     setRepeatCount(loop ? -1 : 0) + playAnimation(); Samsung's own setProgress / colour-filter calls are blocked
 *     while a custom view is showing.
 */
public final class FingerprintExtras {
    public static final String PKG = "com.samsung.android.biometrics.app.setting";
    private static final String TAG = "FreqCtl/FP: ";
    private static final String CUSTOM = "fcl_custom";
    private static final String LOOP_LISTENER = "fcl_loop_listener";
    private static final Uri PNG = Uri.parse("content://io.github.freqctl.extra/png");
    private static final Uri ANIM = Uri.parse("content://io.github.freqctl.extra/animation");

    private static final String[] ASSETS = {"ic_fingerprint_prompt.json", "ic_fingerprint_aod.json",
            "ic_fingerprint_dark_theme.json", "ic_fingerprint_dark_theme_non_alpha.json",
            "ic_fingerprint_light_theme.json", "ic_fingerprint_light_theme_non_alpha.json",
            "prompt_btn_fingerprint.json"};
    private static final String[] RES = {"sem_fingerprint_icon_bg_white", "sem_fingerprint_icon_bg_black",
            "sem_fingerprint_icon_bg", "sem_biometric_prompt_dialog_fingerprint"};

    private static final List<WeakReference<View>> tracked = new ArrayList<>();
    private static Handler main;
    private static Context appContext;
    private static boolean observing;
    /** True while WE call setProgress / setAnimation on a Lottie view, so our own hooks let it through. */
    private static boolean ownCall;

    private static int cachedType = -1;
    private static int cachedRev = -1;
    private static Bitmap cachedBitmap;
    private static byte[] cachedPng;
    private static byte[] cachedAnim;
    private static int failLogs;
    private static int traceLogs;

    private static final Runnable REFRESH = new Runnable() {
        @Override public void run() { refreshAll(); }
    };

    private FingerprintExtras() {}

    public static void install(ClassLoader cl) {
        hookApplicationOnCreate();
        hookLottie(cl);
        hookImageView();
        hookUdfpsColorFilter(cl);
        log("hooks installed");
    }

    // ------------------------------------------------------------ hooks
    private static void hookApplicationOnCreate() {
        try {
            XposedBridge.hookMethod(Application.class.getDeclaredMethod("onCreate"), new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (p.thisObject instanceof Application) {
                        appContext = ((Application) p.thisObject).getApplicationContext();
                        registerObserver(appContext);
                    }
                }
            });
        } catch (Throwable t) { log("Application.onCreate hook skipped: " + t); }
    }

    private static void hookLottie(ClassLoader cl) {
        try {
            Class<?> lottie = XposedHelpers.findClass("com.airbnb.lottie.LottieAnimationView", cl);
            XposedBridge.hookAllMethods(lottie, "setAnimation", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    // only setAnimation(String assetName); our own setAnimation(InputStream, String) passes through
                    if (p.args.length != 1 || !(p.args[0] instanceof String) || !isAsset((String) p.args[0])) return;
                    View v = (View) p.thisObject;
                    track(v);
                    if (applyReplacement(v)) p.setResult(null); else scale(v);
                }
            });
            XposedBridge.hookAllMethods(lottie, "setProgress", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    if (!ownCall && isCustom(p.thisObject)) p.setResult(null);
                }
            });
            // Samsung sets its own repeat count after setAnimation(); that is what made the custom animation play once
            for (String name : new String[]{"setRepeatCount", "setRepeatMode"}) {
                final String n = name;
                XposedBridge.hookAllMethods(lottie, name, new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        if (ownCall || !isCustom(p.thisObject)) return;
                        trace("blocked Samsung " + n + "(" + (p.args.length > 0 ? p.args[0] : "") + ")");
                        p.setResult(null);
                    }
                });
            }
            // only log these, for the diagnosis log
            for (String name : new String[]{"playAnimation", "cancelAnimation", "pauseAnimation", "resumeAnimation",
                    "setMinAndMaxFrame", "setSpeed", "setMinFrame", "setMaxFrame"}) {
                final String n = name;
                XposedBridge.hookAllMethods(lottie, name, new XC_MethodHook() {
                    @Override protected void beforeHookedMethod(MethodHookParam p) {
                        if (!ownCall && isCustom(p.thisObject)) trace("Samsung called " + n);
                    }
                });
            }
        } catch (Throwable t) { log("Lottie hook failed: " + t); }
    }

    private static void hookImageView() {
        try {
            XposedBridge.hookAllMethods(ImageView.class, "setImageResource", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    if (!(p.thisObject instanceof ImageView) || p.args.length != 1 || !(p.args[0] instanceof Integer)) return;
                    ImageView v = (ImageView) p.thisObject;
                    if (!isRes(resName(v.getContext(), (Integer) p.args[0]))) return;
                    track(v);
                    if (applyReplacement(v)) p.setResult(null); else scale(v);
                }
            });
            // keep the custom icon un-tinted (a null argument = "clear", which we still allow)
            XposedBridge.hookAllMethods(ImageView.class, "setColorFilter", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    if (isCustom(p.thisObject) && hasNonNullArgument(p.args)) p.setResult(null);
                }
            });
        } catch (Throwable t) { log("ImageView hook failed: " + t); }
    }

    private static void hookUdfpsColorFilter(ClassLoader cl) {
        try {
            Class<?> w = Class.forName("com.samsung.android.biometrics.app.setting.fingerprint.UdfpsSensorWindow", false, cl);
            XposedBridge.hookMethod(w.getDeclaredMethod("setLottieViewColorFilter", int.class), new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    Context c = appContext;
                    if (c != null && loadCache(c) != ExtraSettings.FP_NONE) p.setResult(null);
                }
            });
        } catch (Throwable t) { log("UDFPS colour-filter hook skipped: " + t); }
    }

    // ------------------------------------------------------------ matching
    private static boolean isAsset(String s) { for (String a : ASSETS) if (a.equals(s)) return true; return false; }
    private static boolean isRes(String s) { for (String r : RES) if (r.equals(s)) return true; return false; }
    private static String resName(Context c, int id) {
        try { return c.getResources().getResourceEntryName(id); } catch (Throwable t) { return ""; }
    }
    private static boolean hasNonNullArgument(Object[] args) {
        if (args == null) return false;
        for (Object a : args) if (a != null) return true;
        return false;
    }
    private static boolean isCustom(Object v) {
        return v != null && Boolean.TRUE.equals(XposedHelpers.getAdditionalInstanceField(v, CUSTOM));
    }
    private static void mark(Object v, boolean on) {
        XposedHelpers.setAdditionalInstanceField(v, CUSTOM, on ? Boolean.TRUE : Boolean.FALSE);
    }

    // ------------------------------------------------------------ settings / cache
    /** Returns the custom icon type that is ready to use (FP_NONE when nothing usable is stored). */
    private static synchronized int loadCache(Context c) {
        int rev = ExtraSettings.get(c, ExtraSettings.K_FP_REV, 0);
        int type = ExtraSettings.get(c, ExtraSettings.K_FP_TYPE, -1);
        if (type < 0) type = rev != 0 ? ExtraSettings.FP_PNG : ExtraSettings.FP_NONE;   // 1.4 compatibility
        if (rev == 0) type = ExtraSettings.FP_NONE;

        if (type != cachedType || rev != cachedRev) {
            Bitmap bmp = null;
            byte[] png = null;
            byte[] anim = null;
            ContentResolver cr = c.getContentResolver();
            try {
                if (type == ExtraSettings.FP_PNG) {
                    byte[] raw = readAll(cr.openInputStream(PNG));
                    if (raw != null && raw.length > 0) {
                        bmp = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                        if (bmp != null) png = raw;
                    }
                } else if (type == ExtraSettings.FP_ANIM) {
                    anim = readAll(cr.openInputStream(ANIM));
                }
            } catch (Throwable t) {
                if (failLogs++ < 5) log("could not read the custom icon from the app: " + t);
            }
            boolean ok = type == ExtraSettings.FP_NONE || bmp != null || (anim != null && anim.length > 0);
            cachedBitmap = bmp;
            cachedPng = png;
            cachedAnim = anim;
            if (ok) {
                cachedType = type;
                cachedRev = rev;
                log("custom icon type=" + type + " rev=" + rev
                        + (bmp != null ? " png=" + bmp.getWidth() + "x" + bmp.getHeight() : "")
                        + (anim != null ? " json=" + anim.length + "B" : ""));
            } else {
                cachedType = -1;   // retry on the next call
                cachedRev = -1;
                if (failLogs++ < 5) log("custom icon type=" + type + " rev=" + rev + " is empty / unreadable");
                return ExtraSettings.FP_NONE;
            }
        }
        if (cachedType == ExtraSettings.FP_PNG && cachedBitmap != null) return ExtraSettings.FP_PNG;
        if (cachedType == ExtraSettings.FP_ANIM && cachedAnim != null) return ExtraSettings.FP_ANIM;
        return ExtraSettings.FP_NONE;
    }

    private static boolean loopWanted(Context c) {
        return ExtraSettings.get(c, ExtraSettings.K_FP_LOOP, ExtraSettings.DEF_LOOP) == 1;
    }

    // ------------------------------------------------------------ applying the custom icon
    private static boolean applyReplacement(View v) {
        Context c = v.getContext();
        int type = loadCache(c);
        if (type == ExtraSettings.FP_PNG) return applyPng(v);
        if (type == ExtraSettings.FP_ANIM) return applyAnimation(v, c);
        return false;
    }

    private static boolean applyPng(View v) {
        if (!(v instanceof ImageView) || cachedBitmap == null) return false;
        // The lock-screen icon is a Lottie view: wrap the image in a one-layer Lottie file and load it through the
        // same path that already works for custom JSON (a bitmap put straight on a Lottie view did not stick).
        if (cachedPng != null && hasMethod(v, "setAnimation", InputStream.class, String.class)) {
            String json = pngAsLottie(cachedPng, cachedBitmap.getWidth(), cachedBitmap.getHeight());
            if (applyLottie(v, json.getBytes(java.nio.charset.StandardCharsets.UTF_8), "fcl_fingerprint_png_" + cachedRev, false)) {
                log("png applied as Lottie on " + v.getClass().getName());
                return true;
            }
        }
        try {
            ImageView iv = (ImageView) v;
            call(v, "cancelAnimation");
            mark(v, true);
            iv.setColorFilter((ColorFilter) null);
            iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            iv.setImageBitmap(cachedBitmap);
            iv.invalidate();
            scale(v);
            log("png applied as bitmap on " + v.getClass().getName());
            return true;
        } catch (Throwable t) { log("png replacement failed: " + t); return false; }
    }

    private static boolean applyAnimation(View v, Context c) {
        if (cachedAnim == null) return false;
        return applyLottie(v, cachedAnim, "fcl_fingerprint_icon_" + cachedRev, true);
    }

    /** Loads a Lottie file into a Samsung LottieAnimationView. {@code animated=false} shows frame 0 only. */
    private static boolean applyLottie(View v, byte[] json, String key, boolean animated) {
        try {
            Method set = v.getClass().getMethod("setAnimation", InputStream.class, String.class);
            boolean loop = loopWanted(v.getContext());
            call(v, "removeAllLottieOnCompositionLoadedListener");   // drop Samsung's own "loaded" callbacks
            ownCall = true;
            try {
                set.invoke(v, new ByteArrayInputStream(json), key);
                mark(v, true);
                ((ImageView) v).setColorFilter((ColorFilter) null);
                v.getClass().getMethod("setProgress", float.class).invoke(v, 0f);
                if (animated) {
                    v.getClass().getMethod("setRepeatCount", int.class).invoke(v, loop ? -1 : 0);   // -1 forever, 0 once
                    installLoopListener(v);
                    v.getClass().getMethod("playAnimation").invoke(v);
                }
            } finally { ownCall = false; }
            scale(v);
            return true;
        } catch (NoSuchMethodException e) {
            return false;                                      // not a Lottie view
        } catch (Throwable t) { log("animation replacement failed: " + t); return false; }
    }

    /**
     * Safety net for the "plays once and stops" problem: when the custom animation ends by itself and repeat is on,
     * start it again. A cancel (Samsung stopping it, or us reloading it) is not restarted.
     */
    private static void installLoopListener(final View v) {
        try {
            Object old = XposedHelpers.getAdditionalInstanceField(v, LOOP_LISTENER);
            if (old != null) {
                v.getClass().getMethod("removeAnimatorListener", Animator.AnimatorListener.class).invoke(v, old);
            }
            AnimatorListenerAdapter l = new AnimatorListenerAdapter() {
                private boolean cancelled;
                @Override public void onAnimationCancel(Animator a) { cancelled = true; trace("animation cancelled"); }
                @Override public void onAnimationEnd(Animator a) {
                    boolean c = cancelled;
                    cancelled = false;
                    boolean again = !c && isCustom(v) && loopWanted(v.getContext());
                    trace("animation ended, cancelled=" + c + ", restart=" + again);
                    if (!again) return;
                    v.post(new Runnable() {
                        @Override public void run() {
                            if (!isCustom(v) || !v.isAttachedToWindow()) return;
                            ownCall = true;
                            try {
                                v.getClass().getMethod("setProgress", float.class).invoke(v, 0f);
                                v.getClass().getMethod("playAnimation").invoke(v);
                            } catch (Throwable t) { log("restart failed: " + t); }
                            finally { ownCall = false; }
                        }
                    });
                }
            };
            v.getClass().getMethod("addAnimatorListener", Animator.AnimatorListener.class).invoke(v, l);
            XposedHelpers.setAdditionalInstanceField(v, LOOP_LISTENER, l);
        } catch (Throwable t) { log("loop listener skipped: " + t); }
    }

    private static String pngAsLottie(byte[] png, int w, int h) {
        String b64 = Base64.encodeToString(png, Base64.NO_WRAP);
        String cx = String.valueOf(w / 2f), cy = String.valueOf(h / 2f);
        return "{\"v\":\"5.7.0\",\"fr\":30,\"ip\":0,\"op\":30,\"w\":" + w + ",\"h\":" + h
                + ",\"nm\":\"fcl\",\"ddd\":0,\"assets\":[{\"id\":\"img_0\",\"w\":" + w + ",\"h\":" + h
                + ",\"u\":\"\",\"p\":\"data:image/png;base64," + b64 + "\",\"e\":1}],"
                + "\"layers\":[{\"ddd\":0,\"ind\":1,\"ty\":2,\"nm\":\"icon\",\"refId\":\"img_0\",\"sr\":1,"
                + "\"ks\":{\"o\":{\"a\":0,\"k\":100},\"r\":{\"a\":0,\"k\":0},"
                + "\"p\":{\"a\":0,\"k\":[" + cx + "," + cy + ",0]},\"a\":{\"a\":0,\"k\":[" + cx + "," + cy + ",0]},"
                + "\"s\":{\"a\":0,\"k\":[100,100,100]}},\"ao\":0,\"ip\":0,\"op\":30,\"st\":0,\"bm\":0}],\"markers\":[]}";
    }

    private static boolean hasMethod(Object o, String name, Class<?>... types) {
        try { o.getClass().getMethod(name, types); return true; } catch (Throwable t) { return false; }
    }

    private static byte[] readAll(InputStream in) throws java.io.IOException {
        if (in == null) return null;
        try {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return b.toByteArray();
        } finally { in.close(); }
    }

    private static void call(Object o, String method) {
        try { o.getClass().getMethod(method).invoke(o); } catch (Throwable ignore) {}
    }

    // ------------------------------------------------------------ tracking / refreshing
    private static synchronized void track(final View v) {
        tracked.removeIf(r -> r.get() == null);   // views that were garbage-collected: do not let the list grow forever
        if (!isTracked(v)) {
            tracked.add(new WeakReference<>(v));
            // the icon is often laid out after the hook ran, so re-centre the scale pivot once it has a size
            v.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
                @Override public void onLayoutChange(View view, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                    if (r - l != or - ol || b - t != ob - ot) scale(view);
                }
            });
        }
        registerObserver(v.getContext().getApplicationContext() != null ? v.getContext().getApplicationContext() : v.getContext());
    }

    private static synchronized boolean isTracked(View v) {
        for (WeakReference<View> r : tracked) if (r.get() == v) return true;
        return false;
    }

    private static synchronized void registerObserver(Context c) {
        if (observing || c == null) return;
        observing = true;
        main = new Handler(Looper.getMainLooper());
        ContentObserver o = new ContentObserver(main) {
            @Override public void onChange(boolean s) {
                main.removeCallbacks(REFRESH);
                main.postDelayed(REFRESH, 150);   // type + rev arrive as separate writes: handle them together
            }
        };
        ContentResolver cr = c.getContentResolver();
        for (String k : new String[]{ExtraSettings.K_FP_SCALE, ExtraSettings.K_FP_REV,
                ExtraSettings.K_FP_TYPE, ExtraSettings.K_FP_LOOP}) {
            cr.registerContentObserver(Settings.Global.getUriFor(k), false, o);
        }
    }

    private static synchronized void refreshAll() {
        for (WeakReference<View> r : tracked) {
            View v = r.get();
            if (v == null) continue;
            if (loadCache(v.getContext()) != ExtraSettings.FP_NONE) {
                applyReplacement(v);
            } else {
                mark(v, false);   // back to the original: Samsung's code puts its icon back next time it shows
            }
            scale(v);
        }
    }

    private static void scale(View v) {
        int pct = Math.max(50, Math.min(200, ExtraSettings.get(v.getContext(), ExtraSettings.K_FP_SCALE, 100)));
        float s = pct / 100f;
        v.setPivotX(v.getWidth() / 2f);
        v.setPivotY(v.getHeight() / 2f);
        v.setScaleX(s);
        v.setScaleY(s);
        // let the enlarged icon draw outside its parent bounds
        ViewParent p = v.getParent();
        for (int i = 0; i < 3 && p instanceof ViewGroup; i++) {
            ((ViewGroup) p).setClipChildren(false);
            ((ViewGroup) p).setClipToPadding(false);
            p = p.getParent();
        }
    }

    /** Limited diagnosis log: what Samsung / Lottie do to the custom icon after we put it in. */
    private static void trace(String s) {
        if (traceLogs++ < 80) log(s);
    }

    private static void log(String s) {
        try { XposedBridge.log(TAG + s); } catch (Throwable ignore) {}
    }
}
