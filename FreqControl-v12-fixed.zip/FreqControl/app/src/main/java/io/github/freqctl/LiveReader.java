package io.github.freqctl;

import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Streams the hottest-core / AP temperature and the current frequency of every CPU cluster from the root
 * helper ("freqctl.sh live", one line per second). It runs only between {@link #start()} and {@link #stop()}
 * (the screen being visible): nothing is polled in the background, and the guard does not depend on it.
 */
public final class LiveReader {
    public static final class Sample {
        /** Degrees C; -1 when there is no such sensor. */
        public int core = -1;
        public int ap = -1;
        public int batt = -1;
        /** Current kHz of policy 0, 2, 5 and 7 (0 = unknown). */
        public final int[] freq = new int[4];
    }

    public interface Listener {
        void onSample(Sample sample);
    }

    private static final String[] FREQ_KEYS = {"f0", "f2", "f5", "f7"};

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Listener listener;
    private volatile boolean running;
    private int generation;
    private Process process;

    public LiveReader(Listener listener) {
        this.listener = listener;
    }

    public synchronized void start() {
        if (running) {
            return;
        }
        running = true;
        final int mine = ++generation;
        Thread thread = new Thread(() -> loop(mine), "freqctl-live");
        thread.setDaemon(true);
        thread.start();
    }

    public synchronized void stop() {
        running = false;
        generation++;
        if (process != null) {
            process.destroy();   // the helper ends by itself when its output pipe closes
            process = null;
        }
    }

    private synchronized boolean active(int mine) {
        return running && mine == generation;
    }

    private void loop(int mine) {
        long backoff = 1000L;
        while (active(mine)) {
            boolean gotData = false;
            try {
                Process p = new ProcessBuilder(RootShell.suBinary(), "-c", "sh " + RootControl.SCRIPT + " live")
                        .redirectErrorStream(true)
                        .start();
                synchronized (this) {
                    if (!active(mine)) {
                        p.destroy();
                        return;
                    }
                    process = p;
                }
                try (BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                    String line;
                    while (active(mine) && (line = in.readLine()) != null) {
                        final Sample sample = parse(line);
                        if (sample != null) {
                            gotData = true;
                            main.post(() -> {
                                if (active(mine)) {
                                    listener.onSample(sample);
                                }
                            });
                        }
                    }
                }
                p.destroy();
            } catch (IOException ignored) {
                // su missing or the helper is not installed yet: retry below
            }
            if (!active(mine)) {
                return;
            }
            // not installed yet / no root: retry slowly instead of spawning su in a tight loop
            backoff = gotData ? 1000L : Math.min(backoff * 2, 10_000L);
            try {
                Thread.sleep(backoff);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    static Sample parse(String line) {
        if (line == null || !line.startsWith("L ")) {
            return null;
        }
        Sample sample = new Sample();
        for (String part : line.substring(2).trim().split(" ")) {
            int eq = part.indexOf('=');
            if (eq <= 0) {
                continue;
            }
            String key = part.substring(0, eq);
            int value;
            try {
                value = Integer.parseInt(part.substring(eq + 1));
            } catch (NumberFormatException e) {
                continue;
            }
            if ("core".equals(key)) {
                sample.core = value;
            } else if ("ap".equals(key)) {
                sample.ap = value;
            } else if ("batt".equals(key)) {
                sample.batt = value;
            } else {
                for (int i = 0; i < FREQ_KEYS.length; i++) {
                    if (FREQ_KEYS[i].equals(key)) {
                        sample.freq[i] = Math.max(0, value);
                    }
                }
            }
        }
        return sample;
    }
}
