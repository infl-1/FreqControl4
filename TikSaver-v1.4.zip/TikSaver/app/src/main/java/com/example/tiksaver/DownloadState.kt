package com.example.tiksaver

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

/** حالة التحميل المشتركة بين الخدمة (DownloadService) والشاشة (MainActivity). */
object DownloadState {

    enum class State { IDLE, RUNNING, DONE, FAILED, CANCELLED }

    @Volatile
    var state: State = State.IDLE
        private set

    @Volatile
    var progress: Int = 0
        private set

    @Volatile
    var message: String = ""
        private set

    private val handler = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    fun update(newState: State, newProgress: Int = progress, newMessage: String = message) {
        state = newState
        progress = newProgress
        message = newMessage
        handler.post { listeners.forEach { it() } }
    }

    /** بعد ما الشاشة تعرض النتيجة النهائية نرجع للوضع الهادئ (الرسالة تبقى). */
    fun reset() {
        state = State.IDLE
        progress = 0
    }
}
