# إضافة اختيار الجودة + تحميل الصوت فقط (TikSaver)

## الملفات
- `app/src/main/java/com/example/tiksaver/QualityPicker.kt`  ← الملف الوحيد المطلوب

## طريقة الدمج (3 خطوات)

1. انسخ `QualityPicker.kt` إلى نفس مجلد `MainActivity.kt`
   (الباكيج: `com.example.tiksaver`).

2. في المكان اللي تنشئ فيه `YoutubeDLRequest` وتبدأ التحميل، لُفّه كذا:

```kotlin
QualityPicker.show(this) { quality ->
    val request = YoutubeDLRequest(url)
    // ... خياراتك الحالية (مجلد الحفظ، القالب، إلخ)
    // احذف أي سطر request.addOption("-f", ...) قديم
    QualityPicker.apply(request, quality)
    // ... نفس استدعاء التحميل الحالي (execute)
}
```

   إذا كان الكود داخل Service أو Fragment مرّر لـ `show` الـ Context المناسب.

3. للصوت (MP3) لازم FFmpeg يكون مهيأ، وغالباً هو كذا عندك لأن التطبيق فيه `libffmpeg.so`:

```kotlin
FFmpeg.getInstance().init(application)   // بجانب YoutubeDL.getInstance().init(...)
```

## ملاحظات
- `height<=` يعني لو الفيديو ما فيه الجودة المختارة ياخذ أقرب أقل منها.
- فيديوهات تيك توك غالباً جوداتها محدودة، فبعض الخيارات بتعطي نفس النتيجة.
- لتغيير صيغة الصوت عدّل `mp3` إلى `m4a` أو `opus`.
