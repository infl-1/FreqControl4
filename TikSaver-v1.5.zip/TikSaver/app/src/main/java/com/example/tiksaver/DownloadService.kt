package com.example.tiksaver

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import java.security.MessageDigest

/**
 * خدمة التحميل.
 *
 * الجديد في 1.5:
 *  - الاستكمال: الملفات الجزئية (.part) تبقى في مجلد ثابت لكل رابط، فإذا انقطع النت
 *    أو أوقفت التحميل يكمل من نفس النقطة بدل ما يبدأ من الصفر.
 *  - إذا انقطع الإنترنت: يتوقف تلقائياً (حالة "بانتظار الإنترنت") ويكمل لما يرجع.
 *  - إيقاف مؤقت / استئناف (من الواجهة أو من الإشعار)، وإلغاء يحذف الجزء المحمّل.
 */
class DownloadService : Service() {

    companion object {
        const val ACTION_START = "com.example.tiksaver.action.START"
        const val ACTION_CANCEL = "com.example.tiksaver.action.CANCEL"
        const val ACTION_PAUSE = "com.example.tiksaver.action.PAUSE"
        const val ACTION_RESUME = "com.example.tiksaver.action.RESUME"

        private const val EXTRA_URL = "url"
        private const val EXTRA_QUALITY = "quality"
        private const val CHANNEL_ID = "downloads"
        private const val NOTIF_ONGOING = 1001
        private const val NOTIF_DONE = 1002
        private const val PROCESS_ID = "tiksaver-download"

        private val mediaExtensions = setOf(
            "mp4", "mkv", "webm", "mov", "mp3", "m4a", "opus", "ogg", "aac", "wav", "flac"
        )

        fun start(context: Context, url: String, quality: Quality) {
            val intent = Intent(context, DownloadService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_URL, url)
                .putExtra(EXTRA_QUALITY, quality.name)
            ContextCompat.startForegroundService(context, intent)
        }

        fun cancel(context: Context) = send(context, ACTION_CANCEL)
        fun pause(context: Context) = send(context, ACTION_PAUSE)
        fun resume(context: Context) = send(context, ACTION_RESUME)

        private fun send(context: Context, action: String) {
            context.startService(Intent(context, DownloadService::class.java).setAction(action))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var network: NetworkMonitor

    @Volatile private var cancelRequested = false
    @Volatile private var networkDropped = false
    private val pausedFlow = MutableStateFlow(false)

    // ───────────────────────── دورة حياة الخدمة ─────────────────────────

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(CHANNEL_ID, "التحميلات", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        network = NetworkMonitor(applicationContext)
        network.start()
        scope.launch { cleanOldWorkDirs() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                ServiceCompat.startForeground(
                    this, NOTIF_ONGOING, buildOngoing("جاري التحميل...", 0),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
                if (job?.isActive == true) return START_NOT_STICKY
                val url = intent.getStringExtra(EXTRA_URL)
                val quality = try {
                    Quality.valueOf(intent.getStringExtra(EXTRA_QUALITY) ?: "ORIGINAL")
                } catch (e: Exception) {
                    Quality.ORIGINAL
                }
                if (url == null) stopSelf() else runDownload(url, quality)
            }
            ACTION_CANCEL -> handleCancel()
            ACTION_PAUSE -> handlePause()
            ACTION_RESUME -> handleResume()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (job?.isActive == true) killProcess()
        scope.cancel()
        network.stop()
        releaseWakeLock()
        super.onDestroy()
    }

    // ───────────────────────── الأوامر ─────────────────────────

    private fun handleCancel() {
        cancelRequested = true
        killProcess()
        val running = job?.isActive == true
        job?.cancel()
        if (!running) stopSelf()
    }

    private fun handlePause() {
        if (job?.isActive != true || pausedFlow.value) return
        pausedFlow.value = true
        showWaitingState()
        killProcess() // الملف الجزئي يبقى، والاستكمال يبدأ منه
    }

    private fun handleResume() {
        if (job?.isActive != true || !pausedFlow.value) return
        pausedFlow.value = false
    }

    private fun killProcess() {
        try { YoutubeDL.getInstance().destroyProcessById(PROCESS_ID) } catch (_: Exception) {}
    }

    // ───────────────────────── التنفيذ ─────────────────────────

    private fun runDownload(url: String, quality: Quality) {
        cancelRequested = false
        networkDropped = false
        pausedFlow.value = false
        DownloadState.update(DownloadState.State.RUNNING, 0, "جاري التحميل...")
        acquireWakeLock()

        job = scope.launch {
            var finalState = DownloadState.State.FAILED
            var message: String
            try {
                val file = downloadWithResume(url, quality)
                if (quality.audioOnly) {
                    MediaSaver.saveAudio(applicationContext, file)
                    message = "تم حفظ الصوت في المعرض (Music/TikSaver) ✅"
                } else {
                    MediaSaver.saveVideo(applicationContext, file)
                    message = "تم الحفظ في المعرض (Movies/TikSaver) ✅"
                }
                workDir(url).deleteRecursively()
                finalState = DownloadState.State.DONE
            } catch (e: Exception) {
                if (cancelRequested) {
                    finalState = DownloadState.State.CANCELLED
                    message = "تم الإلغاء"
                    workDir(url).deleteRecursively() // الإلغاء يحذف الجزء المحمّل
                } else {
                    val detail = e.message?.lineSequence()?.firstOrNull { it.isNotBlank() }?.take(160)
                        ?: e.javaClass.simpleName
                    message = "فشل التحميل. تأكد من الرابط، أو اضغط «تحديث المحرك» وحاول مرة ثانية.\n[تفاصيل] $detail"
                }
            } finally {
                releaseWakeLock()
            }
            finish(finalState, message)
        }
    }

    /**
     * حلقة الاستكمال: تشغّل yt-dlp، وإذا انقطع النت أو تم الإيقاف المؤقت تنتظر
     * ثم تعيد التشغيل على نفس المجلد فيكمل yt-dlp من الملف الجزئي.
     */
    private suspend fun downloadWithResume(url: String, quality: Quality): File {
        val dir = workDir(url)
        while (true) {
            awaitReady()
            networkDropped = false
            val watcher = scope.launch {
                // لو انقطع النت أثناء التحميل نوقف العملية فوراً بدل ما تعلّق وتعيد المحاولة
                network.online.first { !it }
                if (!cancelRequested && !pausedFlow.value) {
                    networkDropped = true
                    killProcess()
                }
            }
            try {
                return downloadFile(url, quality, dir)
            } catch (e: Exception) {
                if (cancelRequested) throw e
                val offline = networkDropped || !network.online.value
                if (pausedFlow.value || offline) continue // ينتظر ثم يكمل من الجزء المحمّل
                throw e
            } finally {
                watcher.cancel()
            }
        }
    }

    /** يوقف التنفيذ حتى يرجع الإنترنت ويُستأنف التحميل (إذا كان موقوفاً مؤقتاً). */
    private suspend fun awaitReady() {
        if (network.online.value && !pausedFlow.value) return
        showWaitingState()
        combine(network.online, pausedFlow) { online, paused -> online && !paused }
            .first { ready ->
                if (!ready) showWaitingState()
                ready
            }
        val p = DownloadState.progress
        DownloadState.update(DownloadState.State.RUNNING, p, "جاري التحميل... $p%")
        notifyOngoing("جاري التحميل... $p%", p)
        acquireWakeLock()
    }

    private fun showWaitingState() {
        val p = DownloadState.progress
        if (pausedFlow.value) {
            val msg = "متوقف مؤقتاً ⏸ ($p%)"
            DownloadState.update(DownloadState.State.PAUSED, p, msg)
            notifyOngoing(msg, p)
        } else {
            val msg = "بانتظار الإنترنت... سيكمل التحميل تلقائياً ⏳ ($p%)"
            DownloadState.update(DownloadState.State.WAITING_NETWORK, p, msg)
            notifyOngoing(msg, p)
        }
        releaseWakeLock()
    }

    private fun downloadFile(url: String, quality: Quality, dir: File): File {
        try {
            YoutubeDL.getInstance().init(applicationContext)
            FFmpeg.getInstance().init(applicationContext)
        } catch (e: Exception) {
            throw IOException("تعذر تجهيز المحرك: ${e.message}")
        }
        dir.mkdirs()

        val request = YoutubeDLRequest(url)
        request.addOption("-o", dir.absolutePath + "/%(id)s.%(ext)s")
        request.addOption("-f", quality.formatSelector())
        if (quality.audioOnly) {
            request.addOption("-x")
            request.addOption("--audio-format", "mp3")
            request.addOption("--audio-quality", "0")
        } else {
            request.addOption("--merge-output-format", "mp4")
        }
        request.addOption("--no-playlist")
        // استكمال الملفات الجزئية + مهلة قصيرة عشان ما يعلّق لو النت ضعيف
        request.addOption("--continue")
        request.addOption("--retries", "5")
        request.addOption("--fragment-retries", "5")
        request.addOption("--socket-timeout", "20")

        var lastProgress = -1
        YoutubeDL.getInstance().execute(request, PROCESS_ID) { progress, _, _ ->
            val p = progress.toInt().coerceIn(0, 100)
            if (p != lastProgress) {
                lastProgress = p
                onProgress(p)
            }
        }

        return dir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in mediaExtensions }
            ?.maxByOrNull { it.length() }
            ?: throw IOException("لم يتم العثور على الملف")
    }

    private fun onProgress(p: Int) {
        // تجاهل تحديثات متأخرة بعد الإيقاف أو انقطاع النت
        if (pausedFlow.value || !network.online.value) return
        val msg = "جاري التحميل... $p%"
        DownloadState.update(DownloadState.State.RUNNING, p, msg)
        notifyOngoing(msg, p)
    }

    // ───────────────────────── ملفات العمل ─────────────────────────

    /** مجلد ثابت لكل رابط، عشان الملفات الجزئية تنلقى عند الاستكمال. */
    private fun workDir(url: String): File {
        val hash = MessageDigest.getInstance("SHA-1")
            .digest(url.toByteArray())
            .joinToString("") { "%02x".format(it) }
            .take(16)
        return File(cacheDir, "dl/$hash")
    }

    private fun cleanOldWorkDirs() {
        val limit = System.currentTimeMillis() - 3L * 24 * 3600 * 1000
        File(cacheDir, "dl").listFiles()?.forEach {
            if (it.lastModified() < limit) it.deleteRecursively()
        }
    }

    // ───────────────────────── الإشعارات ─────────────────────────

    private fun openAppIntent(): PendingIntent {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun actionIntent(action: String, requestCode: Int): PendingIntent {
        val intent = Intent(this, DownloadService::class.java).setAction(action)
        return PendingIntent.getService(this, requestCode, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun buildOngoing(text: String, progress: Int): Notification {
        val paused = pausedFlow.value
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("محمّل الفيديوهات")
            .setContentText(text)
            .setContentIntent(openAppIntent())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, progress, progress == 0)
        if (paused) {
            builder.addAction(0, "استئناف", actionIntent(ACTION_RESUME, 3))
        } else {
            builder.addAction(0, "إيقاف مؤقت", actionIntent(ACTION_PAUSE, 2))
        }
        builder.addAction(0, "إلغاء", actionIntent(ACTION_CANCEL, 1))
        return builder.build()
    }

    private fun notifyOngoing(text: String, progress: Int) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ONGOING, buildOngoing(text, progress))
    }

    private fun finish(state: DownloadState.State, message: String) {
        val progress = if (state == DownloadState.State.DONE) 100 else DownloadState.progress
        DownloadState.update(state, progress, message)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        if (state != DownloadState.State.CANCELLED) {
            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("محمّل الفيديوهات")
                .setContentText(message.lineSequence().first())
                .setContentIntent(openAppIntent())
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(NOTIF_DONE, notification)
        }
        stopSelf()
    }

    // ───────────────────────── WakeLock ─────────────────────────

    private fun acquireWakeLock() {
        try {
            if (wakeLock?.isHeld == true) return
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tiksaver:download").also {
                it.acquire(30 * 60 * 1000L)
            }
        } catch (_: Exception) {}
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {}
        wakeLock = null
    }
}
