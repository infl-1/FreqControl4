# SmartCapture LSPosed — موديول يمنح الصلاحيات لنسخة المود

## وش يسوي
التطبيق المعدّل موقّع بمفتاح غير مفتاح سامسونج، فالنظام يرفض له الصلاحيات اللي يحتاجها مسجل الشاشة
(`CAPTURE_VIDEO_OUTPUT`, `READ_FRAME_BUFFER`, `INTERACT_ACROSS_USERS`, `MANAGE_ACTIVITY_TASKS`,
`INTERNAL_SYSTEM_WINDOW`...). الموديول يشتغل داخل `system_server` ويعدّل نتيجة فحص الصلاحيات
لحزمة `com.samsung.android.app.smartcapture` **فقط**: لو النظام رد «مرفوض» يصير «ممنوح».
باقي التطبيقات والصلاحيات الممنوحة أصلاً ما تتغير.

لا يغيّر الـ uid، فالتطبيق يبقى تحديثاً لتطبيق النظام (`/system/app/SmartCapture` ما ينلمس).

## البناء
- **GitHub Actions:** ارفع المجلد كمستودع، والـ workflow في `.github/workflows/build.yml` يبني
  `app-release.apk` ويرفعه كـ artifact.
- **أو محلياً:** `gradle assembleRelease` (Gradle 8.7، JDK 17، Android SDK 34).
- ملاحظة: مجلد `xposed-stub` فيه واجهات Xposed للترجمة فقط، وما يدخل في الـ APK.

## التثبيت
1. ثبّت APK الموديول.
2. LSPosed ← Modules ← فعّل «SmartCapture LSPosed» ← النطاق (Scope): **System Framework** (اسمها `android`).
3. أعد تشغيل الجهاز (لازم، لأن الـ hook داخل system_server).
4. ثبّت نسخة المود v7 العادية كتحديث، **بدون** `--system-uid`:
   `su -c "pm install -r -d SmartCapture_mod.apk"`
5. جرّب التسجيل.

## التأكد أنه شغّال
LSPosed ← Logs ← Modules، ولازم تشوف:
```
[SCMOD] hooked N x com.android.server.pm.permission.PermissionManagerServiceImpl#checkUidPermission
[SCMOD] ready, target=com.samsung.android.app.smartcapture grantAll=true
[SCMOD] target appId=10218
[SCMOD] granted android.permission.CAPTURE_VIDEO_OUTPUT to com.samsung.android.app.smartcapture
```
سطور `granted` تظهر مرة وحدة لكل صلاحية، وهي قائمة الصلاحيات اللي كان النظام يرفضها فعلاً.
أمر `dumpsys package` ما راح يبيّن `granted=true` لأن التعديل على الفحص وقت التشغيل، مو على الحالة المخزّنة.

## الإعدادات (في `MainHook.java`)
- `GRANT_ALL = true`: كل فحص مرفوض للحزمة يصير ممنوح (يشبه تشغيله بـ uid النظام لهذي الحزمة فقط).
- `GRANT_ALL = false`: فقط الصلاحيات المكتوبة في `LIST`.

## لو لسا يكرش
أرسل:
1. `logcat -d | grep -E "MODFPS|AndroidRuntime|smartcapture"`
2. سطور `[SCMOD]` من سجل LSPosed.

لو طلع `NOTHING hooked` فهذا يعني إن اسم الكلاس مختلف في روم سامسونج عندك، وأحتاج الإصدار.

## حدود (مهم)
- **لم يُبنَ ولم يُجرَّب على جهاز.** اللي اختبرته محلياً: الكود يترجم، ومنطق اختيار الحزمة والـ uid يعطي النتائج
  المتوقعة في محاكاة بدون أندرويد.
- الموديول يغطي فحوصات الصلاحيات فقط. لو سامسونج تفحص التوقيع مباشرة (`checkSignatures` أو «هل التطبيق
  موقّع بمفتاح المنصة») فهذا ما يغطيه، وسيظهر في اللوج بخطأ ثاني.
- تعطيل التوقيع اللي سويته على النظام ما يحتاج تغيير؛ هذا الموديول يكمله.
- جهّز طريقة تعطيل الموديولات (وضع الأمان في Magisk) قبل ما تفعّل hook على system_server.
