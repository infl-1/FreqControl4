package io.github.freqctl.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.slider.Slider;

import java.util.Locale;

import io.github.freqctl.Domain;
import io.github.freqctl.LiveReader;
import io.github.freqctl.R;

/**
 * Thermal guard card. Top: live frequency of each CPU cluster with a quick on/off for that cluster's
 * limit. Then the two sensor buttons (hottest core, AP) with a limit bar each, the battery limit, and
 * whether the guard is tripped right now.
 */
final class GuardCard {
    /** Same order as {@link LiveReader.Sample#freq}. */
    static final Domain[] CLUSTERS = {Domain.CPU0, Domain.CPU2, Domain.CPU5, Domain.CPU7};
    private static final String[] CLUSTER_NAMES = {"0-1", "2-4", "5-6", "7"};

    interface Listener {
        void onGuardCommit(boolean enabled, boolean coreOn, int coreLimit, boolean apOn, int apLimit, int battLimit);

        void onClusterToggle(Domain domain, boolean enabled);
    }

    private final Listener listener;
    private final MaterialSwitch toggle;
    private final MaterialButton coreButton;
    private final MaterialButton apButton;
    private final Slider coreSlider;
    private final Slider apSlider;
    private final Slider battSlider;
    private final TextView coreLabel;
    private final TextView apLabel;
    private final TextView battLabel;
    private final TextView stateText;
    private final TextView[] freqViews = new TextView[CLUSTERS.length];
    private final MaterialSwitch[] clusterSwitches = new MaterialSwitch[CLUSTERS.length];

    private int liveCore = -1;
    private int liveAp = -1;
    private boolean binding;

    GuardCard(View root, Listener listener) {
        this.listener = listener;
        toggle = root.findViewById(R.id.guard_switch);
        coreButton = root.findViewById(R.id.guard_btn_core);
        apButton = root.findViewById(R.id.guard_btn_ap);
        coreSlider = root.findViewById(R.id.guard_core_slider);
        apSlider = root.findViewById(R.id.guard_ap_slider);
        battSlider = root.findViewById(R.id.guard_batt_slider);
        coreLabel = root.findViewById(R.id.guard_core_label);
        apLabel = root.findViewById(R.id.guard_ap_label);
        battLabel = root.findViewById(R.id.guard_batt_label);
        stateText = root.findViewById(R.id.guard_state);

        LinearLayout tiles = root.findViewById(R.id.guard_tiles);
        LayoutInflater inflater = LayoutInflater.from(root.getContext());
        for (int i = 0; i < CLUSTERS.length; i++) {
            View tile = inflater.inflate(R.layout.item_cluster, tiles, false);
            ((TextView) tile.findViewById(R.id.cluster_label)).setText(CLUSTER_NAMES[i]);
            freqViews[i] = tile.findViewById(R.id.cluster_freq);
            MaterialSwitch clusterSwitch = tile.findViewById(R.id.cluster_switch);
            final Domain domain = CLUSTERS[i];
            clusterSwitch.setOnCheckedChangeListener((button, checked) -> {
                if (!binding) {
                    GuardCard.this.listener.onClusterToggle(domain, checked);
                }
            });
            clusterSwitches[i] = clusterSwitch;
            tiles.addView(tile);
        }

        coreSlider.addOnChangeListener((s, value, fromUser) -> updateLabels());
        apSlider.addOnChangeListener((s, value, fromUser) -> updateLabels());
        battSlider.addOnChangeListener((s, value, fromUser) -> updateLabels());
        Slider.OnSliderTouchListener touch = new Slider.OnSliderTouchListener() {
            @Override
            public void onStartTrackingTouch(Slider slider) {
            }

            @Override
            public void onStopTrackingTouch(Slider slider) {
                commit();
            }
        };
        coreSlider.addOnSliderTouchListener(touch);
        apSlider.addOnSliderTouchListener(touch);
        battSlider.addOnSliderTouchListener(touch);

        MaterialButtonToggleGroup group = root.findViewById(R.id.guard_sensor_group);
        group.addOnButtonCheckedListener((g, checkedId, isChecked) -> {
            if (!binding) {
                updateSliderState();
                commit();
            }
        });
        toggle.setOnCheckedChangeListener((button, checked) -> {
            if (!binding) {
                coreButton.setEnabled(checked);
                apButton.setEnabled(checked);
                battSlider.setEnabled(checked);
                updateSliderState();
                commit();
            }
        });
        updateButtonTexts();
    }

    /**
     * @param rootReady     true when the root helper published a table during this boot (the guard runs there)
     * @param tripped       true while the guard has released every limit
     * @param clusterOn     per cluster ({@link #CLUSTERS} order): its limit switch is on
     * @param clusterUsable per cluster: the helper published its frequency table
     */
    void bind(boolean enabled, boolean coreOn, int coreLimit, boolean apOn, int apLimit, int battLimit,
              boolean rootReady, boolean tripped, boolean[] clusterOn, boolean[] clusterUsable) {
        binding = true;
        try {
            toggle.setChecked(enabled);
            coreButton.setChecked(coreOn);
            apButton.setChecked(apOn);
            coreButton.setEnabled(enabled);
            apButton.setEnabled(enabled);
            coreSlider.setValue(clamp(coreSlider, coreLimit));
            apSlider.setValue(clamp(apSlider, apLimit));
            battSlider.setValue(clamp(battSlider, battLimit));
            battSlider.setEnabled(enabled);
            updateSliderState();
            updateLabels();
            for (int i = 0; i < CLUSTERS.length; i++) {
                clusterSwitches[i].setEnabled(clusterUsable[i]);
                clusterSwitches[i].setChecked(clusterUsable[i] && clusterOn[i]);
            }
            int state;
            if (!enabled) {
                state = R.string.guard_state_off;
            } else if (!rootReady) {
                state = R.string.guard_state_no_root;
            } else if (tripped) {
                state = R.string.guard_state_tripped;
            } else if (!coreOn && !apOn) {
                state = R.string.guard_state_battery_only;
            } else {
                state = R.string.guard_state_ok;
            }
            stateText.setText(state);
        } finally {
            binding = false;
        }
    }

    /** One line from the root helper (about once a second while the screen is open). */
    void showLive(LiveReader.Sample sample) {
        for (int i = 0; i < freqViews.length; i++) {
            String text = sample.freq[i] > 0
                    ? String.format(Locale.US, "%.2f", sample.freq[i] / 1_000_000f) : "--";
            if (!text.contentEquals(freqViews[i].getText())) {
                freqViews[i].setText(text);
            }
        }
        liveCore = sample.core;
        liveAp = sample.ap;
        updateButtonTexts();
    }

    private void updateButtonTexts() {
        setIfChanged(coreButton, coreButton.getContext().getString(R.string.guard_btn_core, degrees(liveCore)));
        setIfChanged(apButton, apButton.getContext().getString(R.string.guard_btn_ap, degrees(liveAp)));
    }

    private static void setIfChanged(MaterialButton button, String text) {
        if (!text.contentEquals(button.getText())) {
            button.setText(text);
        }
    }

    private static String degrees(int value) {
        return value >= 0 ? value + "\u00B0" : "--";
    }

    private void updateSliderState() {
        boolean on = toggle.isChecked();
        coreSlider.setEnabled(on && coreButton.isChecked());
        apSlider.setEnabled(on && apButton.isChecked());
    }

    private static float clamp(Slider slider, int value) {
        return Math.max(slider.getValueFrom(), Math.min(value, slider.getValueTo()));
    }

    private void updateLabels() {
        coreLabel.setText(coreLabel.getContext().getString(R.string.guard_core_label, Math.round(coreSlider.getValue())));
        apLabel.setText(apLabel.getContext().getString(R.string.guard_ap_label, Math.round(apSlider.getValue())));
        battLabel.setText(battLabel.getContext().getString(R.string.guard_batt_label, Math.round(battSlider.getValue())));
    }

    private void commit() {
        if (binding) {
            return;
        }
        listener.onGuardCommit(toggle.isChecked(),
                coreButton.isChecked(), Math.round(coreSlider.getValue()),
                apButton.isChecked(), Math.round(apSlider.getValue()),
                Math.round(battSlider.getValue()));
    }
}
