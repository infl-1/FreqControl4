# فحص جاهزية الحقن (قراءة فقط من /proc، ما يلمس اللعبة). يُشغَّل داخل ( ) < /dev/null من Engine.probe
# يطبع: PROBE ok AGE FG UNITYMAIN NATIVE ART MAPS INJ   (أو PROBE none) وبعده سطر SEEN A=.. J=.. S=.. O=.. لو الحاقن شغّال
num() { case "$1" in ''|*[!0-9]*) echo 0;; *) echo "$1";; esac; }
PKG=__PKG__
PID=$(pidof "$PKG" | cut -d' ' -f1)
if [ -z "$PID" ]; then
  echo "PROBE none"
else
  UP=$(num "$(cut -d. -f1 /proc/uptime)")
  ST=$(num "$(sed 's/.*) //' /proc/$PID/stat 2>/dev/null | cut -d' ' -f20)")
  HZ=$(num "$(getconf CLK_TCK 2>/dev/null)")
  [ "$HZ" -gt 0 ] || HZ=100
  AGE=$((UP - ST / HZ))
  [ "$AGE" -ge 0 ] || AGE=0
  # اللعبة في الواجهة = oom_score_adj صفر (التطبيق العلوي)
  ADJ=$(cat /proc/$PID/oom_score_adj 2>/dev/null)
  FG=0
  [ -n "$ADJ" ] && [ "$ADJ" -le 0 ] && FG=1
  M=/proc/$PID/maps
  LINES=$(num "$(wc -l < $M 2>/dev/null)")
  # كود native للتطبيق محمّل (مكتبة .so أو APK فيه مكتبات) تحت /data/app
  NAT=$(num "$(grep ' r-xp ' $M 2>/dev/null | grep -E '/data/app/.*(\.so|\.apk)$' | wc -l)")
  # بيئة Java (ART) شغّالة
  ART=$(num "$(grep -c -E 'libandroid_runtime\.so|libopenjdk' $M 2>/dev/null)")
  # خيط محرك Unity الرئيسي ظهر = المحرك اشتغل
  UM=$(num "$(cat /proc/$PID/task/*/comm 2>/dev/null | grep -c '^UnityMain')")
  # هل الحاقن شغّال أصلاً داخل نفس العملية؟
  INJ=0
  [ "$(cat /data/local/tmp/inj.pid 2>/dev/null)" = "$PID" ] && pgrep -x frida-inject >/dev/null && INJ=1
  echo "PROBE ok $AGE $FG $UM $NAT $ART $LINES $INJ"
  # المصادر النشطة: الحاقن يكتب seen.txt كل ثانية (A=عدد/ثانية J=.. S=.. O=..). نقرأه فقط لو حيّ وحديث (آخر 4 ثواني)
  SEENTXT=""
  SA=$(num "$(stat -c %Y /data/local/tmp/seen.txt 2>/dev/null)")
  NOW=$(num "$(date +%s)")
  if [ "$INJ" = 1 ] && [ "$SA" -gt 0 ] && [ $((NOW - SA)) -le 4 ]; then
    SEENTXT=$(cat /data/local/tmp/seen.txt 2>/dev/null | tr '\n' ' ')
  fi
  echo "SEEN $SEENTXT"
fi
