package com.example.speedtool

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.lang.ref.WeakReference

class MainActivity : Activity() {
    private lateinit var log: TextView
    private lateinit var logCard: View

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(Theme.SURFACE, dp(18).toFloat(), dp(1), 0x2200E5FF)
    }

    private fun button(text: String, bg: Int, fg: Int, stroke: Int = 0): TextView {
        val r = dp(16).toFloat()
        return tv(text, 15f, fg, true).apply {
            gravity = Gravity.CENTER
            isClickable = true
            setPadding(dp(12), dp(15), dp(12), dp(15))
            background = withRipple(rounded(bg, r, if (stroke != 0) dp(1) else 0, stroke), r)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        current = WeakReference(this)
        window.statusBarColor = 0xFF0B0D18.toInt()
        window.navigationBarColor = 0xFF0B0D18.toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(36), dp(18), dp(24))
        }

        // ---- الشعار + العنوان
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_logo)
            scaleType = ImageView.ScaleType.FIT_XY
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, dp(22).toFloat())
                }
            }
            clipToOutline = true
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("Speed Tool", 26f, Color.WHITE, true))
            addView(tv("تحكّم بسرعة الألعاب الأوفلاين", 13f, Theme.MUTED))
            addView(tv("الإصدار $ver  ·  يحتاج روت", 11f, Theme.CYAN).apply { setPadding(0, dp(4), 0, 0) })
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(logo, LinearLayout.LayoutParams(dp(84), dp(84)).apply { marginEnd = dp(16) })
            addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        root.addView(header)

        // ---- الأزرار
        val r = dp(16).toFloat()
        val floatBtn = button("▶  تشغيل الأيقونة العائمة", 0, Color.WHITE).apply {
            background = withRipple(
                GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Theme.PURPLE, 0xFF00B8D4.toInt()))
                    .apply { cornerRadius = r },
                r
            )
            setOnClickListener { openFloating() }
        }
        val logBtn = button("عرض السجل", Theme.SURFACE, Theme.TEXT, 0x3300E5FF).apply {
            setOnClickListener { Engine.readLog { log.text = it; logCard.visibility = View.VISIBLE } }
        }
        root.addView(floatBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(26) })
        root.addView(logBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

        // ---- طريقة الاستخدام
        val steps = card().apply {
            addView(tv("طريقة الاستخدام", 15f, Color.WHITE, true))
            listOf(
                "1  اضغط «تشغيل الأيقونة العائمة» (frida-inject مدمج، ما تحتاج تحط شي).",
                "2  افتح اللعبة، اضغط الأيقونة ثم اختر اللعبة وابدأ التسريع.",
                "3  اضغط مطوّلاً على الأيقونة: يطلع سهمين، ▲ يسرّع و▼ يبطّئ، والسرعة مكتوبة على الأيقونة.",
                "4  إذا ما تسرّعت اللعبة: أوقف التسريع، بدّل «الوضع»، وابدأ من جديد."
            ).forEach { line ->
                addView(tv(line, 13f, Theme.MUTED).apply { setPadding(0, dp(8), 0, 0) })
            }
        }
        root.addView(steps, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(18) })

        // ---- السجل (مخفي لين تضغط عرض السجل)
        log = tv("", 11f, Theme.CYAN).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            textDirection = View.TEXT_DIRECTION_LTR
        }
        logCard = card().apply {
            visibility = View.GONE
            addView(tv("السجل", 15f, Color.WHITE, true))
            addView(log, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        }
        root.addView(logCard, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        // ---- إيقاف التطبيق
        val quitBtn = button("⏻  إيقاف التطبيق", 0x33FF5252, Theme.RED, 0x88FF5252.toInt()).apply {
            setOnClickListener { Engine.quitAll(this@MainActivity) }
        }
        root.addView(quitBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(18) })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0B0D18.toInt())
            isFillViewport = true
            addView(root, ViewGroup.LayoutParams(MATCH, WRAP))
        })

        // إذن الإشعارات (أندرويد 13+): الخدمة الأمامية تشتغل بدونه لكن الإشعار ما يظهر
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onDestroy() {
        if (current?.get() === this) current = null
        super.onDestroy()
    }

    private fun openFloating() {
        if (Settings.canDrawOverlays(this)) { launchFloating(); return }
        Engine.su("appops set $packageName SYSTEM_ALERT_WINDOW allow") { _ ->
            if (Settings.canDrawOverlays(this)) {
                launchFloating()
            } else {
                log.text = "فعّل إذن «الظهور فوق التطبيقات» ثم ارجع واضغط الزر مرة ثانية"
                logCard.visibility = View.VISIBLE
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
    }

    private fun launchFloating() {
        stopService(Intent(this, FloatingService::class.java))
        val svc = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
        log.text = "تم. افتح اللعبة واضغط الأيقونة ثم اختر التطبيق"
        logCard.visibility = View.VISIBLE
        moveTaskToBack(true)
    }

    companion object {
        var current: WeakReference<MainActivity>? = null
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }
}
