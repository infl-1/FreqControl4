import struct, sys, zipfile
def uleb(b,o):
    r=0;s=0
    while True:
        x=b[o];o+=1;r|=(x&0x7f)<<s;s+=7
        if x<0x80:break
    return r,o
def mutf(b,o):
    _,o=uleb(b,o);e=b.index(0,o);return b[o:e].decode('utf-8','replace')
L={}
def setl(r,n):
    for i in r:L[i]=n
setl(range(256),1)
for i in (0x02,0x05,0x08,0x13,0x15,0x16,0x19,0x1a,0x1c,0x1f,0x20,0x22,0x23,0x29): L[i]=2
for i in (0x03,0x06,0x09,0x14,0x17,0x1b,0x24,0x25,0x26,0x2a,0x2b,0x2c): L[i]=3
L[0x18]=5
for i in range(0x2d,0x32):L[i]=2
for i in range(0x32,0x44):L[i]=2
for i in range(0x44,0x6e):L[i]=2
for i in range(0x6e,0x73):L[i]=3
for i in range(0x74,0x79):L[i]=3
for i in range(0x90,0xb0):L[i]=2
for i in range(0xd0,0xe3):L[i]=2
L[0xfa]=4;L[0xfb]=4;L[0xfc]=3;L[0xfd]=3;L[0xfe]=2;L[0xff]=2
class Dex:
    def __init__(s,b):
        s.b=b
        (s.ssz,s.soff,s.tsz,s.toff,s.psz,s.poff,s.fsz,s.foff,s.msz,s.moff,s.csz,s.coff)=struct.unpack_from('<12I',b,0x38)
        s._str={}
    def string(s,i):
        if i not in s._str:
            o=struct.unpack_from('<I',s.b,s.soff+4*i)[0];s._str[i]=mutf(s.b,o)
        return s._str[i]
    def strings(s):
        return [s.string(i) for i in range(s.ssz)]
    def type(s,i): return s.string(struct.unpack_from('<I',s.b,s.toff+4*i)[0])
    def proto(s,i):
        sh,rt,pa=struct.unpack_from('<3I',s.b,s.poff+12*i)
        ps=[]
        if pa:
            n=struct.unpack_from('<I',s.b,pa)[0]
            ps=[s.type(struct.unpack_from('<H',s.b,pa+4+2*k)[0]) for k in range(n)]
        return s.type(rt),ps
    def field(s,i):
        c,t,n=struct.unpack_from('<HHI',s.b,s.foff+8*i);return s.type(c),s.string(n),s.type(t)
    def method(s,i):
        c,p,n=struct.unpack_from('<HHI',s.b,s.moff+8*i);r,ps=s.proto(p);return s.type(c),s.string(n),r,ps
    def classes(s):
        for i in range(s.csz):
            ci,af,sup,ifs,sf,ann,cd,sv=struct.unpack_from('<8I',s.b,s.coff+32*i)
            yield s.type(ci),af,s.type(sup) if sup!=0xffffffff else None,cd
    def class_methods(s,cd):
        if not cd:return
        b=s.b;sf,o=uleb(b,cd);inf,o=uleb(b,o);dm,o=uleb(b,o);vm,o=uleb(b,o)
        for _ in range(sf+inf):
            _,o=uleb(b,o);_,o=uleb(b,o)
        for cnt in (dm,vm):
            idx=0
            for _ in range(cnt):
                d,o=uleb(b,o);idx+=d;af,o=uleb(b,o);co,o=uleb(b,o)
                yield idx,af,co
    def insns(s,co):
        b=s.b;rs,ins,outs,tries,dbg,isz=struct.unpack_from('<4HII',b,co);base=co+16
        p=0
        while p<isz:
            u=struct.unpack_from('<H',b,base+2*p)[0];op=u&0xff
            if op==0 and u in (0x100,0x200,0x300):
                n=struct.unpack_from('<H',b,base+2*p+2)[0]
                if u==0x100: ln=n*2+4
                elif u==0x200: ln=n*4+2
                else:
                    w=n;sz=struct.unpack_from('<I',b,base+2*p+4)[0];ln=(w*sz+1)//2+4
                yield p,op,u,None,ln;p+=ln;continue
            ln=L[op];yield p,op,u,base+2*p,ln;p+=ln
def load(path,member=None):
    if member:
        z=zipfile.ZipFile(path);return [ (n,Dex(z.read(n))) for n in sorted(z.namelist()) if n.startswith('classes') and n.endswith('.dex')]
    return [(path,Dex(open(path,'rb').read()))]
