package io.github.freqctl.ui;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import io.github.freqctl.R;

/**
 * Read-only card. Everything comes from the status string the SDHMS hook publishes (the same values SDHMS's own
 * hidden ThermalLimitStatusActivity and its "sdhms" binder report).
 */
final class StatusCard {
    private final TextView thermal;
    private final TextView sensors;

    StatusCard(View root) {
        thermal = root.findViewById(R.id.status_thermal);
        sensors = root.findViewById(R.id.status_sensors);
    }

    static Map<String, String> parse(String raw) {
        Map<String, String> map = new LinkedHashMap<>();
        if (raw == null) {
            return map;
        }
        for (String part : raw.split(";")) {
            int eq = part.indexOf('=');
            if (eq > 0) {
                map.put(part.substring(0, eq), part.substring(eq + 1));
            }
        }
        return map;
    }

    /** True when the hook published a status during the last two minutes. */
    static boolean isAlive(Map<String, String> m) {
        try {
            long ts = Long.parseLong(m.get("ts"));
            return System.currentTimeMillis() / 1000L - ts < 120;
        } catch (Exception e) {
            return false;
        }
    }

    /** "true"/"false" from the hook, or null when it did not report the value. */
    static Boolean flag(Map<String, String> m, String key) {
        String v = m.get(key);
        if ("true".equals(v)) {
            return Boolean.TRUE;
        }
        return "false".equals(v) ? Boolean.FALSE : null;
    }

    private String yesNo(Context c, Boolean v) {
        return v == null ? c.getString(R.string.status_unknown) : c.getString(v ? R.string.yes : R.string.no);
    }

    private String number(Context c, String v) {
        return v == null || "?".equals(v) ? c.getString(R.string.status_unknown) : v;
    }

    /** Fallbacks are the app's own switch states, used while the hook is silent. */
    void bind(String hookStatus, boolean masterOff, boolean brightOff, boolean cpOff) {
        Context c = thermal.getContext();
        Map<String, String> m = parse(hookStatus);
        boolean alive = isAlive(m);
        boolean avail = alive && "1".equals(m.get("avail"));
        Boolean master = alive ? flag(m, "m") : null;
        Boolean bright = alive ? flag(m, "h") : null;
        Boolean cp = alive ? flag(m, "i") : null;
        String time = new SimpleDateFormat("HH:mm:ss dd-MM-yyyy", Locale.ENGLISH).format(new Date());
        StringBuilder sb = new StringBuilder();
        sb.append(c.getString(R.string.st_refresh, time)).append('\n');
        sb.append(c.getString(R.string.st_binder, alive && "1".equals(m.get("bind"))
                ? "com.sec.android.sdhms.b" : c.getString(R.string.st_disconnected))).append('\n');
        sb.append(c.getString(R.string.st_limiter, avail ? "true" : "false")).append('\n');
        sb.append(c.getString(R.string.st_master, yesNo(c, master != null ? master : (Boolean) masterOff))).append('\n');
        sb.append(c.getString(R.string.st_bright_closed, yesNo(c, bright != null ? bright : (Boolean) brightOff))).append('\n');
        sb.append(c.getString(R.string.st_cp_closed, yesNo(c, cp != null ? cp : (Boolean) cpOff))).append('\n');
        sb.append(c.getString(R.string.st_cur_bright, yesNo(c, alive ? flag(m, "br") : null))).append('\n');
        sb.append(c.getString(R.string.st_cur_hrr, yesNo(c, alive ? flag(m, "hrr") : null))).append('\n');
        sb.append(c.getString(R.string.st_cur_cp_low, yesNo(c, alive ? flag(m, "cpl") : null))).append('\n');
        sb.append(c.getString(R.string.st_cur_cp_cool, yesNo(c, alive ? flag(m, "cpc") : null))).append('\n');
        sb.append(c.getString(R.string.st_flag, number(c, alive ? m.get("fl") : null))).append('\n');
        sb.append(c.getString(R.string.st_delta, number(c, alive ? m.get("dl") : null)));
        thermal.setText(sb.toString());
        sensors.setText(alive ? formatTemps(m.get("t")) : formatTemps(null));
    }

    /** raw values are tenths of a degree; -999 / -888 mean "no sensor", shown as -999 like SDHMS's own tools. */
    private static String formatTemps(String raw) {
        String[] names = {"AP", "BAT", "CHG", "DC", "USB", "WIFI", "PA", "PA1", "CP", "CF"};
        Map<String, String> values = new LinkedHashMap<>();
        if (raw != null) {
            for (String item : raw.split(",")) {
                int colon = item.indexOf(':');
                if (colon > 0) {
                    values.put(item.substring(0, colon), item.substring(colon + 1));
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        for (String name : names) {
            sb.append(name).append('=');
            String v = values.get(name);
            try {
                int tenths = Integer.parseInt(v);
                if (tenths == -999 || tenths == -888) {
                    sb.append("-999");
                } else {
                    sb.append(String.format(Locale.ENGLISH, "%.1f C", tenths / 10.0));
                }
            } catch (Exception e) {
                sb.append("-999");
            }
            sb.append('\n');
        }
        return sb.toString().trim();
    }
}
