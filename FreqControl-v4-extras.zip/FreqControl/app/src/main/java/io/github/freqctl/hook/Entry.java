package io.github.freqctl.hook;

import android.content.Context;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import io.github.freqctl.extras.FingerprintExtras;
import io.github.freqctl.extras.SdhmsExtras;

/**
 * LSPosed entry point. Scope: Samsung's Device Health Manager (SDHMS) - its process may hold SemDvfsManager
 * frequency requests, and it also owns the thermal limiter and receives the touch-boost broadcast - plus the
 * under-display fingerprint UI (com.samsung.android.biometrics.app.setting) for the icon size / style.
 */
public class Entry implements IXposedHookLoadPackage {
    private static final String SDHMS_PACKAGE = "com.sec.android.sdhms";
    private static final String SDHMS_APPLICATION = "com.sec.android.sdhms.MainApplication";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (FingerprintExtras.PKG.equals(lpparam.packageName)) {
            FingerprintExtras.install(lpparam.classLoader);
            return;
        }
        if (!SDHMS_PACKAGE.equals(lpparam.packageName)) {
            return;
        }
        final ClassLoader classLoader = lpparam.classLoader;
        try {
            XposedHelpers.findAndHookMethod(SDHMS_APPLICATION, classLoader, "onCreate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        if (param.thisObject instanceof Context) {
                            FreqController.install((Context) param.thisObject, classLoader);
                            SdhmsExtras.install((Context) param.thisObject, classLoader);
                        }
                    } catch (Throwable t) {
                        XposedBridge.log("FreqCtl: install failed");
                        XposedBridge.log(t);
                    }
                }
            });
            XposedBridge.log("FreqCtl: hooked SDHMS MainApplication.onCreate");
        } catch (Throwable t) {
            XposedBridge.log("FreqCtl: could not hook SDHMS MainApplication.onCreate");
            XposedBridge.log(t);
        }
    }
}
