package com.example.speedtool

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/**
 * صفحة البحث وتغيير القيم داخل اللوحة العائمة (على طريقة جيم جاردن):
 * بحث بقيمة / نطاق / قيمة مجهولة، تضييق (تغيّرت، ثابتة، زادت، نقصت، زادت بقدر...)،
 * تعديل قيمة، تعديل الكل، تجميد، وقائمة محفوظة بقيمها الحيّة.
 */
class MemPanel(
    private val c: Context,
    private val getPkg: () -> String?,
    private val focusInput: (EditText) -> Unit,     // يفعّل لوحة المفاتيح (النافذة تصير قابلة للتركيز)
    private val releaseInput: () -> Unit,           // يخفي لوحة المفاتيح ويرجّع النافذة لغير قابلة للتركيز
    private val onBack: () -> Unit
) : LinearLayout(c) {

    private class Sel(val type: String, val addr: Long)

    private val d = c.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private val ui = Handler(Looper.getMainLooper())

    private var typeIdx = 0
    private var searchMode = "eq"                       // eq | rng | unk
    private val regions = linkedSetOf("A", "Ca", "Cb", "Cd", "Jh")
    private var nextMode = "eq"
    private var tabIdx = 0                              // 0 نتائج | 1 محفوظ
    private var busy = false
    private var state = 0                               // 0 لا نتائج | 1 قائمة | 2 لقطة (قيمة مجهولة)
    private var total = 0L
    private var page = 0
    private var scanType = "i32"
    private var hits: List<Mem.Hit> = emptyList()
    private var sel: Sel? = null
    private val frozenSet = HashSet<Long>()
    private var confirmAll = false
    private var live = false
    private var savedVals: List<String> = emptyList()

    // ------------------------------------------------------------------ أدوات صغيرة
    private fun tv(text: String, size: Float = 12f, color: Int = Theme.TEXT, bold: Boolean = false): TextView =
        TextView(c).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun chip(text: String, onClick: () -> Unit): TextView =
        tv(text, 11f, Theme.TEXT, true).apply {
            gravity = Gravity.CENTER
            isClickable = true
            setPadding(dp(4), dp(9), dp(4), dp(9))
            setOnClickListener { onClick() }
        }

    private fun styleChip(t: TextView, on: Boolean, accent: Int = Theme.CYAN) {
        val r = dp(10).toFloat()
        t.background = withRipple(rounded(if (on) accent else Theme.GLASS, r, if (on) 0 else dp(1), 0x2200E5FF), r)
        t.setTextColor(if (on) Theme.DARK else Theme.TEXT)
    }

    private fun bigBtn(text: String, bg: Int, fg: Int, onClick: () -> Unit): TextView =
        tv(text, 13f, fg, true).apply {
            gravity = Gravity.CENTER
            isClickable = true
            setPadding(dp(8), dp(11), dp(8), dp(11))
            val r = dp(12).toFloat()
            background = withRipple(rounded(bg, r), r)
            setOnClickListener { onClick() }
        }

    private fun inputField(hintText: String): EditText = EditText(c).apply {
        this.hint = hintText
        setHintTextColor(Theme.MUTED)
        setTextColor(Theme.TEXT)
        textSize = 14f
        setSingleLine(true)
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        textDirection = View.TEXT_DIRECTION_LTR
        gravity = Gravity.CENTER
        imeOptions = EditorInfo.IME_ACTION_DONE
        setPadding(dp(8), dp(9), dp(8), dp(9))
        background = rounded(Theme.GLASS2, dp(10).toFloat(), dp(1), 0x3300E5FF)
        setSelectAllOnFocus(true)
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> focusInput(v as EditText)
                // بعد ما تتفعّل النافذة ويصير التركيز (focusInput ينتظر 120ms) نحدّد النص كله عشان تكتب فوقه مباشرة
                MotionEvent.ACTION_UP -> v.postDelayed({ (v as EditText).selectAll() }, 260)
            }
            false
        }
        setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) { releaseInput(); true } else false
        }
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f, top: Int = 0, start: Int = 0, end: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply {
            topMargin = dp(top)
            marginStart = dp(start)
            marginEnd = dp(end)
        }

    private fun row(): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_LTR
    }

    private fun clean(s: String) = s.trim().replace(Regex("\\s+"), "").replace(',', '.')
    private fun typeCode() = Mem.TYPES[typeIdx].first
    private fun typeLabel(code: String) = Mem.TYPES.firstOrNull { it.first == code }?.second ?: code

    // ------------------------------------------------------------------ العناصر
    private val valueEdit = inputField("القيمة")
    private val value2Edit = inputField("إلى").apply { visibility = View.GONE }
    private val typeBtn = chip("") { cycleType() }
    private val modeBtn = chip("") { cycleMode() }
    private val scanBtn = bigBtn("بحث جديد", Theme.GREEN, Theme.DARK) { doScan() }
    private val nextBtn = bigBtn("بحث تالي", Theme.CYAN, Theme.DARK) { doNext() }
    private val clearBtn = chip("مسح") { doClear() }
    private val cancelBtn = chip("إلغاء") { cancelWork() }.apply { visibility = View.GONE }
    private val status = tv("", 11f, Theme.MUTED).apply { maxLines = 4; ellipsize = TextUtils.TruncateAt.END }
    private val tabRes = chip("النتائج") { setTab(0) }
    private val tabSaved = chip("المحفوظ") { setTab(1) }

    private val regionChips = Mem.REGIONS.map { (code, label) ->
        code to chip(label) { toggleRegion(code) }
    }
    private val nextDefs = listOf(
        "eq" to "=", "ne" to "≠", "rng" to "نطاق", "chg" to "تغيّرت", "unch" to "ثابتة",
        "inc" to "زادت", "dec" to "نقصت", "incby" to "+ بقدر", "decby" to "− بقدر"
    )
    private val nextChips = nextDefs.map { (code, label) -> code to chip(label) { setNextMode(code) } }

    private val searchSection = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
    private val resultsBox = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Theme.GLASS, dp(12).toFloat())
    }
    private val pageLabel = tv("", 11f, Theme.MUTED, true).apply { gravity = Gravity.CENTER }
    private val prevBtn = chip("◀") { gotoPage(page - 1) }
    private val nextPageBtn = chip("▶") { gotoPage(page + 1) }
    private val refreshBtn = chip("↻") { if (tabIdx == 0) loadPage() else refreshSaved() }
    private val pagerRow = row()

    private val savedBox = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(Theme.GLASS, dp(12).toFloat())
        visibility = View.GONE
    }

    private val selLabel = tv("اضغط على نتيجة لتحديدها", 11f, Theme.MUTED, true)
    private val editVal = inputField("القيمة الجديدة")
    private val setBtn = bigBtn("تعديل", Theme.GREEN, Theme.DARK) { applySet() }
    private val freezeBtn = bigBtn("❄ تجميد", Theme.CYAN, Theme.DARK) { toggleFreeze() }
    private val saveBtn = bigBtn("★ حفظ", Theme.GLASS2, Theme.TEXT) { saveSel() }
    private val allBtn = bigBtn("تعديل الكل", Theme.ORANGE, Theme.DARK) { editAll() }
    private val unfreezeBtn = bigBtn("فك كل التجميد", Theme.GLASS2, Theme.TEXT) { unfreezeAll() }
    private val editBar = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(10), dp(8), dp(10), dp(10))
        background = rounded(Theme.GLASS2, dp(14).toFloat(), dp(1), 0x3300E5FF)
    }

    init {
        orientation = LinearLayout.VERTICAL

        // ---- العنوان
        val back = bigBtn("رجوع", Theme.GLASS2, Theme.TEXT) { onBack() }
        back.setPadding(dp(14), dp(8), dp(14), dp(8))
        val head = row()
        head.layoutDirection = View.LAYOUT_DIRECTION_RTL
        head.addView(tv("🔍 بحث وتغيير القيم", 14f, Theme.TEXT, true), lp(0, WRAP, 1f))
        head.addView(back, lp(WRAP, WRAP))
        addView(head, lp(MATCH, WRAP, top = 6))

        // ---- التبويبات
        val tabs = row()
        tabs.addView(tabRes, lp(0, WRAP, 1f, end = 4))
        tabs.addView(tabSaved, lp(0, WRAP, 1f, start = 4))
        addView(tabs, lp(MATCH, WRAP, top = 8))

        // ---- البحث
        val inputs = row()
        inputs.addView(valueEdit, lp(0, WRAP, 1f, end = 4))
        inputs.addView(value2Edit, lp(0, WRAP, 1f, start = 4, end = 4))
        inputs.addView(typeBtn, lp(dp(84), WRAP, start = 4))
        searchSection.addView(inputs, lp(MATCH, WRAP, top = 8))

        val modes = row()
        modes.addView(modeBtn, lp(0, WRAP, 1f, end = 4))
        modes.addView(scanBtn, lp(0, WRAP, 1.3f, start = 4))
        searchSection.addView(modes, lp(MATCH, WRAP, top = 8))

        searchSection.addView(tv("تضييق النتائج (بعد ما تغيّر القيمة في اللعبة)", 10f, Theme.MUTED), lp(MATCH, WRAP, top = 10))
        val nx1 = row()
        val nx2 = row()
        nextChips.forEachIndexed { i, p ->
            (if (i < 5) nx1 else nx2).addView(p.second, lp(0, WRAP, 1f, start = 3, end = 3))
        }
        searchSection.addView(nx1, lp(MATCH, WRAP, top = 4))
        searchSection.addView(nx2, lp(MATCH, WRAP, top = 6))
        val nxActions = row()
        nxActions.addView(nextBtn, lp(0, WRAP, 1f, end = 4))
        nxActions.addView(clearBtn, lp(dp(70), WRAP, start = 4))
        searchSection.addView(nxActions, lp(MATCH, WRAP, top = 8))
        searchSection.addView(tv("مناطق الذاكرة", 10f, Theme.MUTED), lp(MATCH, WRAP, top = 10))
        val rg1 = row()
        val rg2 = row()
        regionChips.forEachIndexed { i, p ->
            (if (i < 3) rg1 else rg2).addView(p.second, lp(0, WRAP, 1f, start = 3, end = 3))
        }
        searchSection.addView(rg1, lp(MATCH, WRAP, top = 4))
        searchSection.addView(rg2, lp(MATCH, WRAP, top = 6))

        addView(searchSection, lp(MATCH, WRAP))

        // ---- الحالة
        val st = row()
        st.layoutDirection = View.LAYOUT_DIRECTION_RTL
        st.addView(status, lp(0, WRAP, 1f))
        st.addView(cancelBtn, lp(dp(70), WRAP, start = 6))
        addView(st, lp(MATCH, WRAP, top = 8))

        // ---- النتائج + التنقل
        addView(resultsBox, lp(MATCH, WRAP, top = 6))
        pagerRow.addView(prevBtn, lp(dp(46), WRAP))
        pagerRow.addView(pageLabel, lp(0, WRAP, 1f))
        pagerRow.addView(refreshBtn, lp(dp(46), WRAP, end = 6))
        pagerRow.addView(nextPageBtn, lp(dp(46), WRAP))
        addView(pagerRow, lp(MATCH, WRAP, top = 6))
        addView(savedBox, lp(MATCH, WRAP, top = 6))

        // ---- شريط التعديل
        editBar.addView(selLabel, lp(MATCH, WRAP))
        editBar.addView(editVal, lp(MATCH, WRAP, top = 6))
        val ea = row()
        ea.addView(setBtn, lp(0, WRAP, 1f, end = 3))
        ea.addView(freezeBtn, lp(0, WRAP, 1f, start = 3, end = 3))
        ea.addView(saveBtn, lp(0, WRAP, 1f, start = 3))
        editBar.addView(ea, lp(MATCH, WRAP, top = 8))
        val eb = row()
        eb.addView(allBtn, lp(0, WRAP, 1f, end = 3))
        eb.addView(unfreezeBtn, lp(0, WRAP, 1f, start = 3))
        editBar.addView(eb, lp(MATCH, WRAP, top = 6))
        addView(editBar, lp(MATCH, WRAP, top = 10))

        restyle()
        applyInputTypes()
        renderHits()
        renderPager()
        updateEditBar()
    }

    // ------------------------------------------------------------------ دورة الحياة
    private val tick = object : Runnable {
        override fun run() {
            if (!live) return
            if (!busy && Mem.isRunning()) {
                if (tabIdx == 0 && state == 1) loadPage(true)
                else if (tabIdx == 1 && Mem.saved.isNotEmpty()) refreshSaved()
            }
            ui.postDelayed(this, 1500)
        }
    }

    fun onShow() {
        live = true
        ui.removeCallbacks(tick)
        ui.postDelayed(tick, 1500)
        restyle()
        renderSaved()
    }

    fun onHide() {
        live = false
        ui.removeCallbacks(tick)
    }

    // ------------------------------------------------------------------ الواجهة
    private fun restyle() {
        typeBtn.text = Mem.TYPES[typeIdx].second
        styleChip(typeBtn, true, Theme.CYAN)
        modeBtn.text = when (searchMode) {
            "rng" -> "بحث بنطاق"
            "unk" -> "قيمة مجهولة"
            else -> "قيمة محددة"
        }
        styleChip(modeBtn, true, Theme.CYAN)
        for ((code, ch) in regionChips) styleChip(ch, code in regions, Theme.GREEN)
        for ((code, ch) in nextChips) styleChip(ch, code == nextMode, Theme.CYAN)
        styleChip(tabRes, tabIdx == 0)
        styleChip(tabSaved, tabIdx == 1)
        tabSaved.text = "المحفوظ (" + Mem.saved.size + ")"
        styleChip(clearBtn, false)
        styleChip(cancelBtn, true, Theme.RED)
        cancelBtn.setTextColor(Color.WHITE)
        for (b in listOf(prevBtn, nextPageBtn, refreshBtn)) styleChip(b, false)
        value2Edit.visibility = if ((state != 0 && nextMode == "rng") || (state == 0 && searchMode == "rng")) View.VISIBLE else View.GONE
        valueEdit.hint = if (searchMode == "unk" && state == 0) "—" else if (value2Edit.visibility == View.VISIBLE) "من" else "القيمة"
        val a = if (busy) 0.5f else 1f
        scanBtn.alpha = a
        nextBtn.alpha = a
        searchSection.visibility = if (tabIdx == 0) View.VISIBLE else View.GONE
        resultsBox.visibility = if (tabIdx == 0) View.VISIBLE else View.GONE
        pagerRow.visibility = if (tabIdx == 0 && state == 1 && total > PAGE_SIZE) View.VISIBLE else View.GONE
        savedBox.visibility = if (tabIdx == 1) View.VISIBLE else View.GONE
        cancelBtn.visibility = if (busy) View.VISIBLE else View.GONE
    }

    private fun applyInputTypes() {
        val f = typeCode().startsWith("f")
        val t = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED or
            (if (f) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0)
        for (e in listOf(valueEdit, value2Edit, editVal)) e.inputType = t
    }

    private fun setStatus(s: String, color: Int = Theme.MUTED) {
        status.text = s
        status.setTextColor(color)
    }

    private fun setBusy(on: Boolean, msg: String = "") {
        busy = on
        if (msg.isNotEmpty()) setStatus(msg, Theme.CYAN)
        restyle()
    }

    private fun cycleType() {
        if (state != 0) { setStatus("النوع ثابت أثناء البحث الحالي. اضغط «مسح» لتغييره.", Theme.ORANGE); return }
        typeIdx = (typeIdx + 1) % Mem.TYPES.size
        applyInputTypes()
        restyle()
    }

    private fun cycleMode() {
        if (state != 0) { setStatus("اضغط «مسح» لبدء بحث جديد بنمط مختلف، أو «بحث جديد» لإعادة البحث.", Theme.ORANGE) }
        searchMode = when (searchMode) { "eq" -> "rng"; "rng" -> "unk"; else -> "eq" }
        restyle()
    }

    private fun toggleRegion(code: String) {
        if (code in regions) regions.remove(code) else regions.add(code)
        restyle()
    }

    private fun setNextMode(code: String) {
        nextMode = code
        restyle()
    }

    private fun setTab(i: Int) {
        tabIdx = i
        sel = null
        updateEditBar()
        restyle()
        if (i == 1) { renderSaved(); refreshSaved() } else renderHits()
    }

    private fun cancelWork() {
        Mem.close()
        frozenSet.clear()
        state = 0
        total = 0
        hits = emptyList()
        sel = null
        setBusy(false)
        setStatus("أُلغي. تم إيقاف محرك الذاكرة (والتجميد).", Theme.ORANGE)
        renderHits()
        renderPager()
        updateEditBar()
    }

    // ------------------------------------------------------------------ البحث
    private fun pkgOrWarn(): String? {
        val p = getPkg()
        if (p == null) { setStatus("اختر اللعبة أولًا (من الصفحة الرئيسية للوحة).", Theme.ORANGE); return null }
        if (Engine.isBlocked(p)) {
            setStatus("هذا تطبيق أونلاين وفيه حظر للحسابات، الأداة ترفض تشتغل عليه.", Theme.RED)
            return null
        }
        return p
    }

    private fun doScan() {
        if (busy) return
        releaseInput()
        val pkg = pkgOrWarn() ?: return
        val v1 = clean(valueEdit.text.toString())
        val v2 = clean(value2Edit.text.toString())
        if (searchMode != "unk" && v1.isEmpty()) { setStatus("اكتب القيمة أولًا.", Theme.ORANGE); return }
        if (searchMode == "rng" && v2.isEmpty()) { setStatus("اكتب حدّي النطاق (من / إلى).", Theme.ORANGE); return }
        if (regions.isEmpty()) { setStatus("اختر منطقة ذاكرة واحدة على الأقل.", Theme.ORANGE); return }
        val type = typeCode()
        val a = if (searchMode == "unk") "-" else v1
        val b = if (searchMode == "rng") v2 else "-"
        scanType = type
        sel = null
        state = 0
        setBusy(true, "جاري البحث...")
        Mem.call(
            c,
            listOf("attachpkg $pkg", "scan $type $searchMode $a $b ${regions.joinToString(",")}"),
            { p -> if (busy) setStatus("جاري البحث... $p%", Theme.CYAN) }
        ) { r -> onSearchDone(r) }
    }

    private fun doNext() {
        if (busy) return
        releaseInput()
        val pkg = pkgOrWarn() ?: return
        if (state == 0) { setStatus("ابدأ بحثًا أولًا (بحث جديد).", Theme.ORANGE); return }
        val v1 = clean(valueEdit.text.toString())
        val v2 = clean(value2Edit.text.toString())
        val needs = nextMode in listOf("eq", "ne", "rng", "incby", "decby")
        if (needs && v1.isEmpty()) { setStatus("اكتب القيمة أولًا.", Theme.ORANGE); return }
        if (nextMode == "rng" && v2.isEmpty()) { setStatus("اكتب حدّي النطاق (من / إلى).", Theme.ORANGE); return }
        val a = if (needs) v1 else "-"
        val b = if (nextMode == "rng") v2 else "-"
        setBusy(true, "جاري التضييق...")
        Mem.call(
            c,
            listOf("attachpkg $pkg", "next $nextMode $a $b"),
            { p -> if (busy) setStatus("جاري التضييق... $p%", Theme.CYAN) }
        ) { r -> onSearchDone(r) }
    }

    private fun onSearchDone(r: Mem.Reply) {
        setBusy(false)
        if (!r.ok) {
            setStatus(r.text, Theme.RED)
            if (r.text.contains("ما فيه نتائج")) { state = 0; total = 0; hits = emptyList(); renderHits(); renderPager(); restyle() }
            return
        }
        val t = r.text.split(" ")
        total = t.getOrNull(0)?.toLongOrNull() ?: 0L
        state = if (t.getOrNull(1) == "snap") 2 else 1
        val trunc = t.contains("TRUNC")
        page = 0
        sel = null
        updateEditBar()
        if (state == 1) {
            setStatus(
                total.toString() + " نتيجة" + (if (trunc) " (وصلنا الحد الأعلى، ضيّق البحث)" else "") +
                    if (total == 0L) " — جرّب نوع/منطقة مختلفة" else "",
                if (total == 0L) Theme.ORANGE else Theme.GREEN
            )
            loadPage()
        } else {
            setStatus("$total خانة (قيمة مجهولة). غيّر القيمة في اللعبة ثم اختر تضييق (تغيّرت / زادت / نقصت ...) واضغط «بحث تالي».", Theme.CYAN)
            hits = emptyList()
            renderHits()
            renderPager()
        }
        restyle()
    }

    private fun doClear() {
        if (busy) return
        releaseInput()
        Mem.call(c, listOf("clear")) { }
        state = 0
        total = 0
        hits = emptyList()
        sel = null
        page = 0
        setStatus("تم مسح النتائج.", Theme.MUTED)
        renderHits()
        renderPager()
        updateEditBar()
        restyle()
    }

    private fun gotoPage(p: Int) {
        val last = if (total <= 0) 0 else ((total - 1) / PAGE_SIZE).toInt()
        page = p.coerceIn(0, last)
        loadPage()
    }

    private fun loadPage(silent: Boolean = false) {
        if (state != 1) { hits = emptyList(); renderHits(); renderPager(); return }
        val reqPage = page
        Mem.call(c, listOf("list ${reqPage * PAGE_SIZE} $PAGE_SIZE")) { r ->
            if (r.ok) {
                if (reqPage == page && state == 1) {
                    hits = Mem.hits(r.rows)
                    for (h in hits) { if (h.frozen) frozenSet.add(h.addr) else frozenSet.remove(h.addr) }
                    renderHits()
                    renderPager()
                }
            } else if (!silent) {
                setStatus(r.text, Theme.RED)
            }
        }
    }

    // ------------------------------------------------------------------ عرض النتائج
    private fun renderPager() {
        val last = if (total <= 0) 1 else ((total - 1) / PAGE_SIZE).toInt() + 1
        pageLabel.text = "${page + 1} / $last   ($total)"
        restyle()
    }

    private fun renderHits() {
        resultsBox.removeAllViews()
        if (hits.isEmpty()) {
            val msg = when (state) {
                0 -> "ما فيه نتائج بعد"
                2 -> "وضع القيمة المجهولة: ما نعرض القائمة لين تضيّق النتائج"
                else -> "ما فيه نتائج"
            }
            resultsBox.addView(tv(msg, 11f, Theme.MUTED).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(16), dp(8), dp(16))
            }, lp(MATCH, WRAP))
            return
        }
        for (h in hits) resultsBox.addView(hitRow(h), lp(MATCH, WRAP))
    }

    private fun itemBg(on: Boolean) =
        if (on) rounded(0x3300E5FF, dp(8).toFloat())
        else RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null, ColorDrawable(Color.WHITE))

    private fun hitRow(h: Mem.Hit): View {
        val r = row()
        r.setPadding(dp(8), dp(8), dp(8), dp(8))
        r.isClickable = true
        r.background = itemBg(sel?.addr == h.addr)
        r.setOnClickListener { select(scanType, h.addr, h.value) }
        val addr = tv(java.lang.Long.toHexString(h.addr).uppercase(), 10f, Theme.MUTED).apply {
            typeface = Typeface.MONOSPACE
            maxLines = 1
        }
        val reg = tv(h.region, 9f, Theme.ICE, true).apply { gravity = Gravity.CENTER }
        val frz = h.addr in frozenSet
        val value = tv((if (frz) "❄ " else "") + h.value, 13f, if (frz) Theme.ICE else Theme.CYAN, true).apply {
            gravity = Gravity.END
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val star = tv("★", 16f, Theme.ORANGE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(2), dp(4), dp(2))
            isClickable = true
            setOnClickListener { saveItem(scanType, h.addr) }
        }
        r.addView(addr, lp(0, WRAP, 1.5f))
        r.addView(reg, lp(dp(26), WRAP))
        r.addView(value, lp(0, WRAP, 1.2f, start = 6))
        r.addView(star, lp(WRAP, WRAP))
        return r
    }

    // ------------------------------------------------------------------ المحفوظ
    private fun renderSaved() {
        restyle()
        savedBox.removeAllViews()
        val list = Mem.saved
        if (list.isEmpty()) {
            savedBox.addView(tv("القائمة فاضية. اضغط ★ جنب أي نتيجة لحفظها هنا.", 11f, Theme.MUTED).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(16), dp(8), dp(16))
            }, lp(MATCH, WRAP))
            return
        }
        for ((i, s) in list.withIndex()) {
            val r = row()
            r.setPadding(dp(8), dp(8), dp(8), dp(8))
            r.isClickable = true
            r.background = itemBg(sel?.addr == s.addr)
            val v = savedVals.getOrNull(i) ?: "…"
            r.setOnClickListener { select(s.type, s.addr, v) }
            val frz = s.addr in frozenSet
            r.addView(tv(typeLabel(s.type), 9f, Theme.ICE, true), lp(dp(44), WRAP))
            r.addView(tv(java.lang.Long.toHexString(s.addr).uppercase(), 10f, Theme.MUTED).apply {
                typeface = Typeface.MONOSPACE
                maxLines = 1
            }, lp(0, WRAP, 1.5f))
            r.addView(tv((if (frz) "❄ " else "") + v, 13f, if (frz) Theme.ICE else Theme.CYAN, true).apply {
                gravity = Gravity.END
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, lp(0, WRAP, 1.2f, start = 6))
            r.addView(tv("✕", 15f, Theme.RED, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(2), dp(4), dp(2))
                isClickable = true
                setOnClickListener {
                    Mem.saved.remove(s)
                    if (sel?.addr == s.addr) { sel = null; updateEditBar() }
                    savedVals = emptyList()
                    renderSaved()
                    refreshSaved()
                }
            }, lp(WRAP, WRAP))
            savedBox.addView(r, lp(MATCH, WRAP))
        }
    }

    private fun refreshSaved() {
        val list = ArrayList(Mem.saved)
        if (list.isEmpty()) { savedVals = emptyList(); renderSaved(); return }
        val cmd = "getmany " + list.joinToString(" ") { it.type + ":" + java.lang.Long.toHexString(it.addr) }
        Mem.call(c, listOf(cmd)) { r ->
            if (r.ok && tabIdx == 1) {
                savedVals = r.text.split(" ")
                renderSaved()
            }
        }
    }

    private fun saveItem(type: String, addr: Long) {
        if (Mem.saved.none { it.addr == addr && it.type == type }) Mem.saved.add(Mem.Saved(type, addr))
        setStatus("تم حفظ العنوان في «المحفوظ» (${Mem.saved.size}).", Theme.GREEN)
        restyle()
    }

    // ------------------------------------------------------------------ التعديل
    private fun select(type: String, addr: Long, value: String) {
        sel = Sel(type, addr)
        editVal.setText(if (value == "??" || value == "…") "" else value)
        editVal.selectAll()
        updateEditBar()
        if (tabIdx == 0) renderHits() else renderSaved()
    }

    private fun updateEditBar() {
        val s = sel
        val show = (tabIdx == 0 && state != 0) || (tabIdx == 1 && s != null)
        editBar.visibility = if (show) View.VISIBLE else View.GONE
        if (s == null) {
            selLabel.text = "اضغط على نتيجة لتحديدها (أو «تعديل الكل»)"
            selLabel.setTextColor(Theme.MUTED)
        } else {
            selLabel.text = typeLabel(s.type) + "  @  " + java.lang.Long.toHexString(s.addr).uppercase()
            selLabel.setTextColor(Theme.CYAN)
        }
        val frz = s != null && s.addr in frozenSet
        freezeBtn.text = if (frz) "فك التجميد" else "❄ تجميد"
        val on = s != null
        for (b in listOf(setBtn, freezeBtn, saveBtn)) b.alpha = if (on) 1f else 0.4f
        allBtn.visibility = if (tabIdx == 0 && state == 1) View.VISIBLE else View.GONE
        allBtn.text = if (confirmAll) "تأكيد: تعديل $total" else "تعديل الكل"
    }

    private fun afterEdit() {
        if (tabIdx == 0) loadPage() else refreshSaved()
    }

    private fun applySet() {
        val s = sel ?: run { setStatus("حدّد نتيجة أولًا.", Theme.ORANGE); return }
        val v = clean(editVal.text.toString())
        if (v.isEmpty()) { setStatus("اكتب القيمة الجديدة.", Theme.ORANGE); return }
        releaseInput()
        Mem.call(c, listOf("set ${s.type} ${java.lang.Long.toHexString(s.addr)} $v")) { r ->
            if (r.ok) { setStatus("تم التعديل ✓", Theme.GREEN); afterEdit() } else setStatus(r.text, Theme.RED)
        }
    }

    private fun toggleFreeze() {
        val s = sel ?: run { setStatus("حدّد نتيجة أولًا.", Theme.ORANGE); return }
        releaseInput()
        val hex = java.lang.Long.toHexString(s.addr)
        if (s.addr in frozenSet) {
            Mem.call(c, listOf("unfreeze $hex")) { r ->
                if (r.ok) { frozenSet.remove(s.addr); setStatus("تم فك التجميد.", Theme.MUTED); updateEditBar(); afterEdit() }
                else setStatus(r.text, Theme.RED)
            }
            return
        }
        val v = clean(editVal.text.toString())
        if (v.isEmpty()) { setStatus("اكتب القيمة اللي تبي تثبّتها.", Theme.ORANGE); return }
        Mem.call(c, listOf("freeze ${s.type} $hex $v")) { r ->
            if (r.ok) { frozenSet.add(s.addr); setStatus("تم التجميد ❄ ($v)", Theme.ICE); updateEditBar(); afterEdit() }
            else setStatus(r.text, Theme.RED)
        }
    }

    private fun saveSel() {
        val s = sel ?: run { setStatus("حدّد نتيجة أولًا.", Theme.ORANGE); return }
        saveItem(s.type, s.addr)
    }

    private fun editAll() {
        if (state != 1) return
        releaseInput()
        val v = clean(editVal.text.toString())
        if (v.isEmpty()) { setStatus("اكتب القيمة الجديدة أولًا.", Theme.ORANGE); return }
        if (!confirmAll) {
            confirmAll = true
            updateEditBar()
            ui.postDelayed({ confirmAll = false; updateEditBar() }, 4000)
            return
        }
        confirmAll = false
        updateEditBar()
        Mem.call(c, listOf("setall $v $total")) { r ->
            if (r.ok) { setStatus("تم تعديل ${r.text} عنوان ✓", Theme.GREEN); loadPage() } else setStatus(r.text, Theme.RED)
        }
    }

    private fun unfreezeAll() {
        releaseInput()
        Mem.call(c, listOf("unfreezeall")) { r ->
            if (r.ok) {
                frozenSet.clear()
                setStatus("تم فك كل التجميد.", Theme.MUTED)
                updateEditBar()
                afterEdit()
            } else setStatus(r.text, Theme.RED)
        }
    }

    companion object {
        private const val PAGE_SIZE = 30
        private const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
        private const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT
    }
}
