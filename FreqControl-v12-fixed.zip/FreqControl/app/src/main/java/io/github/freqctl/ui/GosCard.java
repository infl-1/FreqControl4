package io.github.freqctl.ui;

import android.view.View;

import com.google.android.material.materialswitch.MaterialSwitch;

import io.github.freqctl.R;
import io.github.freqctl.extras.ExtraSettings;

/** Game Optimizing Service card: three switches that stop GOS from capping CPU/GPU frequency in games. */
final class GosCard {
    interface Listener {
        void onGosToggle(String key, boolean on);
    }

    private final MaterialSwitch caps;
    private final MaterialSwitch ipm;
    private final MaterialSwitch levels;
    private boolean binding;

    GosCard(View root, Listener listener) {
        caps = root.findViewById(R.id.gos_caps_switch);
        ipm = root.findViewById(R.id.gos_ipm_switch);
        levels = root.findViewById(R.id.gos_levels_switch);
        caps.setOnCheckedChangeListener((button, checked) -> {
            if (!binding) {
                listener.onGosToggle(ExtraSettings.K_GOS_CAPS, checked);
            }
        });
        ipm.setOnCheckedChangeListener((button, checked) -> {
            if (!binding) {
                listener.onGosToggle(ExtraSettings.K_GOS_IPM, checked);
            }
        });
        levels.setOnCheckedChangeListener((button, checked) -> {
            if (!binding) {
                listener.onGosToggle(ExtraSettings.K_GOS_LEVELS, checked);
            }
        });
    }

    void bind(boolean blockCaps, boolean blockIpm, boolean blockLevels) {
        binding = true;
        try {
            caps.setChecked(blockCaps);
            ipm.setChecked(blockIpm);
            levels.setChecked(blockLevels);
        } finally {
            binding = false;
        }
    }
}
