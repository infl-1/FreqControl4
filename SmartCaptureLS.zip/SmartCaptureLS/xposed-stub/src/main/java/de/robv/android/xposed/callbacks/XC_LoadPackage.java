package de.robv.android.xposed.callbacks;
public abstract class XC_LoadPackage extends XCallback {
    public static final class LoadPackageParam extends XCallback.Param {
        public String packageName;
        public String processName;
        public ClassLoader classLoader;
        public Object appInfo;            // android.content.pm.ApplicationInfo in the real API
        public boolean isFirstApplication;
    }
}
