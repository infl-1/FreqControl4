package com.example.tiksaver

import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var linkInput: EditText
    private lateinit var downloadBtn: Button
    private lateinit var updateBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    private var ready = false
    private val urlRegex = Regex("""https?://\S+""")
    private val videoExtensions = setOf("mp4", "mkv", "webm", "mov")
    private val supportedDomains = listOf(
        "tiktok.com",
        "snapchat.com",
        "x.com", "twitter.com", "t.co",
        "youtube.com", "youtu.be"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        linkInput = findViewById(R.id.linkInput)
        downloadBtn = findViewById(R.id.downloadBtn)
        updateBtn = findViewById(R.id.updateBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.pasteBtn).setOnClickListener { pasteFromClipboard() }
        downloadBtn.setOnClickListener { startDownload() }
        updateBtn.setOnClickListener { updateEngine() }

        handleShareIntent(intent)
        initEngine()
    }

    // لو التطبيق مفتوح وجاء رابط جديد من "مشاركة" ما نفتح نسخة ثانية، نستخدم نفس الشاشة
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    private fun handleShareIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT))?.let { linkInput.setText(it) }
        }
    }

    // ---------- المحرك ----------

    private fun initEngine() {
        busy(true)
        status.text = "جاري تجهيز المحرك (أول مرة فقط، ممكن ياخذ شوي)..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().init(applicationContext)
                    FFmpeg.getInstance().init(applicationContext)
                }
                ready = true
                status.text = "جاهز ✅"
            } catch (e: Exception) {
                status.text = "تعذر تجهيز المحرك: ${e.message}"
            } finally {
                busy(false)
            }
        }
    }

    private fun updateEngine() {
        busy(true)
        status.text = "جاري تحديث المحرك..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().updateYoutubeDL(applicationContext, YoutubeDL.UpdateChannel.STABLE)
                }
                status.text = "تم تحديث المحرك ✅"
            } catch (e: Exception) {
                status.text = "فشل التحديث، تأكد من الإنترنت"
            } finally {
                busy(false)
            }
        }
    }

    // ---------- التحميل ----------

    private fun startDownload() {
        val url = extractUrl(linkInput.text.toString())
        if (url == null || !isSupported(url)) {
            status.text = "الرابط غير مدعوم. المدعوم: تيك توك، سناب شات، X، يوتيوب"
            return
        }
        linkInput.setText(url)
        busy(true, determinate = true)
        status.text = "جاري التحميل..."

        lifecycleScope.launch {
            try {
                val file = downloadVideo(url)
                withContext(Dispatchers.IO) {
                    saveToGallery(file)
                    file.delete()
                }
                status.text = "تم الحفظ في المعرض (Movies/TikSaver) ✅"
            } catch (e: Exception) {
                status.text = "فشل التحميل. تأكد من الرابط، أو اضغط «تحديث المحرك» وحاول مرة ثانية."
            } finally {
                busy(false)
            }
        }
    }

    private suspend fun downloadVideo(url: String): File = withContext(Dispatchers.IO) {
        val dir = File(cacheDir, "dl").apply {
            deleteRecursively()
            mkdirs()
        }
        val request = YoutubeDLRequest(url)
        request.addOption("-o", "${dir.absolutePath}/%(id)s.%(ext)s")
        request.addOption("-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b") // أعلى جودة
        request.addOption("--merge-output-format", "mp4")
        request.addOption("--no-playlist")

        YoutubeDL.getInstance().execute(request, "tiktok-download") { p, _, _ ->
            runOnUiThread { progress.progress = p.toInt().coerceIn(0, 100) }
        }

        dir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in videoExtensions }
            ?.maxByOrNull { it.length() }
            ?: throw IOException("لم يتم العثور على الملف")
    }

    private fun saveToGallery(file: File) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "video_${System.currentTimeMillis()}.${file.extension}")
            put(MediaStore.Video.Media.MIME_TYPE, mimeFor(file.extension))
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TikSaver")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri: Uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("تعذر إنشاء الملف في المعرض")

        resolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        } ?: throw IOException("تعذر الكتابة في المعرض")

        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
    }

    // ---------- أدوات مساعدة ----------

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString()
        val url = extractUrl(text)
        if (url != null) linkInput.setText(url) else status.text = "ما لقيت رابط في الحافظة"
    }

    private fun extractUrl(text: String?): String? = text?.let { urlRegex.find(it)?.value }

    private fun isSupported(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        return supportedDomains.any { host == it || host.endsWith(".$it") }
    }

    private fun mimeFor(ext: String): String = when (ext.lowercase()) {
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        else -> "video/mp4"
    }

    private fun busy(on: Boolean, determinate: Boolean = false) {
        progress.visibility = if (on) View.VISIBLE else View.GONE
        progress.isIndeterminate = !determinate
        progress.progress = 0
        downloadBtn.isEnabled = !on && ready
        updateBtn.isEnabled = !on
    }
}
