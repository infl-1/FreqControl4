package de.robv.android.xposed;

/** Stub: logging and method hooking. */
public final class XposedBridge {
    private XposedBridge() {
    }

    public static synchronized void log(String text) {
        throw new UnsupportedOperationException("stub");
    }

    public static synchronized void log(Throwable t) {
        throw new UnsupportedOperationException("stub");
    }

    public static java.util.Set<XC_MethodHook.Unhook> hookAllMethods(Class<?> hookClass, String methodName,
                                                                      XC_MethodHook callback) {
        throw new UnsupportedOperationException("stub");
    }

    public static XC_MethodHook.Unhook hookMethod(java.lang.reflect.Member hookMethod, XC_MethodHook callback) {
        throw new UnsupportedOperationException("stub");
    }
}
