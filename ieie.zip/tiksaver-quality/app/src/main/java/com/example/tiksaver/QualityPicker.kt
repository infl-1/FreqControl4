package com.example.tiksaver

import android.content.Context
import androidx.appcompat.app.AlertDialog
import com.yausername.youtubedl_android.YoutubeDLRequest

/** خيارات الجودة: من الأصلية (الأعلى) نزولاً إلى 144p، وصوت فقط. */
enum class Quality(val label: String, val height: Int?) {
    ORIGINAL("الأصلية (أعلى جودة)", null),
    P2160("2160p (4K)", 2160),
    P1440("1440p", 1440),
    P1080("1080p", 1080),
    P720("720p", 720),
    P480("480p", 480),
    P360("360p", 360),
    P240("240p", 240),
    P144("144p", 144),
    AUDIO("صوت فقط (MP3)", null)
}

object QualityPicker {

    /** يعرض قائمة الجودات، وعند الاختيار يستدعي onSelected. */
    fun show(context: Context, onSelected: (Quality) -> Unit) {
        val items = Quality.values()
        AlertDialog.Builder(context)
            .setTitle("اختر الجودة")
            .setItems(items.map { it.label }.toTypedArray()) { _, i ->
                onSelected(items[i])
            }
            .show()
    }

    /**
     * يضيف خيارات yt-dlp حسب الجودة المختارة.
     * استدعها قبل تنفيذ التحميل، واحذف أي سطر "-f" قديم في كودك.
     */
    fun apply(request: YoutubeDLRequest, q: Quality) {
        when (q) {
            Quality.AUDIO -> {
                request.addOption("-f", "ba/b")
                request.addOption("-x")
                request.addOption("--audio-format", "mp3")
                request.addOption("--audio-quality", "0")
            }
            Quality.ORIGINAL -> {
                request.addOption("-f", "bv*+ba/b")
            }
            else -> {
                val h = q.height
                // يختار أقرب جودة متاحة تحت المطلوبة، وإذا ما لقى يرجع لأفضل متوفر
                request.addOption("-f", "bv*[height<=$h]+ba/b[height<=$h]/b")
            }
        }
    }
}
