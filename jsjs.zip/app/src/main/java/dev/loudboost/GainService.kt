package dev.loudboost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.audiofx.LoudnessEnhancer
import android.os.IBinder

class GainService : Service() {

    companion object {
        const val ACTION_GAIN = "dev.loudboost.GAIN"
        const val EXTRA_GAIN = "gain"
        @Volatile var instance: GainService? = null
        @Volatile var status: String = "الخدمة متوقفة"
    }

    private val effects = HashMap<Int, LoudnessEnhancer>()
    private var lastError: String? = null
    var gain = 0
        private set

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        gain = getSharedPreferences("p", MODE_PRIVATE).getInt("gain", 0)

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("lb", "LoudBoost", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "lb")
            .setContentTitle("LoudBoost شغّال")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)

        attach(0)
    }

    @Synchronized
    fun attach(session: Int) {
        if (effects.containsKey(session)) return
        try {
            val le = LoudnessEnhancer(session)
            le.setTargetGain(gain)
            le.enabled = true
            effects[session] = le
        } catch (t: Throwable) {
            lastError = "session $session: ${t.javaClass.simpleName} ${t.message}"
        }
        refresh()
    }

    @Synchronized
    fun detach(session: Int) {
        if (session == 0) return
        try { effects.remove(session)?.release() } catch (t: Throwable) {}
        refresh()
    }

    @Synchronized
    fun setGain(g: Int) {
        gain = g
        getSharedPreferences("p", MODE_PRIVATE).edit().putInt("gain", g).apply()
        for (e in effects.values) {
            try { e.setTargetGain(g) } catch (t: Throwable) {}
        }
        refresh()
    }

    private fun refresh() {
        val ok0 = effects.containsKey(0)
        val others = effects.size - (if (ok0) 1 else 0)
        status = (if (ok0) "الجلسة العامة (0): تعمل ✅" else "الجلسة العامة (0): فشلت ❌") +
            "\nجلسات التطبيقات المرتبطة: $others" +
            "\nالكسب الحالي: $gain mB" +
            (lastError?.let { "\nآخر خطأ: $it" } ?: "")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_GAIN) setGain(intent.getIntExtra(EXTRA_GAIN, gain))
        return START_STICKY
    }

    override fun onDestroy() {
        synchronized(this) {
            for (e in effects.values) {
                try { e.release() } catch (t: Throwable) {}
            }
            effects.clear()
        }
        instance = null
        status = "الخدمة متوقفة"
        super.onDestroy()
    }
}
