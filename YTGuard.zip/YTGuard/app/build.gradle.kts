plugins { id("com.android.application") }

android {
    namespace = "io.github.ytguard"
    compileSdk = 34

    defaultConfig {
        applicationId = "io.github.ytguard"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // signed with the debug key so the APK is installable as-is
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // compile-time only: the real classes are provided by LSPosed at runtime
    compileOnly(project(":xposed-stub"))
}
