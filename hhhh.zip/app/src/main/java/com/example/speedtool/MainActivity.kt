package com.example.speedtool

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var spinner: Spinner
    private lateinit var log: TextView
    private val pkgs = mutableListOf<String>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.TOP
        }
        spinner = Spinner(this)
        val refresh = Button(this).apply { text = "تحديث قائمة التطبيقات الشغالة"; setOnClickListener { loadRunning() } }
        val floatBtn = Button(this).apply { text = "تشغيل الأيقونة العائمة"; setOnClickListener { openFloating() } }
        val logBtn = Button(this).apply { text = "عرض السجل"; setOnClickListener { Engine.readLog { log.text = it } } }
        log = TextView(this).apply { textSize = 12f }
        val tip = TextView(this).apply {
            textSize = 12f
            text = "1) ضع frida-inject (arm64) في /data/local/tmp\n" +
                   "2) شغّل اللعبة، ارجع هنا، حدّث القائمة، اختر اللعبة\n" +
                   "3) اضغط تشغيل الأيقونة العائمة، وادخل اللعبة. اضغط ⚡ للتحكم."
        }
        listOf(refresh, spinner, floatBtn, logBtn, tip, log).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
        loadRunning()
        // إذن الإشعارات (أندرويد 13+): الخدمة الأمامية تشتغل بدونه لكن الإشعار ما يظهر
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun openFloating() {
        val i = spinner.selectedItemPosition
        if (i < 0 || i >= pkgs.size) { log.text = "اختر تطبيقًا من القائمة"; return }
        val name = pkgs[i]
        if (Engine.isBlocked(name)) {
            log.text = "هذا تطبيق أونلاين وفيه حظر للحسابات، الأداة ترفض تشتغل عليه."
            return
        }
        Engine.pkg = name
        if (Settings.canDrawOverlays(this)) { launchFloating(); return }
        Engine.su("appops set $packageName SYSTEM_ALERT_WINDOW allow") { _ ->
            if (Settings.canDrawOverlays(this)) {
                launchFloating()
            } else {
                log.text = "فعّل إذن «الظهور فوق التطبيقات» ثم ارجع واضغط الزر مرة ثانية"
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
    }

    private fun launchFloating() {
        stopService(Intent(this, FloatingService::class.java))
        val svc = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
        log.text = "تم. افتح اللعبة واضغط ⚡"
        moveTaskToBack(true)
    }

    private fun loadRunning() {
        log.text = "جاري التحميل..."
        Thread {
            try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "ps -A -o NAME"))
                val names = p.inputStream.bufferedReader().readLines()
                    .map { it.trim().substringBefore(':') }.toSet()
                p.waitFor()
                val pm = packageManager
                val apps = pm.getInstalledApplications(0)
                    .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
                    .filter { it.packageName != packageName && it.packageName in names }
                    .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
                runOnUiThread {
                    pkgs.clear()
                    pkgs.addAll(apps.map { it.packageName })
                    val items = apps.map { "${pm.getApplicationLabel(it)}  (${it.packageName})" }
                    spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
                    log.text = if (items.isEmpty()) "ما لقيت تطبيقات شغالة (تأكد من الروت)" else "تم: ${items.size} تطبيق"
                }
            } catch (e: Exception) {
                runOnUiThread { log.text = "فشل: ${e.message}" }
            }
        }.start()
    }
}
