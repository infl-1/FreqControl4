package com.example.speedtool

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

/**
 * عميل محرك الذاكرة: يشغّل MemServer بصلاحية روت (app_process) ويكلمه بأسطر نصية.
 * كل الطلبات تمشي على خيط واحد بالترتيب، والنتيجة ترجع على الخيط الرئيسي.
 */
object Mem {
    class Reply(val ok: Boolean, val text: String, val rows: List<String> = emptyList())
    class Hit(val addr: Long, val value: String, val region: String, val frozen: Boolean)
    class Saved(val type: String, val addr: Long)

    /** أنواع القيم (الكود، الاسم). */
    val TYPES = listOf(
        "i32" to "Dword", "f32" to "Float", "i16" to "Word",
        "i8" to "Byte", "i64" to "Qword", "f64" to "Double"
    )

    /** مناطق الذاكرة (مثل جيم جاردن). */
    val REGIONS = listOf(
        "A" to "Anonymous", "Ca" to "C++ alloc", "Cb" to "C++ .bss",
        "Cd" to "C++ .data", "Jh" to "Java heap", "O" to "Other"
    )

    /** القائمة المحفوظة (تنمسح لو اللعبة انفتحت من جديد لأن العناوين تتغير). */
    val saved = ArrayList<Saved>()

    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor { r -> Thread(r).apply { isDaemon = true } }

    @Volatile private var proc: Process? = null
    @Volatile private var rd: BufferedReader? = null
    @Volatile private var wr: BufferedWriter? = null
    @Volatile private var errText = ""

    private fun isAlive(p: Process): Boolean =
        try { p.exitValue(); false } catch (e: IllegalThreadStateException) { true }

    fun isRunning(): Boolean {
        val p = proc ?: return false
        return isAlive(p)
    }

    @Synchronized
    private fun ensure(ctx: Context): String? {
        val cur = proc
        if (cur != null && isAlive(cur) && rd != null && wr != null) return null
        close()
        errText = ""
        return try {
            val apk = ctx.applicationInfo.sourceDir
            val p = ProcessBuilder(
                "su", "-c",
                "CLASSPATH=$apk exec app_process /system/bin com.example.speedtool.MemServer"
            ).start()
            proc = p
            rd = BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8))
            wr = BufferedWriter(OutputStreamWriter(p.outputStream, Charsets.UTF_8))
            val t = Thread {
                try {
                    p.errorStream.bufferedReader().forEachLine { l ->
                        errText = (errText + l + "\n").takeLast(600)
                    }
                } catch (e: Exception) {
                }
            }
            t.isDaemon = true
            t.start()
            null
        } catch (e: Exception) {
            "فشل تشغيل الروت: ${e.message}"
        }
    }

    /** يقفل محرك الذاكرة (يوقف التجميد ويمسح النتائج). الخادم يموت لحاله لما ينقطع الأنبوب. */
    @Synchronized
    fun close() {
        try {
            wr?.write("quit\n")
            wr?.flush()
        } catch (e: Exception) {
        }
        try { proc?.destroy() } catch (e: Exception) {}
        proc = null
        rd = null
        wr = null
    }

    private fun talk(cmd: String, onProg: ((Int) -> Unit)?): Reply {
        val w = wr
        val r = rd
        if (w == null || r == null) return Reply(false, "محرك الذاكرة غير شغّال")
        var result: Reply? = null
        try {
            w.write(cmd)
            w.write("\n")
            w.flush()
            val rows = ArrayList<String>()
            while (result == null) {
                val line = r.readLine() ?: throw java.io.EOFException()
                if (line.startsWith("PROG ")) {
                    val cbp = onProg
                    val v = line.substring(5).trim().toIntOrNull() ?: 0
                    if (cbp != null) main.post { cbp(v) }
                } else if (line == "OK" || line.startsWith("OK ")) {
                    result = Reply(true, line.removePrefix("OK").trim(), rows)
                } else if (line.startsWith("ERR")) {
                    result = Reply(false, line.removePrefix("ERR").trim(), rows)
                } else {
                    rows.add(line)
                }
            }
        } catch (e: Exception) {
            val tail = errText.trim().takeLast(160)
            close()
            result = Reply(
                false,
                "انقطع الاتصال بمحرك الذاكرة" + if (tail.isNotEmpty()) ": $tail" else " (تأكد من صلاحية الروت)"
            )
        }
        return result ?: Reply(false, "خطأ غير متوقع")
    }

    /** ينفّذ الأوامر بالترتيب (يوقف عند أول فشل) ويرجّع رد آخر أمر على الخيط الرئيسي. */
    fun call(ctx: Context, cmds: List<String>, onProg: ((Int) -> Unit)? = null, cb: (Reply) -> Unit) {
        val app = ctx.applicationContext
        exec.execute {
            val err = ensure(app)
            var rep: Reply = if (err != null) Reply(false, err) else Reply(true, "")
            if (err == null) {
                for (cmd in cmds) {
                    rep = talk(cmd, onProg)
                    if (!rep.ok) break
                    // اللعبة انفتحت من جديد (عملية جديدة): العناوين المحفوظة ما عادت صالحة
                    if (cmd.startsWith("attachpkg") && !rep.text.startsWith("same")) main.post { saved.clear() }
                }
            }
            val out = rep
            main.post { cb(out) }
        }
    }

    /** يحوّل أسطر "R addr value region frozen" إلى نتائج. */
    fun hits(rows: List<String>): List<Hit> {
        val list = ArrayList<Hit>()
        for (l in rows) {
            val t = l.split(" ")
            if (t.size < 5 || t[0] != "R") continue
            val a = t[1].toLongOrNull(16) ?: continue
            list.add(Hit(a, t[2], t[3], t[4] == "1"))
        }
        return list
    }
}
