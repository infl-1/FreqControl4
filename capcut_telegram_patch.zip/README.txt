1) python3 apply_to_apk.py Capcut-v20_0_0.apk Capcut-clean-unsigned.apk
2) وقّع الملف (uber-apk-signer أو apksigner)
3) احذف النسخة القديمة من الجوال ثم ثبّت الجديدة
ملاحظة: التعديل يعطّل نوافذ المعدّل (التحديث/تيليجرام) فقط. الكود المحوّل لـnative (NPDex2c) ما قدرت أفحصه.
