'use strict';
// السرعة تُقرأ من الملف كل 300ms.
// وضعان:
//  1) ألعاب Unity (IL2CPP أو Mono): نضبط Time.timeScale من خيط اللعبة الرئيسي. ما نلمس ساعة النظام،
//     لأن تزييفها يخرّب توقيت الإطارات (Swappy/vsync) فتصير اللعبة "تقطّع" بدون ما تتسرّع.
//  2) باقي الألعاب (أو لو فشل وضع Unity): نغيّر الوقت اللي يشوفه كود اللعبة فقط (libc).
const PATH = '/data/local/tmp/speed.txt';
const FIX_WAITS = true;     // وضع libc: يحوّل مهلات الانتظار المطلقة (cond/sem/mutex) من المزيّف للحقيقي
const FIX_SLEEPS = true;    // وضع libc: يقسم النوم النسبي (nanosleep/usleep) على السرعة
function readMode() {
  try { return File.readAllText('/data/local/tmp/mode.txt').trim(); } catch (e) { return 'auto'; }
}
const MODE = readMode();               // auto = Unity timeScale إذا لقى Unity، غير كذا libc | libc = إجبار ساعة النظام
const UNITY_MODE = MODE !== 'libc';
console.log('speed.js v1.6 mode=' + MODE);
let speed = 1.0;
let engaged = false;        // يصير true أول ما تتغير السرعة عن 1.0؛ قبلها ما نلمس أي شي (وضع libc)
let useLibc = true;         // true = نزيّف ساعة النظام
let calls = 0, failedRead = false, failedHook = false;
let unityPending = false, unityPendingSince = 0;

function logHookError(e) {
  if (!failedHook) { failedHook = true; console.log('hook error: ' + e); }
}

function exp(mod, name) {
  try { const a = mod.findExportByName(name); if (a) return a; } catch (e) {}
  try { return mod.getExportByName(name); } catch (e) {}
  return null;
}
function findExp(name) {
  try { if (Module.findExportByName) { const a = Module.findExportByName(null, name); if (a) return a; } } catch (e) {}
  try { const m = Process.getModuleByName('libc.so'); return exp(m, name); } catch (e) {}
  return null;
}

// ================= وضع Unity: Time.timeScale =================
function detectUnity() {
  if (!UNITY_MODE) return null;
  try {
    const il = Process.findModuleByName('libil2cpp.so');
    if (il) return { kind: 'il2cpp', lib: il };
    const mono = Process.enumerateModules().find(function (m) { return /^libmono.*\.so$/.test(m.name); });
    if (mono) return { kind: 'mono', lib: mono };
  } catch (e) { console.log('detect error: ' + e); }
  return null;
}
const unity = detectUnity();
if (unity) useLibc = false;
console.log('backend=' + (unity ? unity.kind : 'libc'));

const U = { ready: false, ok: false, fails: 0, mainTid: 0, inApply: false, gaveUp: false };
let tsSet = NULL, tsGet = NULL, invokeNF = null;
let icSet = null, icGet = null;   // دوال icall الأصلية (احتياط لما اللعبة تقصّ set_timeScale من الكود المُدار)
const fbuf = Memory.alloc(16), argv = Memory.alloc(16), excBuf = Memory.alloc(16);
const keepStr = [];
function K(s) { const p = Memory.allocUtf8String(s); keepStr.push(p); return p; }
function nf(lib, name, ret, args) {
  const a = exp(lib, name);
  if (!a) throw new Error('missing export ' + name);
  return new NativeFunction(a, ret, args);
}

function giveUp(why) {
  if (U.gaveUp) return;
  U.gaveUp = true; unityPending = false; useLibc = true;
  console.log('unity mode off (' + why + ') -> libc time hooks');
}

function resolveUnity() {
  const lib = unity.lib;
  let klass = NULL, meth;
  if (unity.kind === 'il2cpp') {
    const dom = nf(lib, 'il2cpp_domain_get', 'pointer', [])();
    const getAsms = nf(lib, 'il2cpp_domain_get_assemblies', 'pointer', ['pointer', 'pointer']);
    const asmImg = nf(lib, 'il2cpp_assembly_get_image', 'pointer', ['pointer']);
    const clsFrom = nf(lib, 'il2cpp_class_from_name', 'pointer', ['pointer', 'pointer', 'pointer']);
    meth = nf(lib, 'il2cpp_class_get_method_from_name', 'pointer', ['pointer', 'pointer', 'int']);
    invokeNF = nf(lib, 'il2cpp_runtime_invoke', 'pointer', ['pointer', 'pointer', 'pointer', 'pointer']);
    const sz = Memory.alloc(8);
    sz.writeU64(0);
    const arr = getAsms(dom, sz);
    const n = Number(sz.readU64());
    for (let i = 0; i < n && klass.isNull(); i++) {
      const img = asmImg(arr.add(i * Process.pointerSize).readPointer());
      klass = clsFrom(img, K('UnityEngine'), K('Time'));
    }
  } else {
    const nameNew = nf(lib, 'mono_assembly_name_new', 'pointer', ['pointer']);
    const loaded = nf(lib, 'mono_assembly_loaded', 'pointer', ['pointer']);
    const asmImg = nf(lib, 'mono_assembly_get_image', 'pointer', ['pointer']);
    const clsFrom = nf(lib, 'mono_class_from_name', 'pointer', ['pointer', 'pointer', 'pointer']);
    meth = nf(lib, 'mono_class_get_method_from_name', 'pointer', ['pointer', 'pointer', 'int']);
    invokeNF = nf(lib, 'mono_runtime_invoke', 'pointer', ['pointer', 'pointer', 'pointer', 'pointer']);
    const names = ['UnityEngine.CoreModule', 'UnityEngine'];
    for (let i = 0; i < names.length && klass.isNull(); i++) {
      const an = nameNew(K(names[i]));
      if (an.isNull()) continue;
      const asm = loaded(an);
      if (asm.isNull()) continue;
      klass = clsFrom(asmImg(asm), K('UnityEngine'), K('Time'));
    }
  }
  if (!klass.isNull()) {
    tsSet = meth(klass, K('set_timeScale'), 1);
    tsGet = meth(klass, K('get_timeScale'), 0);
  }
  if (tsSet.isNull()) {
    // Unity يقصّ الدوال اللي ما يستخدمها كود اللعبة، فنروح للدالة الأصلية في المحرك مباشرة
    if (unity.kind === 'il2cpp') {
      if (!klass.isNull()) dumpTimeMethods(lib, klass);
      if (resolveIcalls(lib)) { console.log('unity: using icall Time.set_timeScale'); return; }
    }
    throw new Error((klass.isNull() ? 'UnityEngine.Time class not found' : 'set_timeScale not found') + ' (icall also failed)');
  }
}

// تشخيص: يطبع الدوال اللي فعلاً موجودة في كلاس Time (عشان نعرف وش اللي انقصّ)
function dumpTimeMethods(lib, klass) {
  try {
    const getM = nf(lib, 'il2cpp_class_get_methods', 'pointer', ['pointer', 'pointer']);
    const mName = nf(lib, 'il2cpp_method_get_name', 'pointer', ['pointer']);
    const it = Memory.alloc(Process.pointerSize);
    it.writePointer(NULL);
    const names = [];
    for (let i = 0; i < 300; i++) {
      const m = getM(klass, it);
      if (m.isNull()) break;
      names.push(mName(m).readCString());
    }
    console.log('Time methods: ' + names.length + ' | ' + names.filter(function (n) { return /scale|delta|fixed/i.test(n); }).join(','));
  } catch (e) { console.log('dump methods failed: ' + e); }
}

function resolveIcalls(lib) {
  try {
    const r = exp(lib, 'il2cpp_resolve_icall');
    if (!r) { console.log('icall: il2cpp_resolve_icall export missing'); return false; }
    const resolve = new NativeFunction(r, 'pointer', ['pointer']);
    const find = function (names) {
      for (let i = 0; i < names.length; i++) {
        let p = NULL;
        try { p = resolve(K(names[i])); } catch (e) { console.log('icall error ' + names[i] + ': ' + e); }
        console.log('icall ' + names[i] + ' -> ' + (p && !p.isNull() ? 'found' : 'null'));
        if (p && !p.isNull()) return p;
      }
      return NULL;
    };
    const s = find(['UnityEngine.Time::set_timeScale', 'UnityEngine.Time::set_timeScale(System.Single)']);
    if (s.isNull()) return false;
    const g = find(['UnityEngine.Time::get_timeScale', 'UnityEngine.Time::get_timeScale()']);
    icSet = new NativeFunction(s, 'void', ['float']);
    icGet = g.isNull() ? null : new NativeFunction(g, 'float', []);
    return true;
  } catch (e) {
    console.log('icall resolve failed: ' + e);
    return false;
  }
}

function callStatic(m, v) {
  excBuf.writePointer(NULL);
  let a = NULL;
  if (v !== undefined) { fbuf.writeFloat(v); argv.writePointer(fbuf); a = argv; }
  const r = invokeNF(m, NULL, a, excBuf);
  if (!excBuf.readPointer().isNull()) throw new Error('managed exception');
  return r;
}
function setTS(v) {
  if (icSet) { icSet(v); return; }
  callStatic(tsSet, v);
}
function readTS() {
  if (icSet) return icGet ? icGet() : NaN;
  if (tsGet.isNull()) return NaN;
  const r = callStatic(tsGet);
  return r.isNull() ? NaN : r.add(2 * Process.pointerSize).readFloat();
}

function applyUnity() {
  U.inApply = true;
  try {
    if (!U.ready) { resolveUnity(); U.ready = true; console.log('unity(' + unity.kind + '): timeScale resolved'); }
    const cur = readTS();
    if (!(Math.abs(cur - speed) < 0.001)) {
      setTS(speed);
      if (cur === cur || U.lastLog !== speed) {   // بدون getter ما نكرر نفس السطر في السجل
        console.log('timeScale ' + cur.toFixed(2) + ' -> ' + speed + ' (now ' + readTS().toFixed(2) + ')');
        U.lastLog = speed;
      }
    }
    U.ok = true; U.fails = 0; unityPending = false;
  } catch (e) {
    console.log('unity apply failed: ' + e);
    if (++U.fails >= 3) giveUp('apply failed');
  } finally {
    U.inApply = false;
  }
}

// نشغّل الضبط من الخيط الرئيسي للعبة (Unity ما يسمح بـ Time.timeScale من خيوط ثانية)
const tnames = {};
function nameOf(tid) {
  let n = tnames[tid];
  if (n === undefined) {
    try { n = File.readAllText('/proc/self/task/' + tid + '/comm').trim(); } catch (e) { n = ''; }
    tnames[tid] = n;
  }
  return n;
}
function onUnityCall(tid) {
  if (!U.mainTid) {
    if (nameOf(tid).indexOf('UnityMain') === 0) U.mainTid = tid;
    else if (Date.now() - unityPendingSince > 3000) {
      U.mainTid = tid;
      console.log('main thread guess tid=' + tid + ' name=' + nameOf(tid));
    }
  }
  if (tid === U.mainTid) applyUnity();
}

if (unity) {
  const hk = exp(unity.lib, unity.kind === 'il2cpp' ? 'il2cpp_runtime_invoke' : 'mono_runtime_invoke');
  if (hk) {
    Interceptor.attach(hk, {
      onEnter(args) {
        if (!unityPending || U.inApply || U.gaveUp) return;
        onUnityCall(this.threadId);
      }
    });
    console.log('unity hook: ' + (unity.kind === 'il2cpp' ? 'il2cpp_runtime_invoke' : 'mono_runtime_invoke'));
  } else {
    giveUp('no runtime_invoke export');
  }
  // نعيد التحقق كل ثانية (اللعبة ممكن ترجّع timeScale لـ 1 لما توقف/تفتح قائمة)
  setInterval(function () {
    if (U.gaveUp || !engaged) return;
    if (!unityPending) { unityPending = true; unityPendingSince = Date.now(); }
    else if (!U.ok && Date.now() - unityPendingSince > 8000) giveUp('no main-thread callback');
  }, 1000);
}

// ================= قراءة السرعة =================
function readSpeed() {
  let txt = null;
  try {
    txt = File.readAllText(PATH);
  } catch (e) {
    try { const f = new File(PATH, 'r'); txt = f.readLine(); f.close(); }
    catch (e2) {
      if (!failedRead) { failedRead = true; console.log('read speed file failed: ' + e2); }
      return;
    }
  }
  const v = parseFloat(txt);
  if (v >= 0.01 && v <= 100 && v !== speed) {
    speed = v;
    if (v !== 1.0) engaged = true;
    if (unity && !U.gaveUp && engaged) {
      if (!unityPending) unityPendingSince = Date.now();
      unityPending = true;
    }
    console.log('speed=' + speed);
  }
}
readSpeed();
setInterval(readSpeed, 300);

// ================= وضع libc (للألعاب غير Unity) =================
// "كود اللعبة" = المكتبات اللي مساراتها تحت /data/app أو /data/data أو /data/user.
// ART والنظام وFrida خارجها، فيشوفون الوقت الحقيقي دايماً (هذا اللي يمنع التجمد بعد دقائق).
const gameCache = new Map();
function isGamePath(p) {
  return p.indexOf('/data/app/') === 0 || p.indexOf('/data/data/') === 0 || p.indexOf('/data/user/') === 0;
}
function callerIsGame(ra) {
  const key = ra.toString();
  const hit = gameCache.get(key);
  if (hit !== undefined) return hit;
  const m = Process.findModuleByAddress(ra);
  if (m === null) return false;               // ذاكرة بلا مكتبة (JIT وغيره): نعتبره نظام ولا نخزّنه
  if (gameCache.size > 50000) gameCache.clear();
  const v = isGamePath(m.path || '');
  gameCache.set(key, v);
  return v;
}
function libcOn(ra) { return engaged && useLibc && callerIsGame(ra); }

// الوقت المزيّف: يحافظ على الاستمرارية لما تتغير السرعة
const st = {};
function virt(key, real) {
  let s = st[key];
  if (!s) { s = { r: real, v: real, sp: speed }; st[key] = s; }
  if (s.sp !== speed) {
    s.v = s.v + (real - s.r) * s.sp;
    s.r = real;
    s.sp = speed;
  }
  return s.v + (real - s.r) * s.sp;
}
// يقسم ثواني عشرية إلى [ثواني, كسر] والكسر لا يتجاوز scale-1 (تفادي tv_nsec = 1e9)
function split(v, scale) {
  const sec = Math.floor(v);
  let f = Math.floor((v - sec) * scale);
  if (f > scale - 1) f = scale - 1;
  if (f < 0) f = 0;
  return [sec, f];
}

const cg = findExp('clock_gettime');
if (cg) Interceptor.attach(cg, {
  onEnter(a) {
    this.go = libcOn(this.returnAddress);
    if (this.go) { this.clk = a[0].toInt32(); this.ts = a[1]; }
  },
  onLeave(ret) {
    if (!this.go) return;
    try {
      if (ret.toInt32() !== 0) return;
      const sec = Number(this.ts.readS64());
      const ns = Number(this.ts.add(8).readS64());
      const r = split(virt('c' + this.clk, sec + ns / 1e9), 1e9);
      this.ts.writeS64(r[0]);
      this.ts.add(8).writeS64(r[1]);
      if (calls++ < 3) console.log('clock_gettime hooked, clk=' + this.clk + ' speed=' + speed);
    } catch (e) { logHookError(e); }
  }
});

const gt = findExp('gettimeofday');
if (gt) Interceptor.attach(gt, {
  onEnter(a) {
    this.go = libcOn(this.returnAddress);
    if (this.go) this.tv = a[0];
  },
  onLeave(ret) {
    if (!this.go) return;
    try {
      if (ret.toInt32() !== 0 || this.tv.isNull()) return;
      const sec = Number(this.tv.readS64());
      const us = Number(this.tv.add(8).readS64());
      const r = split(virt('tod', sec + us / 1e6), 1e6);
      this.tv.writeS64(r[0]);
      this.tv.add(8).writeS64(r[1]);
    } catch (e) { logHookError(e); }
  }
});

// مهلات الانتظار المطلقة: اللعبة تحسبها من الوقت المزيّف لكن النواة تقارنها بالحقيقي.
// الحقيقي = الآن الحقيقي + (الموعد - الآن المزيّف) / السرعة
const realCg = cg ? new NativeFunction(cg, 'int', ['int', 'pointer']) : null;
function fixAbs(ctx, args, idx, clkHint) {
  try {
    const p = args[idx];
    if (!realCg || p.isNull()) return;
    const ab = Number(p.readS64()) + Number(p.add(8).readS64()) / 1e9;
    const clk = clkHint !== undefined ? clkHint : (ab < 1e9 ? 1 : 0);
    const t = Memory.alloc(16);
    if (realCg(clk, t) !== 0) return;
    const rn = Number(t.readS64()) + Number(t.add(8).readS64()) / 1e9;
    let remain = ab - virt('c' + clk, rn);
    if (remain < 0) remain = 0;
    const out = split(rn + remain / speed, 1e9);
    t.writeS64(out[0]);
    t.add(8).writeS64(out[1]);
    args[idx] = t;
    ctx.keep = t;                               // يبقي المخزن حيّ لين يرجع الاستدعاء
  } catch (e) { logHookError(e); }
}
// نوم نسبي: المدة تُحسب من الوقت المزيّف لكنها تنتظر بالحقيقي، فنقسمها على السرعة
function fixRel(ctx, args, idx) {
  try {
    const p = args[idx];
    if (p.isNull()) return;
    const d = Number(p.readS64()) + Number(p.add(8).readS64()) / 1e9;
    const t = Memory.alloc(16);
    const out = split(d / speed, 1e9);
    t.writeS64(out[0]);
    t.add(8).writeS64(out[1]);
    args[idx] = t;
    ctx.keep = t;
  } catch (e) { logHookError(e); }
}
if (FIX_WAITS) {
  [['pthread_cond_timedwait', 2], ['pthread_cond_timedwait_monotonic_np', 2],
   ['sem_timedwait', 1], ['pthread_mutex_timedlock', 1],
   ['pthread_mutex_timedlock_monotonic_np', 1]].forEach(function (e) {
    const a = findExp(e[0]);
    if (!a) return;
    Interceptor.attach(a, {
      onEnter(args) { if (libcOn(this.returnAddress)) fixAbs(this, args, e[1]); }
    });
    console.log(e[0] + ': hooked');
  });
}
if (FIX_SLEEPS) {
  const ns = findExp('nanosleep');
  if (ns) Interceptor.attach(ns, {
    onEnter(args) { if (libcOn(this.returnAddress)) fixRel(this, args, 0); }
  });
  const us = findExp('usleep');
  if (us) Interceptor.attach(us, {
    onEnter(args) {
      if (!libcOn(this.returnAddress)) return;
      try { args[0] = ptr(Math.max(0, Math.floor(args[0].toInt32() / speed))); } catch (e) { logHookError(e); }
    }
  });
  const cn = findExp('clock_nanosleep');
  if (cn) Interceptor.attach(cn, {
    onEnter(args) {
      if (!libcOn(this.returnAddress)) return;
      if (args[1].toInt32() & 1) fixAbs(this, args, 2, args[0].toInt32());   // TIMER_ABSTIME
      else fixRel(this, args, 2);
    }
  });
  console.log('sleep hooks: ' + (ns ? 'nanosleep ' : '') + (us ? 'usleep ' : '') + (cn ? 'clock_nanosleep' : ''));
}
console.log('speed hook ready');
