// يقرأ السرعة من الملف كل 300ms، ويغيّر الوقت اللي تشوفه اللعبة (arm64)
const PATH = '/data/local/tmp/speed.txt';
let speed = 1.0;

function readSpeed() {
  try {
    const v = parseFloat(File.readAllText(PATH));
    if (v > 0 && v <= 20) speed = v;
  } catch (e) {}
}
readSpeed();
setInterval(readSpeed, 300);

const st = {};
function warp(key, sec, frac) {          // frac بالثواني (0..1)
  const real = sec + frac;
  let s = st[key];
  if (!s) { s = { r: real, v: real, sp: speed }; st[key] = s; }
  if (s.sp !== speed) {                   // تغيّرت السرعة: أعد الضبط بدون قفزة
    s.v = s.v + (real - s.r) * s.sp;
    s.r = real;
    s.sp = speed;
  }
  const virt = s.v + (real - s.r) * s.sp;
  const vs = Math.floor(virt);
  return [vs, virt - vs];
}

const cg = Module.findExportByName(null, 'clock_gettime');
if (cg) Interceptor.attach(cg, {
  onEnter(a) { this.clk = a[0].toInt32(); this.ts = a[1]; },
  onLeave(ret) {
    if (ret.toInt32() !== 0) return;
    const sec = this.ts.readS64().valueOf();
    const ns = this.ts.add(8).readS64().valueOf();
    const [vs, vf] = warp('c' + this.clk, sec, ns / 1e9);
    this.ts.writeS64(vs);
    this.ts.add(8).writeS64(Math.floor(vf * 1e9));
  }
});

const gt = Module.findExportByName(null, 'gettimeofday');
if (gt) Interceptor.attach(gt, {
  onEnter(a) { this.tv = a[0]; },
  onLeave(ret) {
    if (ret.toInt32() !== 0 || this.tv.isNull()) return;
    const sec = this.tv.readS64().valueOf();
    const us = this.tv.add(8).readS64().valueOf();
    const [vs, vf] = warp('tod', sec, us / 1e6);
    this.tv.writeS64(vs);
    this.tv.add(8).writeS64(Math.floor(vf * 1e6));
  }
});
console.log('speed hook ready');
