# إضافة خيارات الجودة (HD / FHD / 4K) ومعدل الإطارات (30 / 60 / 120) لمسجّل الشاشة

## الاستخدام (في مستودعك قبل البناء)
```bash
apktool d SmartCapture.apk -o SmartCapture      # فك التطبيق
python3 apply_mod.py SmartCapture               # تطبيق التعديل (مرة وحدة، وإذا كررته ما يضر)
apktool b SmartCapture -o SmartCapture_mod.apk  # بناء
# ثم zipalign + توقيع بنفس طريقتك الحالية
```
إذا طلع سطر `[FAIL]` أرسله لي كما هو.

## تحديث v4 (من log3.txt)
- **شريط الأدوات ما يطلع بعد اللقطة:** `ScreenshotUiService` كان يكرش في `WindowManagerUtils.getVisibleWindowList` (تحتاج `MANAGE_ACTIVITY_TASKS`). الحين تُغلَّف وترجع قائمة فاضية بدل الكراش.
- **نافذة التسجيل (نقرة وحدة على الـ tile) تكرش:** `ScreenRecorderService` كان يكرش في `ExternalEventDetector.registerCallStateChangeListener` (`SecurityException: listen`، تحتاج صلاحية حالة الهاتف المميزة). الحين دوال تسجيل/إلغاء مستمعات المكالمات والغطاء ووضع اليد الواحدة تتغلّف بـ try/catch.
- النتيجة الجانبية: التسجيل ما يتوقف تلقائياً عند اتصال مكالمة.

## تحديث v3 (كراشات جولة logcat الثانية)
- بعد إصلاحات v2 اختفى `VerifyError` و`STATUS_BAR`، وظهرت أخطاء صلاحيات نظام ثانية:
  - `DeviceUtils.getFocusedUserId` ← `INTERACT_ACROSS_USERS` (كان يكرش عند بدء خدمة التسجيل).
  - `DexUtils.isDesktopStandAloneMode` ← `LauncherProvider READ_SETTINGS` (كان يكرش صفحة الإعدادات).
- الحل: كل دوال `static` في `DeviceUtils` و`DexUtils` وكلاسات `SepWrapper*` تتغلّف بـ try/catch، وإذا انرفضت الصلاحية ترجع قيمة افتراضية (0 / false / null) بدل ما يكرش التطبيق.
- ملاحظة: القيمة الافتراضية ممكن تعطّل ميزة جانبية (مثل كشف وضع DeX)، لكن ما تأثر على التسجيل نفسه.

## تحديث v2 (إصلاح الكراش — من سجل logcat الحقيقي)
- **VerifyError في `SettingsFragment.updateScreenRecorderSettings`**: المترجم (R8) يعيد استخدام السجل `p0` لقيمة ثانية قبل نهاية الدالة، فاستدعاء `modRefresh` عند `return-void` كان يمرّر قيمة غلط بدل `this`. الحين الدالة الأصلية تتسمّى `...$mod` وفوقها غلاف صغير ينادي الأصلية ثم `modRefresh`.
- **SecurityException في زر التسجيل (tile)**: `ScreenRecorderUtils.collapseQuickPanel` تحتاج صلاحية النظام `STATUS_BAR` وما تنمنح لتطبيق بتوقيع غير توقيع سامسونج. الحين تُغلَّف بـ try/catch وتتجاهل الخطأ (لوحة الإشعارات ما تنقفل تلقائياً).
- **مهم:** شغّل السكربت على مجلد جديد من `apktool d` للـ APK **الأصلي**، مو على المجلد المعدّل قبل.

## وش يضيف
| الشاشة | التعديل |
|---|---|
| إعدادات لقطات الشاشة وتسجيلات الشاشة | قائمة الجودة تصير: **4K (2160p) / FHD (1080p) / HD (720p) / SD (480p)** |
| نفس الشاشة، تحت صف الجودة | صف جديد **معدل الإطارات (FPS)**: 30 / 60 / 120 |

القيم تنحفظ في نفس تخزين التطبيق: `video_quality` (موجود أصلاً، صار يقبل 2160) و `video_frame_rate` (جديد).

## كيف يشتغل (للمراجعة)
- `res/xml/*.xml`: ينسخ صف الجودة نفسه ويسمّيه `key_screen_recorder_frame_rate`.
- `SettingsFragment`: يحقن 4 دوال (`modSetup / modRefresh / modOnChange / modApply`) ويربطها في `onCreate` و `onPreferenceChange` و `updateScreenRecorderSettings`.
- `ScreenRecorder.initRecorder`: كان معدل الإطارات ثابت 60 (`displayFrameRate`)، الحين يقرأ اختيارك.
- `ScreenRecorderContext.setRecordingResolutionAndBitrate`: عند 120 إطار يرفع الـ bitrate التلقائي ×1.5.
- `MP4Recorder.initVideo`: التطبيق يفرض AVC Main Level 4، وهذا يمنع الدقات العالية، فيُتجاوز عند 4K أو أكثر من 60 إطار.
- كلاس مساعد جديد: `com/mod/RecorderMod.smali`.

## ملاحظات مهمة
1. **لم يُجرَّب على جهاز** (بيئتي ما فيها apktool ولا جهاز). تحققت أن كل الدوال والحقول المشفّرة المستخدمة موجودة فعلاً في ملفات dex، وأن السجلات والـ labels صحيحة، وجرّبت السكربت على ملفات smali تجريبية بنفس صيغة baksmali.
2. **120 إطار** ما تعطي نتيجة إلا إذا شاشتك تشتغل 120Hz أثناء التسجيل (وضع الحركة السلسة مفعّل) وكان المرمّز يدعمها.
3. **4K** معناها هنا أن الضلع القصير = 2160. التطبيق أصلاً يقص الدقة حسب أقصى ما يدعمه مرمّز AVC في جهازك، فإذا جهازك يدعم أقل، تتقلص تلقائياً.
4. إذا فشل التسجيل عند 4K أو 120، جرّب خفض واحد منهما لتعرف أيهما حدّ جهازك.
5. المسمّيات المشفّرة (`ListPreference.s/t` و `DropDownPreference.x/h` و `m2`) مأخوذة من نفس هذا الـ APK، فلو غيّرت إصدار التطبيق لازم أعيد فحصها.
