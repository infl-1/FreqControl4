package io.github.freqctl.extras;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileNotFoundException;

/** Serves the user's custom fingerprint icon (png / lottie json) to the biometrics process. Read-only. */
public class ExtraProvider extends ContentProvider {
    @Override public boolean onCreate() { return true; }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        String n = uri.getLastPathSegment();
        String file = "png".equals(n) ? "fp_icon.png" : "animation".equals(n) ? "fp_anim.json" : null;
        if (file == null || !"r".equals(mode)) throw new FileNotFoundException(String.valueOf(uri));
        File f = new File(getContext().getFilesDir(), file);
        if (!f.isFile()) throw new FileNotFoundException(file);
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
