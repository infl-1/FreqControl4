#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
apply_mod.py  <apktool_decoded_dir>

Adds to Samsung SmartCapture (screen recorder):
  * quality list :  4K (2160p) / FHD (1080p) / HD (720p) / SD (480p)
  * new row      :  frame rate 30 / 60 / 120 fps  (right under the quality row)
  * recorder hooks that really use the chosen values.

Run it ONCE on the folder produced by `apktool d`, then `apktool b`.
Idempotent: running twice does nothing the second time.
"""
import os, re, sys, glob, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
MARK = "MOD-FPS-4K"
FPS_KEY = "key_screen_recorder_frame_rate"
Q_KEY = "key_screen_recorder_video_settings"
FPS_TITLE = "معدل الإطارات (FPS)"

REC = "Lcom/samsung/android/app/smartcapture/screenrecorder/recorder/"
SF = "Lcom/samsung/android/app/settings/SettingsFragment;"

errors, notes = [], []

def rd(p):
    with open(p, encoding="utf-8") as f: return f.read()
def wr(p, t):
    with open(p, "w", encoding="utf-8", newline="\n") as f: f.write(t)

def find_one(root, tail):
    hits = [p for p in glob.glob(os.path.join(root, "smali*", "**", tail), recursive=True)]
    if len(hits) != 1:
        errors.append(f"file not found / ambiguous: {tail} -> {hits}")
        return None
    return hits[0]

def method_span(text, name, sig):
    m = re.search(r"^\.method (?:[\w-]+ )*" + re.escape(name) + r"\(" + re.escape(sig) + r"\)\S+\n.*?^\.end method",
                  text, re.M | re.S)
    if not m: raise RuntimeError(f"method {name}({sig}) not found")
    return m.start(), m.end()

def bump_locals(body):
    m = re.search(r"^(\s*)\.locals (\d+)\s*$", body, re.M)
    if not m: raise RuntimeError(".locals not found (method uses .registers?)")
    n = int(m.group(2))
    if n + 1 > 15: raise RuntimeError("too many registers to bump")
    body = body[:m.start()] + f"{m.group(1)}.locals {n+1}" + body[m.end():]
    return body, f"v{n}"

def prologue_end(body):
    """index just after the .locals line + header directives (.param/.annotation/.prologue/.line)"""
    m = re.search(r"^\s*\.locals \d+\s*\n", body, re.M)
    pos = m.end()
    lines = body[pos:].split("\n")
    off = 0; in_ann = False
    for ln in lines:
        s = ln.strip()
        if in_ann:
            off += len(ln) + 1
            if s.startswith(".end annotation"): in_ann = False
            continue
        if s.startswith(".annotation"):
            in_ann = True; off += len(ln) + 1; continue
        if s == "" or s.startswith((".param", ".end param", ".prologue", ".line", "#")):
            off += len(ln) + 1; continue
        break
    return pos + off

def wrap_method(text, name, sig, build_wrapper):
    """rename the original method to <name>$mod and put a small wrapper with the old name in front of it.
    (safer than patching inside: R8 reuses p0 for other values, so p0 is not always 'this' near the end)"""
    a, b = method_span(text, name, sig)
    body = text[a:b]
    header = body.split("\n", 1)[0]
    renamed = header.replace(name + "(" + sig + ")", name + "$mod(" + sig + ")", 1)
    if renamed == header: raise RuntimeError(f"cannot rename {name}")
    if " static " in header: kind = "invoke-static"
    elif " private " in header or " constructor " in header: kind = "invoke-direct"
    else: kind = "invoke-virtual"
    wrapper = build_wrapper(header, kind)
    return text[:a] + wrapper + "\n" + renamed + body[len(header):] + text[b:]

def patch_method(text, name, sig, fn):
    a, b = method_span(text, name, sig)
    new = fn(text[a:b])
    return text[:a] + new + text[b:]

# ---------------------------------------------------------------- SettingsFragment
def patch_settings(path):
    t = rd(path)
    if MARK in t: notes.append("SettingsFragment: already patched"); return
    # 1. fields + methods
    fields = rd(os.path.join(HERE, "payload", "SettingsFragment_fields.smali"))
    meths = rd(os.path.join(HERE, "payload", "SettingsFragment_methods.smali"))
    m = re.search(r"^\.method ", t, re.M)
    t = t[:m.start()] + f"# {MARK}\n" + fields + "\n" + t[m.start():]
    t = t.rstrip("\n") + "\n" + meths

    # 2. onCreate : call modSetup before the sound-settings lookup
    def f_create(b):
        mm = re.search(r"^(\s*)const-string [vp]\d+, \"key_screen_recorder_sound_settings\"\s*$", b, re.M)
        if not mm: raise RuntimeError("anchor key_screen_recorder_sound_settings not found in onCreate")
        ins = f"{mm.group(1)}invoke-direct {{p0}}, {SF}->modSetup()V\n\n"
        return b[:mm.start()] + ins + b[mm.start():]
    t = patch_method(t, "onCreate", "Landroid/os/Bundle;", f_create)

    # 3. onPreferenceChange : handle our two keys first
    def f_change(b):
        b, tmp = bump_locals(b)
        pos = prologue_end(b)
        code = (f"    invoke-direct {{p0, p1, p2}}, {SF}->modOnChange(Landroidx/preference/Preference;Ljava/lang/Object;)Z\n\n"
                f"    move-result {tmp}\n\n    if-eqz {tmp}, :mod_continue\n\n    return {tmp}\n\n    :mod_continue\n")
        return b[:pos] + code + b[pos:]
    t = patch_method(t, "onPreferenceChange", "Landroidx/preference/Preference;Ljava/lang/Object;", f_change)

    # 4. updateScreenRecorderSettings : wrapper -> call original, then modRefresh (p0 is NOT always 'this' at return-void)
    def w_upd(header, kind):
        return (header + "\n    .locals 0\n\n"
                f"    {kind} {{p0, p1}}, {SF}->updateScreenRecorderSettings$mod(Z)V\n\n"
                f"    invoke-direct {{p0}}, {SF}->modRefresh()V\n\n    return-void\n.end method\n")
    t = wrap_method(t, "updateScreenRecorderSettings", "Z", w_upd)
    wr(path, t); notes.append("SettingsFragment: patched (onCreate, onPreferenceChange, updateScreenRecorderSettings)")

# ---------------------------------------------------------------- recorder hooks
def patch_screen_recorder(path):
    t = rd(path)
    if MARK in t: notes.append("ScreenRecorder: already patched"); return
    def f(b):
        mm = re.search(r"^(\s*)iget ([vp]\d+), [vp]\d+, " + re.escape(REC) + r"ScreenRecorderContext;->displayFrameRate:I\s*$", b, re.M)
        if not mm: raise RuntimeError("displayFrameRate read not found in initRecorder")
        x = mm.group(2)
        b, tmp = bump_locals(b)
        mm = re.search(r"^(\s*)iget ([vp]\d+), [vp]\d+, " + re.escape(REC) + r"ScreenRecorderContext;->displayFrameRate:I\s*$", b, re.M)
        code = (f"\n    # {MARK}\n"
                f"    iget-object {tmp}, p0, {REC}ScreenRecorder;->mContext:Landroid/content/Context;\n\n"
                f"    invoke-static {{{tmp}, {x}}}, Lcom/mod/RecorderMod;->fps(Landroid/content/Context;I)I\n\n"
                f"    move-result {x}\n")
        return b[:mm.end()] + code + b[mm.end():]
    t = patch_method(t, "initRecorder", "", f)
    wr(path, t); notes.append("ScreenRecorder.initRecorder: frame rate hook")

def patch_mp4(path):
    t = rd(path)
    if MARK in t: notes.append("MP4Recorder: already patched"); return
    def f(b):
        old = "invoke-static {}, Lcom/samsung/android/app/smartcapture/screenrecorder/util/AudioUtil;->isSupportAVCMainProfileLevel4()Z"
        if old not in b: raise RuntimeError("isSupportAVCMainProfileLevel4 call not found in initVideo")
        return b.replace(old, "invoke-static {}, Lcom/mod/RecorderMod;->level4()Z  # " + MARK)
    t = patch_method(t, "initVideo", "", f)
    wr(path, t); notes.append("MP4Recorder.initVideo: AVC level4 override skipped for 4K / >60fps")

def patch_context(path):
    t = rd(path)
    if MARK in t: notes.append("ScreenRecorderContext: already patched"); return
    def f(b):
        pat = re.compile(r"(invoke-virtual \{p0, [vp]\d+, [vp]\d+, [vp]\d+\}, " + re.escape(REC) +
                         r"ScreenRecorderContext;->getProperAutoBitrate\(III\)I\s*\n(?:[ \t]*(?:\.line \d+)?[ \t]*\n)*"
                         r"[ \t]*move-result ([vp]\d+)\s*\n(?:[ \t]*(?:\.line \d+)?[ \t]*\n)*"
                         r"[ \t]*iput \2, p0, " + re.escape(REC) + r"ScreenRecorderContext;->bitrate:I[ \t]*\n)")
        mm = pat.search(b)
        if not mm: raise RuntimeError("auto bitrate store not found")
        x = mm.group(2)
        b, tmp = bump_locals(b)
        mm = pat.search(b)
        code = (f"\n    # {MARK}\n"
                f"    iget-object {tmp}, p0, {REC}ScreenRecorderContext;->context:Landroid/content/Context;\n\n"
                f"    invoke-static {{{tmp}, {x}}}, Lcom/mod/RecorderMod;->bitrate(Landroid/content/Context;I)I\n\n"
                f"    move-result {x}\n\n"
                f"    iput {x}, p0, {REC}ScreenRecorderContext;->bitrate:I\n")
        return b[:mm.end()] + code + b[mm.end():]
    t = patch_method(t, "setRecordingResolutionAndBitrate", "", f)
    wr(path, t); notes.append("ScreenRecorderContext: auto-bitrate scaled x1.5 at 120fps")

def patch_utils(path):
    """collapseQuickPanel needs android.permission.STATUS_BAR (signature permission) -> SecurityException with our own signature.
    Wrap it so a failure is ignored (the panel just stays open)."""
    t = rd(path)
    if MARK in t: notes.append("ScreenRecorderUtils: already patched"); return
    U = "Lcom/samsung/android/app/smartcapture/screenrecorder/util/ScreenRecorderUtils;"
    def w(header, kind):
        return (header + "\n    .locals 1\n\n"
                "    :mod_try_start\n"
                f"    invoke-static {{p0}}, {U}->collapseQuickPanel$mod(Landroid/content/Context;)V\n"
                "    :mod_try_end\n"
                "    .catch Ljava/lang/Throwable; {:mod_try_start .. :mod_try_end} :mod_catch\n\n"
                "    :mod_ret\n    return-void\n\n"
                "    :mod_catch\n    move-exception v0\n\n    goto :mod_ret\n.end method\n")
    t = wrap_method(t, "collapseQuickPanel", "Landroid/content/Context;", w)
    t = t.rstrip("\n") + f"\n\n# {MARK}\n"
    wr(path, t); notes.append("ScreenRecorderUtils.collapseQuickPanel: SecurityException ignored")

# ---------------------------------------------------------------- generic safety net
def _param_words(params):
    n = 0; i = 0
    while i < len(params):
        c = params[i]
        if c in "JD": n += 2; i += 1
        elif c in "ZBSCIF": n += 1; i += 1
        else:
            while params[i] == "[": i += 1
            if params[i] == "L": i = params.index(";", i) + 1
            else: i += 1
            n += 1
    return n

_METH = re.compile(r"^\.method ((?:[\w-]+ )*)([^\s(]+)\(([^)]*)\)(\S+)[ \t]*\n(.*?)^\.end method[ \t]*\n", re.M | re.S)

def make_safe(path, names=None):
    """Every static method of a utility class gets try/catch(Throwable) -> default value (0/false/null).
    Our re-signed APK is not platform-signed, so hidden-API / signature-permission calls throw SecurityException."""
    t = rd(path)
    if MARK in t: notes.append(f"safe: {os.path.basename(path)} already patched"); return
    cm = re.search(r"^\.class .*?(L[^;\s]+;)\s*$", t, re.M)
    cls = cm.group(1)
    count = [0]
    def rep(m):
        flags, name, params, ret, body = m.group(1), m.group(2), m.group(3), m.group(4), m.group(5)
        fl = flags.split()
        if name.startswith("<") or "synthetic" in fl or "bridge" in fl or "abstract" in fl or "native" in fl: return m.group(0)
        is_static = "static" in fl
        if names is None:
            if not is_static: return m.group(0)       # default: static methods only
        elif name not in names: return m.group(0)       # explicit list: static or instance
        pw = _param_words(params) + (0 if is_static else 1)
        if is_static: op = "invoke-static"
        elif "private" in fl: op = "invoke-direct"
        else: op = "invoke-virtual"
        call = (f"{op}/range {{p0 .. p{pw-1}}}" if pw else f"{op} {{}}") + f", {cls}->{name}$mod({params}){ret}"
        if ret == "V": ok = "    return-void\n"; res = ""; dflt = "    return-void\n"
        elif ret in ("J", "D"): res = "    move-result-wide v0\n"; ok = "    return-wide v0\n"; dflt = "    const-wide/16 v0, 0x0\n\n    return-wide v0\n"
        elif ret[0] in "L[":
            res = "    move-result-object v0\n"; ok = "    return-object v0\n"
            if ret == "Ljava/lang/String;": dflt = '    const-string v0, ""\n\n    return-object v0\n'
            elif ret in ("Ljava/util/List;", "Ljava/util/ArrayList;", "Ljava/util/Collection;"):
                dflt = ("    new-instance v0, Ljava/util/ArrayList;\n\n    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V\n\n    return-object v0\n")
            else: dflt = "    const/4 v0, 0x0\n\n    return-object v0\n"
        else: res = "    move-result v0\n"; ok = "    return v0\n"; dflt = "    const/4 v0, 0x0\n\n    return v0\n"
        hdr = f".method {flags}{name}({params}){ret}\n"
        wrapper = (hdr + "    .locals 2\n\n    :mod_ts\n    " + call + "\n" + (("\n" + res) if res else "") +
                   "    :mod_te\n    .catch Ljava/lang/Throwable; {:mod_ts .. :mod_te} :mod_c\n\n" + ok +
                   "\n    :mod_c\n    move-exception v1\n\n" + dflt + ".end method\n\n")
        renamed = f".method {flags}{name}$mod({params}){ret}\n" + body + ".end method\n"
        count[0] += 1
        return wrapper + renamed
    t2 = _METH.sub(rep, t)
    t2 = t2.rstrip("\n") + f"\n\n# {MARK}\n"
    wr(path, t2); notes.append(f"safe: {os.path.basename(path)}: {count[0]} methods wrapped")

# ---------------------------------------------------------------- XML (new preference row)
def element_span(text, key_pos):
    start = text.rfind("<", 0, key_pos)
    tag = re.match(r"<([\w.:-]+)", text[start:]).group(1)
    # end of opening tag
    i = start; q = None
    while True:
        c = text[i]
        if q: 
            if c == q: q = None
        elif c in "\"'": q = c
        elif c == ">": break
        i += 1
    if text[i-1] == "/": return start, i + 1, tag
    close = text.index(f"</{tag}>", i) + len(f"</{tag}>")
    return start, close, tag

def patch_xml(root):
    done = 0
    for p in glob.glob(os.path.join(root, "res", "xml*", "*.xml")):
        t = rd(p)
        if Q_KEY not in t: continue
        if FPS_KEY in t: notes.append(f"xml: {os.path.relpath(p, root)} already has fps row"); done += 1; continue
        kp = t.index(Q_KEY)
        s, e, tag = element_span(t, kp)
        el = t[s:e]
        el2 = el.replace(Q_KEY, FPS_KEY)
        el2 = re.sub(r"\s+(?:android|app):(?:summary|dependency|id)=\"[^\"]*\"", "", el2)
        if re.search(r"(?:android|app):title=\"", el2):
            el2 = re.sub(r"((?:android|app):title=)\"[^\"]*\"", lambda m: f'{m.group(1)}"{FPS_TITLE}"', el2, count=1)
        else:
            el2 = re.sub(r"(<[\w.:-]+)", lambda m: f'{m.group(1)} android:title="{FPS_TITLE}"', el2, count=1)
        ls = t.rfind("\n", 0, s) + 1
        indent = t[ls:s] if t[ls:s].strip() == "" else "    "
        t = t[:e] + "\n" + indent + el2 + t[e:]
        wr(p, t); done += 1
        notes.append(f"xml: fps row added after quality row in {os.path.relpath(p, root)}")
    if not done: errors.append("no res/xml file contains key_screen_recorder_video_settings")

# ---------------------------------------------------------------- helper class
def add_helper(root):
    # put it next to the recorder code (same smali_classesN)
    sp = find_one(root, "screenrecorder/recorder/ScreenRecorder.smali")
    if not sp: return
    base = sp.split(os.sep + "com" + os.sep)[0]
    dst = os.path.join(base, "com", "mod", "RecorderMod.smali")
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy(os.path.join(HERE, "payload", "RecorderMod.smali"), dst)
    notes.append(f"helper class written: {os.path.relpath(dst, root)}")

def main():
    if len(sys.argv) != 2 or not os.path.isdir(sys.argv[1]):
        print(__doc__); sys.exit(2)
    root = sys.argv[1]
    targets = {
        "settings": find_one(root, "com/samsung/android/app/settings/SettingsFragment.smali"),
        "recorder": find_one(root, "screenrecorder/recorder/ScreenRecorder.smali"),
        "mp4": find_one(root, "screenrecorder/recorder/core/MP4Recorder.smali"),
        "ctx": find_one(root, "screenrecorder/recorder/ScreenRecorderContext.smali"),
        "utils": find_one(root, "screenrecorder/util/ScreenRecorderUtils.smali"),
    }
    steps = [("settings", patch_settings), ("recorder", patch_screen_recorder), ("mp4", patch_mp4), ("ctx", patch_context), ("utils", patch_utils)]
    for k, fn in steps:
        if targets[k]:
            try: fn(targets[k])
            except Exception as ex: errors.append(f"{k}: {ex}")
    safe = [find_one(root, "baseutil/device/DeviceUtils.smali"), find_one(root, "baseutil/device/DexUtils.smali")]
    safe += sorted(glob.glob(os.path.join(root, "smali*", "**", "baseutil", "sep", "SepWrapper*.smali"), recursive=True))
    safe.append(find_one(root, "baseutil/view/WindowManagerUtils.smali"))
    for sp in safe:
        if sp:
            try: make_safe(sp)
            except Exception as ex: errors.append(f"safe {os.path.basename(sp)}: {ex}")
    # instance methods (private, ()V): phone-state / cover / one-hand listeners need privileged permissions
    sp = find_one(root, "baseutil/device/ExternalEventDetector.smali")
    if sp:
        try: make_safe(sp, names={"registerCallStateChangeListener", "unregisterCallStateChangeListener",
                                  "registerCoverStateChangeListener", "unregisterCoverStateChangeListener",
                                  "registerOneHandOperationRunningStateChangeListener",
                                  "unregisterOneHandOperationRunningStateChangeListener"})
        except Exception as ex: errors.append(f"safe ExternalEventDetector: {ex}")
    try: patch_xml(root)
    except Exception as ex: errors.append(f"xml: {ex}")
    add_helper(root)
    print("\n".join("[ok]   " + n for n in notes))
    if errors:
        print("\n".join("[FAIL] " + e for e in errors)); sys.exit(1)
    print("done.")
if __name__ == "__main__": main()
