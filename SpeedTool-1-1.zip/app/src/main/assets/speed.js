'use strict';
// يقرأ السرعة من الملف كل 300ms ويغيّر الوقت اللي تشوفه اللعبة
const PATH = '/data/local/tmp/speed.txt';
let speed = 1.0;
let calls = 0, failedRead = false, failedHook = false;

function readSpeed() {
  let txt = null;
  try {
    txt = File.readAllText(PATH);
  } catch (e) {
    try { const f = new File(PATH, 'r'); txt = f.readLine(); f.close(); }
    catch (e2) {
      if (!failedRead) { failedRead = true; console.log('read speed file failed: ' + e2); }
      return;
    }
  }
  const v = parseFloat(txt);
  if (v > 0 && v <= 20 && v !== speed) { speed = v; console.log('speed=' + speed); }
}
readSpeed();
setInterval(readSpeed, 300);

function findExp(name) {
  try { if (Module.findExportByName) { const a = Module.findExportByName(null, name); if (a) return a; } } catch (e) {}
  try { const m = Process.getModuleByName('libc.so');
        if (m.findExportByName) { const a = m.findExportByName(name); if (a) return a; }
        if (m.getExportByName) return m.getExportByName(name); } catch (e) {}
  return null;
}

const st = {};
function warp(key, sec, frac) {
  const real = sec + frac;
  let s = st[key];
  if (!s) { s = { r: real, v: real, sp: speed }; st[key] = s; }
  if (s.sp !== speed) {
    s.v = s.v + (real - s.r) * s.sp;
    s.r = real;
    s.sp = speed;
  }
  const virt = s.v + (real - s.r) * s.sp;
  const vs = Math.floor(virt);
  return [vs, virt - vs];
}

const cg = findExp('clock_gettime');
if (cg) Interceptor.attach(cg, {
  onEnter(a) { this.clk = a[0].toInt32(); this.ts = a[1]; },
  onLeave(ret) {
    try {
      if (ret.toInt32() !== 0) return;
      const sec = Number(this.ts.readS64());
      const ns = Number(this.ts.add(8).readS64());
      const r = warp('c' + this.clk, sec, ns / 1e9);
      this.ts.writeS64(r[0]);
      this.ts.add(8).writeS64(Math.floor(r[1] * 1e9));
      if (calls++ < 3) console.log('clock_gettime hooked, clk=' + this.clk + ' speed=' + speed);
    } catch (e) { if (!failedHook) { failedHook = true; console.log('hook error: ' + e); } }
  }
});
console.log('clock_gettime: ' + cg);

const gt = findExp('gettimeofday');
if (gt) Interceptor.attach(gt, {
  onEnter(a) { this.tv = a[0]; },
  onLeave(ret) {
    try {
      if (ret.toInt32() !== 0 || this.tv.isNull()) return;
      const sec = Number(this.tv.readS64());
      const us = Number(this.tv.add(8).readS64());
      const r = warp('tod', sec, us / 1e6);
      this.tv.writeS64(r[0]);
      this.tv.add(8).writeS64(Math.floor(r[1] * 1e6));
    } catch (e) { if (!failedHook) { failedHook = true; console.log('hook error: ' + e); } }
  }
});
console.log('gettimeofday: ' + gt);
console.log('speed hook ready');
