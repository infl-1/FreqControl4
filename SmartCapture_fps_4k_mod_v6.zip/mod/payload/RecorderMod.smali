.class public final Lcom/mod/RecorderMod;
.super Ljava/lang/Object;
.source "RecorderMod.java"

# Added by apply_mod.py : frame-rate (30/60/120) and quality (SD/HD/FHD/4K) options

.field public static final Q_LABELS:[Ljava/lang/String;
.field public static final Q_VALUES:[Ljava/lang/String;
.field public static final Q_INTS:[I
.field public static final F_LABELS:[Ljava/lang/String;
.field public static final F_VALUES:[Ljava/lang/String;
.field public static final F_INTS:[I
.field public static sFps:I
.field public static sQ:I
.field public static sFi:I
.field public static sQi:I
.field public static sHeavy:Z

.method static constructor <clinit>()V
    .locals 3

    const/4 v0, 0x4
    new-array v0, v0, [Ljava/lang/String;
    const/4 v1, 0x0
    const-string v2, "4K (2160p)"
    aput-object v2, v0, v1
    const/4 v1, 0x1
    const-string v2, "FHD (1080p)"
    aput-object v2, v0, v1
    const/4 v1, 0x2
    const-string v2, "HD (720p)"
    aput-object v2, v0, v1
    const/4 v1, 0x3
    const-string v2, "SD (480p)"
    aput-object v2, v0, v1
    sput-object v0, Lcom/mod/RecorderMod;->Q_LABELS:[Ljava/lang/String;

    const/4 v0, 0x4
    new-array v0, v0, [Ljava/lang/String;
    const/4 v1, 0x0
    const-string v2, "2160"
    aput-object v2, v0, v1
    const/4 v1, 0x1
    const-string v2, "1080"
    aput-object v2, v0, v1
    const/4 v1, 0x2
    const-string v2, "720"
    aput-object v2, v0, v1
    const/4 v1, 0x3
    const-string v2, "480"
    aput-object v2, v0, v1
    sput-object v0, Lcom/mod/RecorderMod;->Q_VALUES:[Ljava/lang/String;

    const/4 v0, 0x4
    new-array v0, v0, [I
    const/4 v1, 0x0
    const/16 v2, 0x870
    aput v2, v0, v1
    const/4 v1, 0x1
    const/16 v2, 0x438
    aput v2, v0, v1
    const/4 v1, 0x2
    const/16 v2, 0x2d0
    aput v2, v0, v1
    const/4 v1, 0x3
    const/16 v2, 0x1e0
    aput v2, v0, v1
    sput-object v0, Lcom/mod/RecorderMod;->Q_INTS:[I

    const/4 v0, 0x3
    new-array v0, v0, [Ljava/lang/String;
    const/4 v1, 0x0
    const-string v2, "30 fps"
    aput-object v2, v0, v1
    const/4 v1, 0x1
    const-string v2, "60 fps"
    aput-object v2, v0, v1
    const/4 v1, 0x2
    const-string v2, "120 fps"
    aput-object v2, v0, v1
    sput-object v0, Lcom/mod/RecorderMod;->F_LABELS:[Ljava/lang/String;

    const/4 v0, 0x3
    new-array v0, v0, [Ljava/lang/String;
    const/4 v1, 0x0
    const-string v2, "30"
    aput-object v2, v0, v1
    const/4 v1, 0x1
    const-string v2, "60"
    aput-object v2, v0, v1
    const/4 v1, 0x2
    const-string v2, "120"
    aput-object v2, v0, v1
    sput-object v0, Lcom/mod/RecorderMod;->F_VALUES:[Ljava/lang/String;

    const/4 v0, 0x3
    new-array v0, v0, [I
    const/4 v1, 0x0
    const/16 v2, 0x1e
    aput v2, v0, v1
    const/4 v1, 0x1
    const/16 v2, 0x3c
    aput v2, v0, v1
    const/4 v1, 0x2
    const/16 v2, 0x78
    aput v2, v0, v1
    sput-object v0, Lcom/mod/RecorderMod;->F_INTS:[I

    return-void
.end method

.method public static find([Ljava/lang/String;Ljava/lang/String;)I
    .locals 3

    const/4 v0, 0x0

    :loop
    array-length v1, p0

    if-ge v0, v1, :not_found

    aget-object v2, p0, v0

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :found

    add-int/lit8 v0, v0, 0x1

    goto :loop

    :found
    return v0

    :not_found
    const/4 v0, -0x1

    return v0
.end method

.method public static load(Landroid/content/Context;)V
    .locals 6

    invoke-static {}, Lcom/samsung/android/app/smartcapture/screenrecorder/util/ScreenRecorderSharePreference;->getInstance()Lcom/samsung/android/app/smartcapture/screenrecorder/util/ScreenRecorderSharePreference;

    move-result-object v0

    const-string v1, "video_frame_rate"

    const-string v2, "60"

    invoke-virtual {v0, p0, v1, v2}, Lcom/samsung/android/app/smartcapture/screenrecorder/util/ScreenRecorderSharePreference;->loadStringState(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    sget-object v4, Lcom/mod/RecorderMod;->F_VALUES:[Ljava/lang/String;

    invoke-static {v4, v3}, Lcom/mod/RecorderMod;->find([Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    if-gez v3, :f_ok

    const/4 v3, 0x1

    :f_ok
    sput v3, Lcom/mod/RecorderMod;->sFi:I

    sget-object v4, Lcom/mod/RecorderMod;->F_INTS:[I

    aget v3, v4, v3

    sput v3, Lcom/mod/RecorderMod;->sFps:I

    const-string v1, "video_quality"

    const-string v2, "1080"

    invoke-virtual {v0, p0, v1, v2}, Lcom/samsung/android/app/smartcapture/screenrecorder/util/ScreenRecorderSharePreference;->loadStringState(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    sget-object v4, Lcom/mod/RecorderMod;->Q_VALUES:[Ljava/lang/String;

    invoke-static {v4, v5}, Lcom/mod/RecorderMod;->find([Ljava/lang/String;Ljava/lang/String;)I

    move-result v5

    if-gez v5, :q_ok

    const/4 v5, 0x1

    :q_ok
    sput v5, Lcom/mod/RecorderMod;->sQi:I

    sget-object v4, Lcom/mod/RecorderMod;->Q_INTS:[I

    aget v5, v4, v5

    sput v5, Lcom/mod/RecorderMod;->sQ:I

    const/4 v0, 0x0

    const/16 v1, 0x438

    if-gt v5, v1, :heavy

    const/16 v1, 0x3c

    if-le v3, v1, :set_flag

    :heavy
    const/4 v0, 0x1

    :set_flag
    sput-boolean v0, Lcom/mod/RecorderMod;->sHeavy:Z

    return-void
.end method

.method public static fps(Landroid/content/Context;I)I
    .locals 1

    invoke-static {p0}, Lcom/mod/RecorderMod;->load(Landroid/content/Context;)V

    sget v0, Lcom/mod/RecorderMod;->sFps:I

    return v0
.end method

.method public static bitrate(Landroid/content/Context;I)I
    .locals 2

    invoke-static {p0}, Lcom/mod/RecorderMod;->load(Landroid/content/Context;)V

    sget v0, Lcom/mod/RecorderMod;->sFps:I

    const/16 v1, 0x78

    if-lt v0, v1, :done

    int-to-float v0, p1

    const/high16 v1, 0x3fc00000    # 1.5f

    mul-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result p1

    :done
    return p1
.end method

.method public static level4()Z
    .locals 2

    invoke-static {}, Lcom/samsung/android/app/smartcapture/screenrecorder/util/AudioUtil;->isSupportAVCMainProfileLevel4()Z

    move-result v0

    if-eqz v0, :done

    sget-boolean v0, Lcom/mod/RecorderMod;->sHeavy:Z

    xor-int/lit8 v0, v0, 0x1

    :done
    return v0
.end method

.method public static index(Landroid/content/Context;Z)I
    .locals 1

    invoke-static {p0}, Lcom/mod/RecorderMod;->load(Landroid/content/Context;)V

    if-eqz p1, :quality

    sget v0, Lcom/mod/RecorderMod;->sFi:I

    return v0

    :quality
    sget v0, Lcom/mod/RecorderMod;->sQi:I

    return v0
.end method

.method public static label(ZI)Ljava/lang/String;
    .locals 1

    if-eqz p0, :quality

    sget-object v0, Lcom/mod/RecorderMod;->F_LABELS:[Ljava/lang/String;

    goto :pick

    :quality
    sget-object v0, Lcom/mod/RecorderMod;->Q_LABELS:[Ljava/lang/String;

    :pick
    aget-object v0, v0, p1

    return-object v0
.end method

.method public static value(ZI)Ljava/lang/String;
    .locals 1

    if-eqz p0, :quality

    sget-object v0, Lcom/mod/RecorderMod;->F_VALUES:[Ljava/lang/String;

    goto :pick

    :quality
    sget-object v0, Lcom/mod/RecorderMod;->Q_VALUES:[Ljava/lang/String;

    :pick
    aget-object v0, v0, p1

    return-object v0
.end method

.method public static labelIndex(ZLjava/lang/String;)I
    .locals 1

    if-eqz p0, :quality

    sget-object v0, Lcom/mod/RecorderMod;->F_LABELS:[Ljava/lang/String;

    goto :pick

    :quality
    sget-object v0, Lcom/mod/RecorderMod;->Q_LABELS:[Ljava/lang/String;

    :pick
    invoke-static {v0, p1}, Lcom/mod/RecorderMod;->find([Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    return v0
.end method

.method public static putGlobal(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 1

    :mod_ts
    invoke-static {p0, p1, p2}, Landroid/provider/Settings$Global;->putString(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    :mod_te
    .catch Ljava/lang/Throwable; {:mod_ts .. :mod_te} :mod_c

    return v0

    :mod_c
    move-exception v0

    const/4 v0, 0x0

    return v0
.end method

.method public static needOverlay(Landroid/content/Context;)V
    .locals 2

    :mod_ts
    const-string v0, "\u0641\u0639\u0651\u0644 \u00ab\u0627\u0644\u0638\u0647\u0648\u0631 \u0641\u0648\u0642 \u0627\u0644\u062a\u0637\u0628\u064a\u0642\u0627\u062a\u00bb \u0644\u0633\u0645\u0627\u0631\u062a \u0643\u0627\u0628\u062a\u0634\u0631 \u062b\u0645 \u0623\u0639\u062f \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :mod_te
    .catch Ljava/lang/Throwable; {:mod_ts .. :mod_te} :mod_c

    return-void

    :mod_c
    move-exception v0

    return-void
.end method

.method public static safeCapture(Ljava/lang/String;Landroid/content/Context;FI)Landroid/graphics/Bitmap;
    .locals 1

    :mod_ts
    invoke-static {p0, p1, p2, p3}, Lcom/samsung/android/app/smartcapture/baseutil/view/CaptureUtils;->captureScreen(Ljava/lang/String;Landroid/content/Context;FI)Landroid/graphics/Bitmap;

    move-result-object v0

    :mod_te
    .catch Ljava/lang/Throwable; {:mod_ts .. :mod_te} :mod_c

    return-object v0

    :mod_c
    move-exception v0

    const/4 v0, 0x0

    return-object v0
.end method

.method public static neverEmpty(Landroid/graphics/Bitmap;)Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method public static rootCollapse()V
    .locals 4

    :mod_ts
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v0

    const/4 v1, 0x3

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "su"

    aput-object v3, v1, v2

    const/4 v2, 0x1

    const-string v3, "-c"

    aput-object v3, v1, v2

    const/4 v2, 0x2

    const-string v3, "cmd statusbar collapse"

    aput-object v3, v1, v2

    invoke-virtual {v0, v1}, Ljava/lang/Runtime;->exec([Ljava/lang/String;)Ljava/lang/Process;

    :mod_te
    .catch Ljava/lang/Throwable; {:mod_ts .. :mod_te} :mod_c

    return-void

    :mod_c
    move-exception v0

    return-void
.end method

.method public static collapsePanels(Ljava/lang/Object;)V
    .locals 1

    :mod_ts
    check-cast p0, Landroid/app/SemStatusBarManager;

    invoke-virtual {p0}, Landroid/app/SemStatusBarManager;->collapsePanels()V

    :mod_te
    .catch Ljava/lang/Throwable; {:mod_ts .. :mod_te} :mod_c

    return-void

    :mod_c
    move-exception v0

    invoke-static {}, Lcom/mod/RecorderMod;->rootCollapse()V

    return-void
.end method

.method public static tileStart(Landroid/service/quicksettings/TileService;Z)Z
    .locals 3

    :mod_ts
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "com.samsung.android.app.smartcapture.screenrecorder.ScreenRecorderStarterActivity"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "com.samsung.android.app.screenrecorder.ACTION_START"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x22

    if-lt v1, v2, :mod_old

    const/high16 v1, 0x4000000

    const/4 v2, 0x0

    invoke-static {p0, v2, v0, v1}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroid/service/quicksettings/TileService;->startActivityAndCollapse(Landroid/app/PendingIntent;)V

    goto :mod_done

    :mod_old
    invoke-virtual {p0, v0}, Landroid/service/quicksettings/TileService;->startActivityAndCollapse(Landroid/content/Intent;)V

    :mod_done
    const/4 v0, 0x1

    :mod_te
    .catch Ljava/lang/Throwable; {:mod_ts .. :mod_te} :mod_c

    return v0

    :mod_c
    move-exception v0

    const/4 v0, 0x0

    return v0
.end method
