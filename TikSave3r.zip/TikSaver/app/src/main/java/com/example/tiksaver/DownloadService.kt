package com.example.tiksaver

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException

/** حالة التحميل المشتركة بين الخدمة والشاشة */
object DownloadState {
    data class State(
        val running: Boolean = false,
        val progress: Int = 0,
        val message: String = ""
    )

    val state = MutableStateFlow(State())
}

/**
 * خدمة أمامية (Foreground Service): تكمل التحميل حتى لو طلعت من التطبيق أو قفلت الشاشة.
 */
class DownloadService : Service() {

    companion object {
        private const val EXTRA_URL = "url"
        private const val EXTRA_HINT = "hint"
        private const val CHANNEL_ID = "downloads"
        private const val NOTIF_ID = 1001
        private const val NOTIF_DONE_ID = 1002
        private const val PROCESS_ID = "tiktok-download"

        fun start(context: Context, url: String, hint: String) {
            DownloadState.state.value = DownloadState.State(true, 0, "جاري التحميل...")
            val intent = Intent(context, DownloadService::class.java)
                .putExtra(EXTRA_URL, url)
                .putExtra(EXTRA_HINT, hint)
            ContextCompat.startForegroundService(context, intent)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastNotifiedPercent = -1
    private val videoExtensions = setOf("mp4", "mkv", "webm", "mov")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val url = intent?.getStringExtra(EXTRA_URL)
        if (url == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        val hint = intent?.getStringExtra(EXTRA_HINT).orEmpty()

        startForeground(
            NOTIF_ID,
            buildNotification("جاري التحميل...", 0),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        acquireWakeLock()
        scope.launch { runDownload(url, hint, startId) }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        releaseWakeLock()
        super.onDestroy()
    }

    private fun runDownload(url: String, hint: String, startId: Int) {
        var message = ""
        try {
            YoutubeDL.getInstance().init(applicationContext)
            FFmpeg.getInstance().init(applicationContext)
            val file = downloadVideo(url)
            saveToGallery(file)
            file.delete()
            message = "تم الحفظ في المعرض (Movies/TikSaver) ✅"
        } catch (e: Exception) {
            val reason = e.message?.lineSequence()?.firstOrNull { it.isNotBlank() }?.take(160)
                ?: e.javaClass.simpleName
            val hintLine = if (hint.isNotEmpty()) "\n[صور] $hint" else ""
            message = "فشل التحميل. تأكد من الرابط، أو اضغط «تحديث المحرك» وحاول مرة ثانية.$hintLine\n[تفاصيل] $reason"
        } finally {
            releaseWakeLock()
        }

        DownloadState.state.value = DownloadState.State(false, 0, message)
        notifyDone(message)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
    }

    private fun downloadVideo(url: String): File {
        val dir = File(cacheDir, "dl").apply {
            deleteRecursively()
            mkdirs()
        }
        val request = YoutubeDLRequest(url)
        request.addOption("-o", "${dir.absolutePath}/%(id)s.%(ext)s")
        request.addOption("-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b") // أعلى جودة
        request.addOption("--merge-output-format", "mp4")
        request.addOption("--no-playlist")

        YoutubeDL.getInstance().execute(request, PROCESS_ID) { p, _, _ ->
            onProgress(p.toInt().coerceIn(0, 100))
        }

        return dir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in videoExtensions }
            ?.maxByOrNull { it.length() }
            ?: throw IOException("لم يتم العثور على الملف")
    }

    private fun saveToGallery(file: File) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "video_${System.currentTimeMillis()}.${file.extension}")
            put(MediaStore.Video.Media.MIME_TYPE, mimeFor(file.extension))
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TikSaver")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri: Uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("تعذر إنشاء الملف في المعرض")

        resolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        } ?: throw IOException("تعذر الكتابة في المعرض")

        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
    }

    private fun mimeFor(ext: String): String = when (ext.lowercase()) {
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        else -> "video/mp4"
    }

    // ---------- الإشعارات وقفل الجهاز ----------

    private fun onProgress(percent: Int) {
        DownloadState.state.value = DownloadState.State(true, percent, "جاري التحميل... $percent%")
        if (percent != lastNotifiedPercent) {
            lastNotifiedPercent = percent
            getSystemService(NotificationManager::class.java)
                .notify(NOTIF_ID, buildNotification("جاري التحميل... $percent%", percent))
        }
    }

    private fun ensureChannel(): NotificationManager {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "التحميل", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return nm
    }

    private fun buildNotification(text: String, percent: Int): Notification {
        ensureChannel()
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("محمّل الفيديوهات")
            .setContentText(text)
            .setProgress(100, percent, percent <= 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun notifyDone(text: String) {
        val nm = ensureChannel()
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("محمّل الفيديوهات")
            .setContentText(text.lineSequence().first())
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIF_DONE_ID, notification)
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TikSaver:download").apply {
            acquire(3 * 60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }
}
