package de.robv.android.xposed.callbacks;
public abstract class XCallback {
    public static final int PRIORITY_DEFAULT = 50;
    public XCallback() { }
    public XCallback(int priority) { }
    public static abstract class Param {
        public Param() { }
    }
}
