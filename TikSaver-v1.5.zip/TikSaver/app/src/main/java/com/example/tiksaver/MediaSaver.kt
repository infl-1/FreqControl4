package com.example.tiksaver

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.IOException
import java.io.OutputStream

/** حفظ الملفات في المعرض (Movies / Music / Pictures)/TikSaver عبر MediaStore. */
object MediaSaver {

    private fun videoMime(ext: String): String = when (ext.lowercase()) {
        "webm" -> "video/webm"
        "mov" -> "video/quicktime"
        "mkv" -> "video/x-matroska"
        else -> "video/mp4"
    }

    private fun audioMime(ext: String): String = when (ext.lowercase()) {
        "opus", "ogg" -> "audio/ogg"
        "flac" -> "audio/flac"
        "wav" -> "audio/x-wav"
        "m4a", "aac" -> "audio/mp4"
        else -> "audio/mpeg"
    }

    private fun save(
        context: Context,
        collection: Uri,
        name: String,
        mime: String,
        relativePath: String,
        writer: (OutputStream) -> Unit
    ) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(collection, values) ?: throw IOException("تعذر إنشاء الملف في المعرض")
        val out = resolver.openOutputStream(uri) ?: throw IOException("تعذر الكتابة في المعرض")
        out.use { writer(it) }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
    }

    fun saveVideo(context: Context, file: File) {
        val ext = file.extension
        save(
            context, MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            "video_${System.currentTimeMillis()}.$ext", videoMime(ext),
            Environment.DIRECTORY_MOVIES + "/TikSaver"
        ) { out -> file.inputStream().use { it.copyTo(out) } }
    }

    fun saveAudio(context: Context, file: File) {
        val ext = file.extension
        save(
            context, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            "audio_${System.currentTimeMillis()}.$ext", audioMime(ext),
            Environment.DIRECTORY_MUSIC + "/TikSaver"
        ) { out -> file.inputStream().use { it.copyTo(out) } }
    }

    fun saveImage(context: Context, bytes: ByteArray, name: String, mime: String) {
        save(
            context, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, name, mime,
            Environment.DIRECTORY_PICTURES + "/TikSaver"
        ) { out -> out.write(bytes) }
    }
}
