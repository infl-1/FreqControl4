.class public final Lcom/mod/FpsCap;
.super Ljava/lang/Object;
.source "FpsCap.java"

# Caps the frames the encoder accepts from the input surface (drops extra frames from 120Hz games)

.method public static apply(Landroid/media/MediaFormat;I)V
    .locals 3

    if-lez p1, :done

    int-to-float v0, p1

    const-string v1, "max-fps-to-encoder"

    :try_start_0
    invoke-virtual {p0, v1, v0}, Landroid/media/MediaFormat;->setFloat(Ljava/lang/String;F)V
    :try_end_0
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_0} :catch_0

    :done
    return-void

    :catch_0
    move-exception v2

    return-void
.end method
