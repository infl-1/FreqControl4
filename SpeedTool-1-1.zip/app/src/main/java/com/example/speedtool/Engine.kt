package com.example.speedtool

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.Locale

object Engine {
    const val DIR = "/data/local/tmp"
    // ألعاب أونلاين تنحظر فيها الحسابات: الأداة ترفض تشتغل عليها
    private val blocked = listOf("callofduty", "codm", "com.tencent.ig", "com.pubg", "freefire")
    private val main = Handler(Looper.getMainLooper())

    @Volatile var pkg: String? = null
    @Volatile var speed = 2.0
    @Volatile var running = false

    fun isBlocked(name: String) = blocked.any { name.contains(it, ignoreCase = true) }

    private fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)

    fun su(cmd: String, cb: ((String) -> Unit)? = null) {
        Thread {
            val out = try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                p.outputStream.close()
                val o = p.inputStream.bufferedReader().readText() +
                        p.errorStream.bufferedReader().readText()
                p.waitFor()
                o
            } catch (e: Exception) {
                "فشل: لا يوجد روت؟ ${e.message}"
            }
            if (cb != null) main.post { cb(out.trim().ifBlank { "تم" }) }
        }.start()
    }

    fun start(ctx: Context, cb: (String) -> Unit) {
        val name = pkg
        if (name == null) { cb("اختر تطبيقًا أولًا"); return }
        if (isBlocked(name)) { cb("هذا تطبيق أونلاين وفيه حظر للحسابات، الأداة ترفض تشتغل عليه."); return }
        val tmp = File(ctx.filesDir, "speed.js")
        ctx.assets.open("speed.js").use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        running = true
        su(
            "setenforce 0; " +
            "pkill -x frida-inject; " +
            "cp ${tmp.absolutePath} $DIR/speed.js; chmod 644 $DIR/speed.js; " +
            "echo ${fmt(speed)} > $DIR/speed.txt; chmod 644 $DIR/speed.txt; " +
            "chmod 755 $DIR/frida-inject; " +
            "nohup $DIR/frida-inject -n $name -s $DIR/speed.js > $DIR/frida.log 2>&1 < /dev/null & " +
            "sleep 2; tail -n 8 $DIR/frida.log",
            cb
        )
    }

    fun setSpeed(v: Double) {
        speed = v
        if (running) su("echo ${fmt(v)} > $DIR/speed.txt; chmod 644 $DIR/speed.txt")
    }

    fun stop(cb: ((String) -> Unit)? = null) {
        running = false
        su("echo 1.00 > $DIR/speed.txt; sleep 1; pkill -x frida-inject", cb)
    }

    fun readLog(cb: (String) -> Unit) = su("tail -n 12 $DIR/frida.log", cb)
}
