package com.example.speedtool

import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.Locale

object Engine {
    const val DIR = "/data/local/tmp"
    // ألعاب أونلاين تنحظر فيها الحسابات: الأداة ترفض تشتغل عليها
    private val blocked = listOf("callofduty", "codm", "com.tencent.ig", "com.pubg", "freefire")
    private val validName = Regex("^[A-Za-z0-9._]+$")
    private val main = Handler(Looper.getMainLooper())

    // يرجّع SELinux لحالته الأصلية (نحفظها قبل ما نخليه Permissive)
    private const val RESTORE_SELINUX =
        "p=\$(cat $DIR/selinux_prev 2>/dev/null); [ \"\$p\" = Enforcing ] && setenforce 1; rm -f $DIR/selinux_prev; true"

    class App(val pkg: String, val label: String, val icon: Drawable?)

    @Volatile var pkg: String? = null
    @Volatile var speed = 2.0
    @Volatile var running = false
    @Volatile var startedAt = 0L

    fun isBlocked(name: String) = blocked.any { name.contains(it, ignoreCase = true) }

    private fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)

    fun su(cmd: String, cb: ((String) -> Unit)? = null) {
        Thread {
            val out = try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                p.outputStream.close()
                val o = p.inputStream.bufferedReader().readText() +
                        p.errorStream.bufferedReader().readText()
                p.waitFor()
                o
            } catch (e: Exception) {
                "فشل: لا يوجد روت؟ ${e.message}"
            }
            if (cb != null) main.post { cb(out.trim().ifBlank { "تم" }) }
        }.start()
    }

    /** التطبيقات (غير النظام) الشغالة الآن، مرتبة بالاسم. */
    fun listRunning(ctx: Context, cb: (List<App>) -> Unit) {
        val appCtx = ctx.applicationContext
        Thread {
            val apps: List<App> = try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "ps -A -o NAME 2>/dev/null"))
                p.outputStream.close()
                val names = p.inputStream.bufferedReader().readLines()
                    .map { it.trim().substringBefore(':') }.toSet()
                p.waitFor()
                val pm = appCtx.packageManager
                pm.getInstalledApplications(0)
                    .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                    .filter { it.packageName != appCtx.packageName && (it.packageName in names) }
                    .map {
                        val ic = try { pm.getApplicationIcon(it) } catch (e: Exception) { null }
                        App(it.packageName, pm.getApplicationLabel(it).toString(), ic)
                    }
                    .sortedBy { it.label.lowercase() }
            } catch (e: Exception) {
                emptyList()
            }
            main.post { cb(apps) }
        }.start()
    }

    /** يفك ضغط frida-inject.xz المدمج في الـ APK إلى مجلد التطبيق (مرة وحدة، أو لما يتغير الملف). */
    private fun prepareBundled(ctx: Context): File? {
        val dst = File(ctx.filesDir, "frida-inject")
        val marker = File(ctx.filesDir, "frida-inject.ok")
        val tag = try {
            ctx.assets.open("frida-inject.xz").use { it.available().toString() }
        } catch (e: Exception) {
            return null                         // الـ APK مبني بدون frida-inject.xz
        }
        if (dst.exists() && dst.length() > 1_000_000L && marker.exists() && marker.readText() == tag) return dst
        marker.delete()
        ctx.assets.open("frida-inject.xz").use { raw ->
            org.tukaani.xz.XZInputStream(java.io.BufferedInputStream(raw, 1 shl 16)).use { xz ->
                dst.outputStream().use { o -> xz.copyTo(o, 1 shl 16) }
            }
        }
        marker.writeText(tag)
        return dst
    }

    fun start(ctx: Context, cb: (String) -> Unit) {
        val name = pkg
        if (name == null) { cb("اختر تطبيقًا أولًا"); return }
        if (isBlocked(name)) { cb("هذا تطبيق أونلاين وفيه حظر للحسابات، الأداة ترفض تشتغل عليه."); return }
        if (!validName.matches(name)) { cb("اسم الحزمة غير صالح"); return }
        running = true
        startedAt = System.currentTimeMillis()
        val appCtx = ctx.applicationContext
        Thread {
            val js = File(appCtx.filesDir, "speed.js")
            val bundled = try {
                appCtx.assets.open("speed.js").use { i -> js.outputStream().use { o -> i.copyTo(o) } }
                prepareBundled(appCtx)
            } catch (e: Exception) {
                null
            }
            // لو frida-inject مدمج: ننسخه لـ /data/local/tmp (إذا غير موجود أو حجمه مختلف)
            val install = if (bundled != null)
                "[ \"\$(stat -c %s $DIR/frida-inject 2>/dev/null)\" = \"${bundled.length()}\" ] || cp ${bundled.absolutePath} $DIR/frida-inject; "
            else ""
            su(
                install +
                "[ -f $DIR/frida-inject ] || { echo 'FC_ERR: frida-inject غير موجود (frida-inject.xz ناقص من الـ APK)'; exit 3; }; " +
                "PID=\$(pidof $name | cut -d' ' -f1); " +
                "[ -n \"\$PID\" ] || { echo 'FC_ERR: التطبيق غير شغّال، افتحه أولًا'; exit 4; }; " +
                "[ \"\$(getenforce)\" = Enforcing ] && echo Enforcing > $DIR/selinux_prev; " +
                "setenforce 0; " +
                "pkill -x frida-inject; " +
                "cp ${js.absolutePath} $DIR/speed.js; chmod 644 $DIR/speed.js; " +
                "echo ${fmt(speed)} > $DIR/speed.txt; chmod 644 $DIR/speed.txt; " +
                "chmod 755 $DIR/frida-inject; " +
                "nohup $DIR/frida-inject -p \$PID -s $DIR/speed.js > $DIR/frida.log 2>&1 < /dev/null & " +
                "sleep 2; " +
                "pgrep -x frida-inject >/dev/null || echo 'FC_ERR: توقف الحاقن، شوف السجل'; " +
                "tail -n 8 $DIR/frida.log"
            ) { out ->
                if (out.contains("FC_ERR")) {
                    running = false
                    su(RESTORE_SELINUX)            // فشل التشغيل: لا نترك SELinux مفتوح
                }
                cb(out.replace("FC_ERR: ", ""))
            }
        }.start()
    }

    fun updateSpeed(v: Double) {
        speed = v
        if (running) su("echo ${fmt(v)} > $DIR/speed.txt; chmod 644 $DIR/speed.txt")
    }

    fun stop(cb: ((String) -> Unit)? = null) {
        running = false
        // أرجع السرعة 1.00 أول، ثم أوقف الحاقن، ثم أرجع SELinux
        su("echo 1.00 > $DIR/speed.txt; sleep 1; pkill -x frida-inject; $RESTORE_SELINUX", cb)
    }

    /** هل الحاقن لسا شغّال؟ (يموت لو اللعبة أُغلقت) */
    fun alive(cb: (Boolean) -> Unit) =
        su("pgrep -x frida-inject >/dev/null && echo ON || echo OFF") { cb(it.trim() == "ON") }

    fun readLog(cb: (String) -> Unit) = su("tail -n 12 $DIR/frida.log", cb)
}
