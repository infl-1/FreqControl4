# Compatibility check: NexAlloy 2.0.111 fingerprints vs YouTube 21.41.526

Method: parsed the NexAlloy `classes.dex`, pulled every string constant out of the 238
YouTube/shared `*Fingerprint` classes, and looked each one up in the string pools of the 8 dex
files of YouTube 21.41.526 (`tools/dex.py`).

Result: 174 of 238 fingerprints have all of their string anchors present. The other 64 were
filtered down to the ones that are genuine string literals (the rest are method references or
resource names that are never in a dex string pool, so they say nothing either way).

String literals that no longer exist in 21.41.526 (these fingerprints need a new anchor):

| Fingerprint | Missing string |
|---|---|
| shared/ad/LithoDialogBuilderFingerprint | `SlidingDialogAnimation` |
| youtube/interaction/downloads/OfflineVideoEndpointFingerprint | `Unsupported Offline Video Action: ` |
| youtube/interaction/downloads/ResolveCommandFingerprint | `Unknown command not resolved` |
| youtube/layout/hide/general/ParseElementFromBufferFingerprint | `Failed to parse Element` |
| youtube/misc/contexthook/ReelCreateItemsEndpointConstructorFingerprint | `reel/create_reel_items` |
| youtube/misc/imageurlhook/MessageDigestImageUrlParentFingerprint | `@#&=*+-_.,:!?()/~'%;$` |
| youtube/misc/playercontrols/ElementsImageComponentFingerprint | `Failed to find a valid source for the image` |
| youtube/shared/PlaybackStartDescriptorToStringFingerprint | `PlaybackStartDescriptor:` |
| youtube/video/information/PlayerControllerSetTimeReferenceFingerprint | `Media progress reported outside media playback: ` |

Caveats:
* Fingerprints also match on opcodes, parameter types and call structure. A fingerprint whose
  strings are all present can still be broken, so "174 OK" is an upper bound, not a guarantee.
* Only static analysis was done. Nothing here was run on a device.
