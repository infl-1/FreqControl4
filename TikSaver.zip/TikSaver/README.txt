طريقة بناء الـ APK:
1) نزّل وثبّت Android Studio (آخر إصدار).
2) فك الضغط عن المجلد، ثم File > Open واختر مجلد TikSaver.
3) انتظر انتهاء Gradle Sync (يحتاج إنترنت، أول مرة ياخذ كم دقيقة).
4) Build > Build Bundle(s) / APK(s) > Build APK(s)
5) الملف يطلع في: app/build/outputs/apk/debug/app-debug.apk
6) انقله للجوال وثبّته (فعّل "التثبيت من مصادر غير معروفة").

ملاحظات:
- أول تشغيل يفك المحرك (بايثون + yt-dlp) فيأخذ شوي.
- لو وقف التحميل مستقبلاً اضغط "تحديث المحرك".
- لو Gradle ما لقى المكتبة: افتح app/build.gradle.kts وغيّر رقم نسخة youtubedl-android
  لآخر نسخة من github.com/yausername/youtubedl-android
- يمكنك أيضاً المشاركة من تيك توك مباشرة: مشاركة > TikSaver.
