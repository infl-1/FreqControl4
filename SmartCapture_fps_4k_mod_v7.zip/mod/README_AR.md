# إضافة خيارات الجودة (HD / FHD / 4K) ومعدل الإطارات (30 / 60 / 120) لمسجّل الشاشة

## الاستخدام (في مستودعك قبل البناء)
```bash
apktool d SmartCapture.apk -o SmartCapture      # فك التطبيق
python3 apply_mod.py SmartCapture               # تطبيق التعديل (مرة وحدة، وإذا كررته ما يضر)
apktool b SmartCapture -o SmartCapture_mod.apk  # بناء
# ثم zipalign + توقيع بنفس طريقتك الحالية
```
إذا طلع سطر `[FAIL]` أرسله لي كما هو.
شغّله على مجلد **جديد** من `apktool d` للـ APK الأصلي (مو على مجلد معدّل بإصدار قديم من المود).

## تحديث v7 (من log3_1.txt)
1. **قائمة التسجيل تكرش والكيبورد مفتوح:** `getSoundSettingSuggestionPopupWindowType` ترجع 2012 (`TYPE_INPUT_METHOD_DIALOG`) لما الكيبورد ظاهر، والنظام يرفضه (`permission denied for window type 2012`). صارت ترجع 2038 دايماً (نوافذ overlay تنرسم فوق الكيبورد).
2. **شريط أدوات اللقطة العادية يكرش:** `ScrollCaptureAbstractMainUiView.onAttachedToWindow` ← `canScrollCapture` ← `SemRemoteAppDataExtractionManager` تحتاج صلاحية النظام `EXTRACT_SMARTCLIP_DATA` فترمي `SecurityException`. دالتا `ScrollInfoExtractor.extractScrollInfoFromRemoteApp` و`extractViewInfoFromRemoteApp` صارتا ترجعان null عند أي خطأ (والتطبيق أصلاً يعامل null كـ «ما فيه شي قابل للتمرير»). النتيجة: الشريط يظهر، لكن التقاط التمرير (Scroll capture) ما يشتغل.
3. **تضغط «بدء» في القائمة والخدمة تتقفل بدون تسجيل:** `checkPreConditionsThenStartRecording` توقف الخدمة كلها عند **أي** استثناء من `checkPreConditions` (أي فحص يرمي SecurityException مثل حالة المكالمات). الحين فقط الإيقافات المقصودة (بطارية منخفضة، مساحة قليلة، Dex على PC) توقف، وغيرها يُسجَّل في logcat بالوسم `MODFPS` ويكمل التسجيل.
4. **إغلاق شريط الإشعارات:** ضغطة البلاط تفتح `ScreenRecorderStarterActivity` عبر `TileService.startActivityAndCollapse` (الطريقة الرسمية بدون صلاحيات)، ودوال `collapsePanels` الأصلية صارت محمية من الأخطاء مع احتياطي روت. للتعطيل: `python3 apply_mod.py <المجلد> --no-collapse`.
- لو لسا ما بدأ التسجيل، التقط لوق وفيه الوسم `MODFPS`: `logcat -d | grep -E "MODFPS|AndroidRuntime|smartcapture"`.

## تحديث v6 — رسالة «يتعذر تسجيل الشاشة بسبب سياسة الحماية»
- **السبب (مؤكد من الكود):** `ScreenRecorderController.checkPreConditions()` تلتقط لقطة شاشة تجريبية قبل التسجيل عبر `CaptureUtils.captureScreen` (واجهة نظام مخفية). لو رجعت اللقطة فاضية يعتبرها «طبقة محمية» ويعرض الرسالة (رمز الخطأ -0xc354) ويوقف التسجيل. التطبيق غير موقّع بتوقيع النظام فتطلع فاضية دايماً.
- **الحل:** اللقطة التجريبية صارت محمية من الأخطاء (`RecorderMod.safeCapture`) ونتيجتها ما تُعتبر «محمية» أبداً (`RecorderMod.neverEmpty`)، فيكمل الفحص (البطارية والمساحة والمكالمات) ويبدأ التسجيل. المحتوى المحمي (FLAG_SECURE) يظهر أسود في التسجيل حسب النظام.
- إغلاق شريط الإشعارات صار مفعّل افتراضياً من v7 (انظر أدناه).

## تحديث v5 (من log3.txt + فحص كود الـ APK نفسه)
الأسباب الحقيقية للمشاكل الثلاث (كلها مأخوذة من الـ dex، مو تخمين):

1. **أزرار التحكم بعد لقطة الشاشة ما تظهر:** `ServiceFragment.createLayoutParams` تطلب نوع نافذة سامسونج `SEM_TYPE_SCROLL_CAPTURE` (القيمة 2441) عن طريق `DeviceUtils.getWindowType`، والنظام يرفضه لتطبيق مو موقّع بتوقيع النظام (`BadTokenException: permission denied for window type 2441`).
   - الحل: `getWindowType` تعطي `TYPE_APPLICATION_OVERLAY` (2038) لكل نوافذ العرض. المسارين اللي يستخدمونه لالتقاط الشاشة فعلياً (`GlobalScreenshot.takeScreenshot` و`PartialMagnifierViewController.captureBitmap`) يستخدمون نسخة أصلية اسمها `getWindowTypeRaw` عشان ما يتغير سلوك اللقطة.
   - نفس الشي لنافذة العد التنازلي وأزرار التسجيل (`CountdownView` / `FloatingButtonView` تستخدم `TYPE_SCREENSHOT`)، وبعض الحوارات اللي كانت تستخدم 2008 / 2412 ثابتة.
2. **ضغطة وحدة على مسجل الشاشة ما تفتح نافذة البدء:** `ScreenRecorderController.canDrawOverlay` لما صلاحية «الظهور فوق التطبيقات» مو ممنوحة تبني حوار على سياق ينشأ عن `createWindowContext(2008)`، وإصلاحات v3 كانت ترجّع null بدل الخطأ، فيصير `NPE` في `LayoutInflater` (اللي شفناه في اللوق، سطر 145).
   - الحل: إذا الصلاحية ناقصة يطلع Toast، ويفتح صفحة الصلاحية، ويوقف الخدمة بدون كراش.
   - **مهم: لازم تمنح التطبيق صلاحية «الظهور فوق التطبيقات» مرة وحدة** (الإعدادات ← التطبيقات ← سمارت كابتشر ← الظهور فوق التطبيقات)، أو بصلاحية الروت:
     `su -c "appops set com.samsung.android.app.smartcapture SYSTEM_ALERT_WINDOW allow"`
     بدونها كل نوافذ التطبيق (الشريط والعد التنازلي والأزرار) ما تنعرض لأن النوع 2038 يحتاجها.
3. **الجودة تتغير بالقائمة وما تنحفظ:** `ScreenRecorderSharePreference.saveStringState` لمفتاح `video_quality` تكتب أول شي في `Settings.Global` (تحتاج `WRITE_SECURE_SETTINGS`)، ولما ترمي `SecurityException` يتم تجاهل كتابة `SharedPreferences` بعدها. فما ينحفظ شي أبداً (حتى بدون المود).
   - الحل: كتابة `Settings.Global` تتغلّف بـ try/catch (دالة `RecorderMod.putGlobal`) وتكمل الكتابة العادية.

## تحديث v4 (من log3.txt)
- **شريط الأدوات ما يطلع بعد اللقطة:** `ScreenshotUiService` كان يكرش في `WindowManagerUtils.getVisibleWindowList` (تحتاج `MANAGE_ACTIVITY_TASKS`). الحين تُغلَّف وترجع قائمة فاضية بدل الكراش.
- **نافذة التسجيل (نقرة وحدة على الـ tile) تكرش:** `ScreenRecorderService` كان يكرش في `ExternalEventDetector.registerCallStateChangeListener` (`SecurityException: listen`، تحتاج صلاحية حالة الهاتف المميزة). الحين دوال تسجيل/إلغاء مستمعات المكالمات والغطاء ووضع اليد الواحدة تتغلّف بـ try/catch.
- النتيجة الجانبية: التسجيل ما يتوقف تلقائياً عند اتصال مكالمة.

## تحديث v3 (كراشات جولة logcat الثانية)
- بعد إصلاحات v2 اختفى `VerifyError` و`STATUS_BAR`، وظهرت أخطاء صلاحيات نظام ثانية:
  - `DeviceUtils.getFocusedUserId` ← `INTERACT_ACROSS_USERS` (كان يكرش عند بدء خدمة التسجيل).
  - `DexUtils.isDesktopStandAloneMode` ← `LauncherProvider READ_SETTINGS` (كان يكرش صفحة الإعدادات).
- الحل: كل دوال `static` في `DeviceUtils` و`DexUtils` وكلاسات `SepWrapper*` تتغلّف بـ try/catch، وإذا انرفضت الصلاحية ترجع قيمة افتراضية (0 / false / null) بدل ما يكرش التطبيق.
- ملاحظة: القيمة الافتراضية ممكن تعطّل ميزة جانبية (مثل كشف وضع DeX)، لكن ما تأثر على التسجيل نفسه.

## تحديث v2 (إصلاح الكراش — من سجل logcat الحقيقي)
- **VerifyError في `SettingsFragment.updateScreenRecorderSettings`**: المترجم (R8) يعيد استخدام السجل `p0` لقيمة ثانية قبل نهاية الدالة، فاستدعاء `modRefresh` عند `return-void` كان يمرّر قيمة غلط بدل `this`. الحين الدالة الأصلية تتسمّى `...$mod` وفوقها غلاف صغير ينادي الأصلية ثم `modRefresh`.
- **SecurityException في زر التسجيل (tile)**: `ScreenRecorderUtils.collapseQuickPanel` تحتاج صلاحية النظام `STATUS_BAR` وما تنمنح لتطبيق بتوقيع غير توقيع سامسونج. الحين تُغلَّف بـ try/catch وتتجاهل الخطأ (لوحة الإشعارات ما تنقفل تلقائياً).
- **مهم:** شغّل السكربت على مجلد جديد من `apktool d` للـ APK **الأصلي**، مو على المجلد المعدّل قبل.

## وش يضيف
| الشاشة | التعديل |
|---|---|
| إعدادات لقطات الشاشة وتسجيلات الشاشة | قائمة الجودة تصير: **4K (2160p) / FHD (1080p) / HD (720p) / SD (480p)** |
| نفس الشاشة، تحت صف الجودة | صف جديد **معدل الإطارات (FPS)**: 30 / 60 / 120 |

القيم تنحفظ في نفس تخزين التطبيق: `video_quality` (موجود أصلاً، صار يقبل 2160) و `video_frame_rate` (جديد).

## كيف يشتغل (للمراجعة)
- `res/xml/*.xml`: ينسخ صف الجودة نفسه ويسمّيه `key_screen_recorder_frame_rate`.
- `SettingsFragment`: يحقن 4 دوال (`modSetup / modRefresh / modOnChange / modApply`) ويربطها في `onCreate` و `onPreferenceChange` و `updateScreenRecorderSettings`.
- `ScreenRecorder.initRecorder`: كان معدل الإطارات ثابت 60 (`displayFrameRate`)، الحين يقرأ اختيارك.
- `ScreenRecorderContext.setRecordingResolutionAndBitrate`: عند 120 إطار يرفع الـ bitrate التلقائي ×1.5.
- `MP4Recorder.initVideo`: التطبيق يفرض AVC Main Level 4، وهذا يمنع الدقات العالية، فيُتجاوز عند 4K أو أكثر من 60 إطار.
- كلاس مساعد جديد: `com/mod/RecorderMod.smali`.

## ملاحظات مهمة
1. **لم يُجرَّب على جهاز** (بيئتي ما فيها apktool ولا جهاز). تحققت أن كل الدوال والحقول المشفّرة المستخدمة موجودة فعلاً في ملفات dex، وأن السجلات والـ labels صحيحة، وجرّبت السكربت على ملفات smali تجريبية بنفس صيغة baksmali.
2. **120 إطار** ما تعطي نتيجة إلا إذا شاشتك تشتغل 120Hz أثناء التسجيل (وضع الحركة السلسة مفعّل) وكان المرمّز يدعمها.
3. **4K** معناها هنا أن الضلع القصير = 2160. التطبيق أصلاً يقص الدقة حسب أقصى ما يدعمه مرمّز AVC في جهازك، فإذا جهازك يدعم أقل، تتقلص تلقائياً.
4. إذا فشل التسجيل عند 4K أو 120، جرّب خفض واحد منهما لتعرف أيهما حدّ جهازك.
5. المسمّيات المشفّرة (`ListPreference.s/t` و `DropDownPreference.x/h` و `m2`) مأخوذة من نفس هذا الـ APK، فلو غيّرت إصدار التطبيق لازم أعيد فحصها.
