plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.tiksaver"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.tiksaver"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // نخلي المعماريات اللي تشتغل على أغلب الجوالات عشان يصغر حجم التطبيق
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // مطلوب لمكتبة youtubedl-android (تفك مكتبات بايثون عند التشغيل)
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // yt-dlp داخل التطبيق (بدون سيرفر)
    implementation("com.github.yausername.youtubedl-android:library:0.17.2")
}
