#!/usr/bin/env python3
"""apply_fpscap.py <apktool_decoded_dir>
Makes the fps setting a real cap: adds max-fps-to-encoder to the encoder format.
Run after your existing apply step and before `apktool b`. Safe to run twice."""
import os, re, sys, glob, shutil
HERE = os.path.dirname(os.path.abspath(__file__))
MARK = "MOD-FPSCAP"
if len(sys.argv) != 2 or not os.path.isdir(sys.argv[1]): print(__doc__); sys.exit(2)
root = sys.argv[1]
hits = glob.glob(os.path.join(root, "smali*", "**", "screenrecorder", "recorder", "core", "MP4Recorder.smali"), recursive=True)
if len(hits) != 1: print("[FAIL] MP4Recorder.smali not found / ambiguous:", hits); sys.exit(1)
path = hits[0]
t = open(path, encoding="utf-8").read()
if MARK in t:
    print("[ok]   MP4Recorder already patched")
else:
    m = re.search(r"^\.method (?:[\w-]+ )*initVideo\(\)\S+\n.*?^\.end method", t, re.M | re.S)
    if not m: print("[FAIL] initVideo() not found"); sys.exit(1)
    body = m.group(0)
    pat = re.compile(r"const-string ([vp]\d+), \"frame-rate\"\s*\n(?:(?!const-string)[^\n]*\n){0,10}?"
                     r"([ \t]*)invoke-virtual \{([vp]\d+), \1, ([vp]\d+)\}, Landroid/media/MediaFormat;->setInteger\(Ljava/lang/String;I\)V[ \t]*\n")
    mm = pat.search(body)
    if not mm: print("[FAIL] frame-rate setInteger not found in initVideo"); sys.exit(1)
    ind, fmt, val = mm.group(2), mm.group(3), mm.group(4)
    add = f"\n{ind}# {MARK}\n{ind}invoke-static {{{fmt}, {val}}}, Lcom/mod/FpsCap;->apply(Landroid/media/MediaFormat;I)V\n"
    body = body[:mm.end()] + add + body[mm.end():]
    t = t[:m.start()] + body + t[m.end():]
    open(path, "w", encoding="utf-8", newline="\n").write(t)
    print("[ok]   MP4Recorder.initVideo: max-fps-to-encoder hook added")
base = path.split(os.sep + "com" + os.sep)[0]
dst = os.path.join(base, "com", "mod", "FpsCap.smali")
os.makedirs(os.path.dirname(dst), exist_ok=True)
shutil.copy(os.path.join(HERE, "payload", "FpsCap.smali"), dst)
print("[ok]   helper written:", os.path.relpath(dst, root))
