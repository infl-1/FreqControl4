package com.example.speedtool

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.util.Locale

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout            // نافذة الأيقونة الصغيرة (الفقاعة + السهمين)
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var bubble: BubbleView
    private lateinit var upBtn: ArrowView
    private lateinit var downBtn: ArrowView

    // اللوحة: نافذة مستقلة بكامل الشاشة وشفافة، تنفتح لما تضغط الأيقونة
    private lateinit var full: FrameLayout
    private lateinit var fullParams: WindowManager.LayoutParams
    private lateinit var card: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var body: LinearLayout
    private lateinit var colA: LinearLayout
    private lateinit var colB: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var footerRow: LinearLayout
    private lateinit var grpApp: View
    private lateinit var grpSpeed: View
    private lateinit var grpSrc: View
    private lateinit var speedLabel: TextView
    private lateinit var bar: SeekBar
    private lateinit var status: TextView
    private lateinit var toggle: TextView
    private lateinit var closeIcon: TextView
    private lateinit var quit: TextView
    private lateinit var readyHint: TextView

    private class SrcTile(val box: LinearLayout, val title: TextView, val sub: TextView)

    private val ui = Handler(Looper.getMainLooper())
    private var watchdog: Runnable? = null
    private var arrowsShown = false
    private var panelOpen = false
    private var shift = 0
    private var lastCommit = 0L
    private var refreshAll: () -> Unit = {}
    private var resetPage: () -> Unit = {}

    // مربعات المصدر (App / Java / System / Other) وحالة الجاهزية للحقن
    private val srcKeys = "AJSO"
    private val srcLabels = listOf("App", "Java", "System", "Other")
    private val tiles = ArrayList<SrcTile>()
    private var srcSeen = IntArray(Engine.ROWS * 4)   // استدعاءات بالثانية لكل (صف × مصدر): srcSeen[صف*4 + عمود]
    private var styleMatrix: () -> Unit = {}
    private var seenLive = false             // الأرقام حديثة (الحاقن شغّال وراسلنا)
    private var injectedNow = false
    private var probeGen = 0

    // إرسال السرعة للحاقن: مرة كل 250ms كحد أقصى (كل إرسال يشغّل su)
    private val commit = Runnable {
        lastCommit = SystemClock.uptimeMillis()
        Engine.updateSpeed(Engine.speed)
    }
    private val hideArrowsRun = Runnable { hideArrows() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_QUIT) Engine.quitAll(applicationContext)
        return START_NOT_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // السرعة من 0.01 إلى 100 (الشريط لوغاريتمي: يغطي القيم الصغيرة والكبيرة بنفس الدقة)
    private fun roundSpeed(v: Double): Double {
        val c = v.coerceIn(MIN_SPEED, MAX_SPEED)
        return if (c < 1.0) Math.round(c * 100) / 100.0 else Math.round(c * 10) / 10.0
    }
    private fun speedOf(progress: Int) =
        roundSpeed(MIN_SPEED * Math.pow(10.0, 4.0 * progress / BAR_MAX))
    private fun progressOf(speed: Double) =
        Math.round(Math.log10(speed.coerceIn(MIN_SPEED, MAX_SPEED) / MIN_SPEED) / 4.0 * BAR_MAX).toInt()
            .coerceIn(0, BAR_MAX)
    private fun fmtSpeed(v: Double) = when {
        v < 1.0 -> String.format(Locale.US, "%.2fx", v)
        v < 100.0 -> String.format(Locale.US, "%.1fx", v)
        else -> String.format(Locale.US, "%.0fx", v)
    }
    // حجم الخطوة حسب القيمة: صغيرة تحت 0.2، ثم 0.1، ثم 1.0 فوق 10
    private fun stepFor(v: Double, dir: Int): Double {
        val eps = 1e-9
        return when {
            v < 0.2 - eps || (dir < 0 && v <= 0.2 + eps) -> 0.01
            v < 10.0 - eps || (dir < 0 && v <= 10.0 + eps) -> 0.1
            else -> 1.0
        }
    }

    /** خدمة أمامية: بدونها أندرويد يقتل الأيقونة العائمة بعد ما التطبيق يروح للخلفية. */
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Speed Tool", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val quitIntent = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingService::class.java).setAction(ACTION_QUIT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val quitAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "إيقاف التطبيق", quitIntent
        ).build()
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
                      else Notification.Builder(this)
        val notif = builder
            .setContentTitle("Speed Tool")
            .setContentText("الأيقونة العائمة شغّالة")
            .setSmallIcon(android.R.drawable.ic_media_ff)
            .setOngoing(true)
            .addAction(quitAction)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notif)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        upBtn = ArrowView(this, true).apply { visibility = View.GONE }
        downBtn = ArrowView(this, false).apply { visibility = View.GONE }
        bubble = BubbleView(this).apply { speedText = fmtSpeed(Engine.speed) }
        head.addView(upBtn, LinearLayout.LayoutParams(dp(40), dp(40)).apply { bottomMargin = dp(6) })
        head.addView(bubble, LinearLayout.LayoutParams(dp(60), dp(60)))
        head.addView(downBtn, LinearLayout.LayoutParams(dp(40), dp(40)).apply { topMargin = dp(6) })

        buildPanel()

        root.addView(head, LinearLayout.LayoutParams(WRAP, WRAP))
        ui.post { fitOnScreen() }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8); y = dp(140)
        }

        // نافذة اللوحة: تملا الشاشة (داخل أشرطة النظام) وما تاخذ التركيز عشان اللعبة ما تتوقف
        fullParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        // لمسة: سحب = تحريك | ضغطة = فتح اللوحة | ضغط مطوّل = ظهور سهمين (أسرع/أبطأ)
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var moved = false; var longPressed = false
        val longPress = Runnable {
            longPressed = true
            bubble.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            showArrows()
        }
        bubble.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = params.x; startY = params.y
                    moved = false; longPressed = false
                    ui.postDelayed(longPress, 450)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (!moved && (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8))) {
                        moved = true
                        ui.removeCallbacks(longPress)
                    }
                    if (moved) {
                        params.x = startX + dx; params.y = startY + dy
                        updateRoot()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    ui.removeCallbacks(longPress)
                    if (!moved && !longPressed) togglePanel()
                }
                MotionEvent.ACTION_CANCEL -> ui.removeCallbacks(longPress)
            }
            true
        }

        // السهمين: ضغطة = 0.1، وإذا بقيت ضاغط يتكرر ويتسارع
        attachRepeat(upBtn, +1, true) { upBtn.down = it; upBtn.invalidate() }
        attachRepeat(downBtn, -1, true) { downBtn.down = it; downBtn.invalidate() }

        wm.addView(root, params)
        refreshAll()
    }

    // ---------------------------------------------------------------- السرعة

    private fun applySpeed(v: Double, fromBar: Boolean = false) {
        val sp = roundSpeed(v)
        Engine.speed = sp
        val t = fmtSpeed(sp)
        bubble.speedText = t
        bubble.invalidate()
        speedLabel.text = t
        if (!fromBar) bar.progress = progressOf(sp)
        ui.removeCallbacks(commit)
        val wait = (lastCommit + 250 - SystemClock.uptimeMillis()).coerceAtLeast(0)
        ui.postDelayed(commit, wait)
    }

    // كل ما طوّلت الضغط تكبر الخطوة
    private fun mult(count: Int) = when {
        count > 50 -> 10.0
        count > 30 -> 5.0
        count > 14 -> 2.0
        else -> 1.0
    }

    private fun attachRepeat(v: View, dir: Int, consume: Boolean, onPress: (Boolean) -> Unit = {}) {
        var count = 0
        val rep = object : Runnable {
            override fun run() {
                count++
                applySpeed(Engine.speed + dir * stepFor(Engine.speed, dir) * mult(count))
                armHide()
                ui.postDelayed(this, 90)
            }
        }
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    count = 0
                    onPress(true)
                    applySpeed(Engine.speed + dir * stepFor(Engine.speed, dir))
                    armHide()
                    ui.postDelayed(rep, 420)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(rep)
                    onPress(false)
                    armHide()
                }
            }
            consume
        }
    }

    // ---------------------------------------------------------------- الأسهم والأيقونة

    private fun updateRoot() {
        try { wm.updateViewLayout(root, params) } catch (e: Exception) {}
    }

    private fun arrowSpace() = dp(46)

    private fun showArrows() {
        if (!arrowsShown) {
            arrowsShown = true
            upBtn.visibility = View.VISIBLE
            downBtn.visibility = View.VISIBLE
            // نرفع النافذة بمقدار السهم العلوي عشان الأيقونة تبقى مكانها
            val newY = (params.y - arrowSpace()).coerceAtLeast(0)
            shift = params.y - newY
            params.y = newY
            updateRoot()
        }
        armHide()
    }

    private fun hideArrows() {
        if (!arrowsShown) return
        arrowsShown = false
        upBtn.visibility = View.GONE
        downBtn.visibility = View.GONE
        params.y += shift
        shift = 0
        updateRoot()
    }

    private fun armHide() {
        if (!arrowsShown) return
        ui.removeCallbacks(hideArrowsRun)
        ui.postDelayed(hideArrowsRun, 4000)
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): IntArray {
        val dm = android.util.DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels)
    }

    /** يرجّع الأيقونة داخل الشاشة (بعد التدوير أو بعد إغلاق اللوحة). */
    private fun fitOnScreen() {
        if (!::root.isInitialized || !::params.isInitialized) return
        val sz = screenSize()
        val sw = sz[0]; val sh = sz[1]
        root.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val maxY = sh - root.measuredHeight - dp(40)
        val maxX = sw - root.measuredWidth - dp(4)
        var changed = false
        if (params.y > maxY) { params.y = maxY.coerceAtLeast(0); changed = true }
        if (params.x > maxX) { params.x = maxX.coerceAtLeast(0); changed = true }
        if (changed) updateRoot()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        ui.postDelayed({
            if (panelOpen) arrange() else fitOnScreen()
        }, 200)
    }

    // ---------------------------------------------------------------- فتح وإغلاق اللوحة

    private fun togglePanel() {
        if (panelOpen) closePanel() else openPanel()
    }

    private fun openPanel() {
        if (panelOpen) return
        if (arrowsShown) {
            ui.removeCallbacks(hideArrowsRun)
            hideArrows()
        }
        resetPage()
        arrange()
        try {
            wm.addView(full, fullParams)
        } catch (e: Exception) {
            return
        }
        panelOpen = true
        root.visibility = View.INVISIBLE   // الأيقونة تختفي طول ما اللوحة مفتوحة (INVISIBLE مو GONE عشان النافذة ما تصير بحجم صفر)
        startProbe()
    }

    private fun closePanel() {
        if (!panelOpen) return
        panelOpen = false
        stopProbe()
        try { wm.removeView(full) } catch (e: Exception) {}
        root.visibility = View.VISIBLE
        fitOnScreen()
    }

    private fun detach(v: View) {
        (v.parent as? ViewGroup)?.removeView(v)
    }

    /**
     * يرتّب محتوى اللوحة حسب اتجاه الشاشة:
     *  - أفقي: عمودين (اللعبة + مصدر الوقت | السرعة) وشريط سفلي واحد فيه التشغيل والإغلاق.
     *  - عمودي: عمود واحد (اللعبة، السرعة، مصدر الوقت) والأزرار تحت.
     */
    private fun arrange() {
        if (!::body.isInitialized) return
        val sz = screenSize()
        val land = sz[0] > sz[1]

        detach(toggle); detach(status); detach(closeIcon); detach(quit)
        body.removeAllViews()
        colA.removeAllViews()
        colB.removeAllViews()
        bottomBar.removeAllViews()
        footerRow.removeAllViews()

        if (land) {
            body.orientation = LinearLayout.HORIZONTAL
            colA.addView(grpApp, LinearLayout.LayoutParams(MATCH, WRAP))
            colA.addView(grpSrc, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
            colB.addView(grpSpeed, LinearLayout.LayoutParams(MATCH, WRAP))
            body.addView(colA, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(8) })
            body.addView(colB, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(8) })

            footerRow.addView(toggle, LinearLayout.LayoutParams(0, WRAP, 2f).apply { marginEnd = dp(4) })
            footerRow.addView(closeIcon, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                marginStart = dp(4); marginEnd = dp(4)
            })
            footerRow.addView(quit, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(4) })
            bottomBar.addView(status, LinearLayout.LayoutParams(MATCH, WRAP))
            bottomBar.addView(footerRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        } else {
            body.orientation = LinearLayout.VERTICAL
            body.addView(grpApp, LinearLayout.LayoutParams(MATCH, WRAP))
            body.addView(grpSpeed, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
            body.addView(grpSrc, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

            bottomBar.addView(toggle, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
            bottomBar.addView(status, LinearLayout.LayoutParams(MATCH, WRAP))
            footerRow.addView(closeIcon, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(4) })
            footerRow.addView(quit, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(4) })
            bottomBar.addView(footerRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        }
    }

    // ---------------------------------------------------------------- جاهزية الحقن (المربعات الخضراء)

    private fun startProbe() {
        if (!panelOpen) return
        if (Engine.pkg == null) {
            readyHint.text = "اختر اللعبة أولًا"
            return
        }
        val g = ++probeGen
        probeStep(g)
    }

    private fun stopProbe() {
        probeGen++          // أي فحص جاري أو مجدول بالرقم القديم يتجاهل نفسه
    }

    private fun probeStep(g: Int) {
        val pk = Engine.pkg
        if (g != probeGen || !panelOpen || pk == null) return
        Engine.probe(applicationContext, pk) { r ->
            if (g == probeGen && panelOpen) {
                onProbe(r)
                ui.postDelayed({ probeStep(g) }, PROBE_MS)
            }
        }
    }

    private fun onProbe(r: Engine.Readiness?) {
        if (r == null) {
            readyHint.text = "تعذّر فحص اللعبة (تأكد من الروت)"
            readyHint.setTextColor(Theme.ORANGE)
            return
        }
        injectedNow = r.injected
        seenLive = r.injected && r.seenOk
        srcSeen = if (seenLive) r.seen else IntArray(Engine.ROWS * 4)

        readyHint.text = when {
            !r.alive -> "اللعبة مو شغّالة، افتحها أولًا"
            !r.injected -> "اضغط ابدأ لكشف المصادر النشطة داخل اللعبة"
            !seenLive -> "الحاقن شغّال، جاري كشف المصادر..."
            else -> "الأخضر = مصدر نشط (اللعبة تقرأ الوقت منه)"
        }
        readyHint.setTextColor(if (seenLive) Theme.GREEN else Theme.MUTED)
        styleSrc()
    }

    private fun fmtRate(n: Int): String = if (n >= 1000) String.format(Locale.US, "%.1fk/ث", n / 1000.0) else "$n/ث"
    private fun fmtShort(n: Int): String = if (n >= 1000) String.format(Locale.US, "%.1fk", n / 1000.0) else "$n"

    /** مربعات الأعمدة (ملخص الجدول): إطار أخضر = اللعبة تقرأ الوقت من هذا المصدر فعلاً، عادي = فاضي. التعبئة = فيه صفوف معلّمة. */
    private fun styleSrc() {
        val r = dp(14).toFloat()
        for (i in 0 until tiles.size) {
            val t = tiles[i]
            val bit = 1 shl i
            val sel = Engine.matrix.any { (it and bit) != 0 }
            var clockRate = 0
            var anyRate = 0
            for (row in 0 until Engine.ROWS) {
                val n = srcSeen[row * 4 + i]
                anyRate += n
                if (row <= 3) clockRate += n
            }
            val active = seenLive && anyRate > 0
            val bg = when {
                sel && active -> Theme.GREEN
                sel -> Theme.PURPLE
                else -> Theme.GLASS2
            }
            val stroke = if (active) Theme.GREEN else 0x33FFFFFF
            t.box.background = withRipple(rounded(bg, r, dp(2), stroke), r)
            val fg = when {
                sel && active -> Theme.DARK
                sel -> Color.WHITE
                active -> Theme.GREEN
                else -> Theme.MUTED
            }
            t.title.setTextColor(fg)
            t.sub.setTextColor(fg)
            t.sub.text = when {
                active -> fmtRate(if (clockRate > 0) clockRate else anyRate)
                seenLive -> "فاضي"
                else -> "—"
            }
        }
        styleMatrix()
    }

    // ---------------------------------------------------------------- عناصر الواجهة

    private fun tv(text: String, size: Float = 13f, color: Int = Theme.TEXT, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun pill(
        text: String, bg: Int, fg: Int = Color.WHITE, size: Float = 13f,
        strokeColor: Int = 0, radiusDp: Int = 12
    ): TextView {
        val r = dp(radiusDp).toFloat()
        return tv(text, size, fg, true).apply {
            gravity = Gravity.CENTER
            isClickable = true
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = withRipple(rounded(bg, r, if (strokeColor != 0) dp(1) else 0, strokeColor), r)
        }
    }

    private fun stepBtn(sym: String, dir: Int): TextView {
        val b = pill(sym, Theme.GLASS2, Theme.TEXT, 22f, 0x4400E5FF, 24)
        attachRepeat(b, dir, false)
        return b
    }

    private fun appRow(a: Engine.App, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(7), dp(10), dp(7))
            isClickable = true
            background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null, ColorDrawable(Color.WHITE))
            setOnClickListener { onClick() }
        }
        val img = ImageView(this).apply { if (a.icon != null) setImageDrawable(a.icon) }
        row.addView(img, LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(10) })
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(tv(a.label, 13f, Theme.TEXT, true).apply { maxLines = 1 })
        texts.addView(tv(a.pkg, 10f, Theme.MUTED).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
        })
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (a.running) row.addView(tv("● شغّال", 10f, Theme.GREEN, true))
        return row
    }

    private fun buildPanel() {
        // ---- النافذة الكاملة: تعتيم شفاف + بطاقة شبه شفافة تملا الشاشة. الضغط خارج البطاقة يغلق اللوحة.
        full = FrameLayout(this).apply {
            setBackgroundColor(Theme.SCRIM)
            setOnClickListener { closePanel() }
        }
        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            isClickable = true                     // الضغط داخل البطاقة ما يغلق اللوحة
            setPadding(dp(14), dp(8), dp(14), dp(12))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Theme.GLASS_TOP, Theme.GLASS_BOTTOM)
            ).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), 0x4400E5FF)
            }
        }
        full.addView(card, FrameLayout.LayoutParams(MATCH, MATCH).apply {
            setMargins(dp(10), dp(10), dp(10), dp(10))
        })

        // ---- العنوان
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(tv("⚡ Speed Tool", 16f, Theme.TEXT, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(tv("✕", 20f, Theme.MUTED, true).apply {
            setPadding(dp(16), dp(6), dp(8), dp(6))
            setOnClickListener { closePanel() }
        })
        card.addView(header)

        // ---- منطقة المحتوى (تتمرر) + الشريط السفلي الثابت
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        colA = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        colB = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        footerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(body, LinearLayout.LayoutParams(MATCH, WRAP))
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        }
        card.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = dp(4) })
        bottomBar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(bottomBar, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- اختيار التطبيق
        val appIcon = ImageView(this).apply { visibility = View.GONE }
        val appName = tv("اختر اللعبة", 14f, Theme.TEXT, true).apply { maxLines = 1 }
        val appPkg = tv("اضغط لعرض التطبيقات الشغالة", 10f, Theme.MUTED).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
        }
        val appTexts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(appName)
            addView(appPkg)
        }
        val appCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = withRipple(rounded(Theme.GLASS2, dp(14).toFloat(), dp(1), 0x2200E5FF), dp(14).toFloat())
            addView(appIcon, LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(10) })
            addView(appTexts, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(tv("▾", 16f, Theme.CYAN, true))
        }
        grpApp = appCard

        // ---- قائمة التطبيقات (صفحة منفصلة تحل محل المحتوى)
        val listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Theme.GLASS, dp(12).toFloat())
        }
        val pickerTitle = tv("اختر اللعبة", 14f, Theme.TEXT, true)
        val backBtn = pill("رجوع", Theme.GLASS2, Theme.TEXT, 12f, 0, 10)
        val pickerHead = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(pickerTitle, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(backBtn, LinearLayout.LayoutParams(WRAP, WRAP))
        }
        val pickerBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(pickerHead, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
            addView(listBox, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        }
        content.addView(pickerBox, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- السرعة: عرض كبير + - + ، شريط، قيم جاهزة
        speedLabel = tv(fmtSpeed(Engine.speed), 34f, Theme.CYAN, true).apply { gravity = Gravity.CENTER }
        val speedRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(stepBtn("−", -1), LinearLayout.LayoutParams(dp(48), dp(48)))
            addView(speedLabel, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(stepBtn("+", +1), LinearLayout.LayoutParams(dp(48), dp(48)))
        }

        bar = SeekBar(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            max = BAR_MAX
            progress = progressOf(Engine.speed)
            progressTintList = ColorStateList.valueOf(Theme.CYAN)
            thumbTintList = ColorStateList.valueOf(Theme.CYAN)
            progressBackgroundTintList = ColorStateList.valueOf(0x33FFFFFF)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, pr: Int, u: Boolean) {
                    if (u) applySpeed(speedOf(pr), true)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        val presets = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        listOf(0.5, 1.0, 2.0, 5.0, 10.0).forEach { v ->
            val chip = pill(fmtSpeed(v), Theme.GLASS, Theme.TEXT, 12f, 0x2200E5FF, 10)
            chip.setPadding(dp(2), dp(7), dp(2), dp(7))
            chip.setOnClickListener { applySpeed(v) }
            presets.addView(chip, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                marginStart = dp(3); marginEnd = dp(3)
            })
        }

        val speedGroup = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        speedGroup.addView(speedRow, LinearLayout.LayoutParams(MATCH, WRAP))
        speedGroup.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        speedGroup.addView(presets, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        grpSpeed = speedGroup

        // ---- مصدر استدعاء الوقت: مربعات App / Java / System / Other (الأخضر = مصدر نشط فعلاً داخل اللعبة)
        readyHint = tv("اختر اللعبة أولًا", 11f, Theme.MUTED).apply {
            maxLines = 2
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        val srcCaption = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(tv("مصدر الوقت", 12f, Theme.TEXT, true))
            addView(readyHint, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(8) })
        }
        val tileRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_HORIZONTAL
        }
        srcLabels.forEach { label ->
            val title = tv(label, 13f, Theme.MUTED, true).apply { gravity = Gravity.CENTER }
            val sub = tv("—", 9f, Theme.MUTED).apply { gravity = Gravity.CENTER }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                addView(title)
                addView(sub)
            }
            tiles.add(SrcTile(box, title, sub))
            tileRow.addView(box, LinearLayout.LayoutParams(dp(62), dp(62)).apply {
                marginStart = dp(4); marginEnd = dp(4)
            })
        }

        // ---- الوضع (تلقائي / ساعة النظام)
        val modeAuto = pill("تلقائي · Unity", 0, Theme.MUTED, 12f, 0, 10)
        val modeLibc = pill("ساعة النظام", 0, Theme.MUTED, 12f, 0, 10)
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            background = rounded(Theme.GLASS, dp(13).toFloat())
            addView(modeAuto, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(modeLibc, LinearLayout.LayoutParams(0, WRAP, 1f))
        }

        val openMatrix = pill("جدول الدوال والمصادر  ▸", Theme.GLASS2, Theme.CYAN, 12f, 0x3300E5FF, 10)
        val srcGroup = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        srcGroup.addView(srcCaption, LinearLayout.LayoutParams(MATCH, WRAP))
        srcGroup.addView(tileRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        srcGroup.addView(openMatrix, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        srcGroup.addView(modeRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        grpSrc = srcGroup

        fun styleModes() {
            val r = dp(10).toFloat()
            val libc = Engine.mode == "libc"
            modeAuto.background = withRipple(rounded(if (!libc) Theme.PURPLE else 0, r), r)
            modeAuto.setTextColor(if (!libc) Color.WHITE else Theme.MUTED)
            modeLibc.background = withRipple(rounded(if (libc) Theme.PURPLE else 0, r), r)
            modeLibc.setTextColor(if (libc) Color.WHITE else Theme.MUTED)
        }

        fun showApp(pkg: String?, labelOverride: String? = null, icon: Drawable? = null) {
            if (pkg == null) {
                appName.text = "اختر اللعبة"
                appPkg.text = "اضغط لعرض التطبيقات الشغالة"
                appIcon.visibility = View.GONE
                return
            }
            val pm = packageManager
            val lbl = labelOverride ?: try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) { pkg }
            val ic = icon ?: try { pm.getApplicationIcon(pkg) } catch (e: Exception) { null }
            appName.text = lbl
            appPkg.text = pkg
            if (ic != null) {
                appIcon.setImageDrawable(ic)
                appIcon.visibility = View.VISIBLE
            } else {
                appIcon.visibility = View.GONE
            }
        }

        // ---- زر التشغيل + الحالة + أزرار الإغلاق (ترتيبها يحدده arrange حسب الاتجاه)
        toggle = pill("ابدأ التسريع", Theme.GREEN, Theme.DARK, 15f, 0, 14)
        toggle.setPadding(dp(8), dp(11), dp(8), dp(11))

        fun refresh() {
            val on = Engine.running
            val r = dp(14).toFloat()
            toggle.text = if (on) "إيقاف التسريع" else "ابدأ التسريع"
            toggle.background = withRipple(rounded(if (on) Theme.RED else Theme.GREEN, r), r)
            toggle.setTextColor(if (on) Color.WHITE else Theme.DARK)
            bubble.active = on
            bubble.invalidate()
        }
        refreshAll = { refresh() }

        status = tv("", 11f, Theme.MUTED).apply {
            setPadding(dp(2), dp(8), dp(2), 0)
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
        }

        closeIcon = pill("إغلاق الأيقونة", Theme.GLASS2, Theme.MUTED, 12f, 0x33FFFFFF, 12)
        quit = pill("⏻  إيقاف التطبيق", 0x33FF5252, Theme.RED, 12f, 0x88FF5252.toInt(), 12)

        // ---- السلوك
        fun showPicker(on: Boolean) {
            pickerBox.visibility = if (on) View.VISIBLE else View.GONE
            body.visibility = if (on) View.GONE else View.VISIBLE
            bottomBar.visibility = if (on) View.GONE else View.VISIBLE
            scroll.scrollTo(0, 0)
        }
        resetPage = { showPicker(false) }
        backBtn.setOnClickListener { showPicker(false) }

        fun choose(a: Engine.App) {
            showPicker(false)
            if (Engine.isBlocked(a.pkg)) {
                status.text = "هذا تطبيق أونلاين وفيه حظر للحسابات، الأداة ترفض تشتغل عليه."
                return
            }
            if (Engine.running) Engine.stop()
            Engine.pkg = a.pkg
            Engine.mode = Engine.modeFor(applicationContext, a.pkg)
            Engine.matrix = Engine.matrixFor(applicationContext, a.pkg)
            styleModes()
            showApp(a.pkg, a.label, a.icon)
            status.text = "تم اختيار: " + a.pkg
            refresh()
            // نبدأ كشف مصادر اللعبة الجديدة من الصفر
            srcSeen = IntArray(Engine.ROWS * 4)
            seenLive = false
            injectedNow = false
            styleSrc()
            readyHint.text = "جاري فحص اللعبة..."
            readyHint.setTextColor(Theme.MUTED)
            stopProbe()
            startProbe()
        }

        fun setMode(m: String) {
            val pk = Engine.pkg
            if (Engine.running) {
                status.text = "أوقف التسريع أول، ثم غيّر الوضع"
                return
            }
            Engine.alive { live ->
                if (live) {
                    status.text = "الحاقن لسا شغّال داخل اللعبة. لتغيير الوضع اقفل اللعبة وافتحها من جديد (تغييره الحين يكرّشها)"
                } else {
                    Engine.mode = m
                    if (pk != null) Engine.saveMode(applicationContext, pk, m)
                    styleModes()
                    status.text = "الوضع يتطبق عند الضغط على ابدأ التسريع"
                }
            }
        }
        modeAuto.setOnClickListener { setMode("auto") }
        modeLibc.setOnClickListener { setMode("libc") }

        // ---- جدول الدوال (مثل جيم جاردن): صف لكل دالة وقت × عمود لكل مصدر. الضغط على العنوان أو رقم الصف يعلّم الكل.
        fun commitMatrix(msg: String? = null) {
            val pk = Engine.pkg
            if (pk != null) Engine.saveMatrix(applicationContext, pk, Engine.matrix)
            styleSrc()
            // الحاقن يقرأ الجدول كل نص ثانية، وكل مصدر يحتفظ بساعته فالتبديل المباشر ما يقفّز الوقت
            Engine.updateCats()
            status.text = msg ?: if (injectedNow) "تم التغيير مباشرة" else "يتطبق عند الضغط على ابدأ التسريع"
        }
        fun toggleCell(row: Int, col: Int) {
            val m = Engine.matrix.copyOf()
            m[row] = m[row] xor (1 shl col)
            Engine.matrix = m
            commitMatrix()
        }
        fun toggleRow(row: Int) {
            val m = Engine.matrix.copyOf()
            m[row] = if (m[row] == 15) 0 else 15
            Engine.matrix = m
            commitMatrix()
        }
        fun toggleColumn(col: Int) {
            val bit = 1 shl col
            val all = Engine.matrix.all { (it and bit) != 0 }
            Engine.matrix = IntArray(Engine.ROWS) { if (all) Engine.matrix[it] and bit.inv() else Engine.matrix[it] or bit }
            commitMatrix()
        }
        fun toggleAll() {
            val all = Engine.matrix.all { it == 15 }
            Engine.matrix = IntArray(Engine.ROWS) { if (all) 0 else 15 }
            commitMatrix()
        }
        fun resetMatrix() {
            Engine.matrix = Engine.defaultMatrix()
            commitMatrix("رجع الافتراضي: App + Java")
        }

        val cellViews = Array(Engine.ROWS) { arrayOfNulls<TextView>(4) }
        val rowLabels = arrayOfNulls<TextView>(Engine.ROWS)
        fun hdr(text: String, onClick: () -> Unit): TextView =
            tv(text, 12f, Theme.TEXT, true).apply {
                gravity = Gravity.CENTER
                paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
                setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { onClick() }
            }
        val matrixHead = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            addView(hdr("#") { toggleAll() }, LinearLayout.LayoutParams(0, WRAP, 2.3f))
            srcLabels.forEachIndexed { i, l ->
                addView(hdr(l) { toggleColumn(i) }, LinearLayout.LayoutParams(0, WRAP, 1f))
            }
        }
        val matrixRows = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Theme.GLASS, dp(12).toFloat())
            setPadding(dp(6), dp(4), dp(6), dp(6))
        }
        matrixRows.addView(matrixHead, LinearLayout.LayoutParams(MATCH, WRAP))
        for (row in 0 until Engine.ROWS) {
            val label = tv("${row + 1}  " + Engine.ROW_NAMES[row], 10f, Theme.TEXT).apply {
                gravity = Gravity.CENTER_VERTICAL or Gravity.START
                paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
                maxLines = 2
                setOnClickListener { toggleRow(row) }
            }
            rowLabels[row] = label
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                gravity = Gravity.CENTER_VERTICAL
                addView(label, LinearLayout.LayoutParams(0, WRAP, 2.3f).apply { marginEnd = dp(4) })
            }
            for (col in 0 until 4) {
                val cell = tv("", 10f, Theme.MUTED, true).apply {
                    gravity = Gravity.CENTER
                    isClickable = true
                    setOnClickListener { toggleCell(row, col) }
                }
                cellViews[row][col] = cell
                line.addView(cell, LinearLayout.LayoutParams(0, dp(34), 1f).apply {
                    marginStart = dp(3); marginEnd = dp(3)
                })
            }
            matrixRows.addView(line, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(5) })
        }
        val matrixTitle = tv("جدول الدوال والمصادر", 14f, Theme.TEXT, true)
        val matrixReset = pill("إعادة تعيين", Theme.GLASS2, Theme.TEXT, 12f, 0, 10)
        val matrixBack = pill("رجوع", Theme.GLASS2, Theme.TEXT, 12f, 0, 10)
        val matrixBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(matrixTitle, LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(matrixReset, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(6) })
                addView(matrixBack, LinearLayout.LayoutParams(WRAP, WRAP))
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
            addView(
                tv("الإطار الأخضر = اللعبة تستدعي هذي الدالة من هذا المصدر (الرقم = مرة بالثانية). ✓ = معلّمة للتسريع. اضغط العنوان أو رقم الصف لتعليم الكل.", 10f, Theme.MUTED),
                LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) }
            )
            addView(matrixRows, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        }
        content.addView(matrixBox, LinearLayout.LayoutParams(MATCH, WRAP))
        styleMatrix = {
            val rr = dp(8).toFloat()
            for (row in 0 until Engine.ROWS) {
                for (col in 0 until 4) {
                    val t = cellViews[row][col] ?: continue
                    val on = (Engine.matrix[row] and (1 shl col)) != 0
                    val n = srcSeen[row * 4 + col]
                    val active = seenLive && n > 0
                    val bg = when {
                        on && active -> Theme.GREEN
                        on -> Theme.PURPLE
                        else -> Theme.GLASS2
                    }
                    t.background = rounded(bg, rr, dp(2), if (active) Theme.GREEN else 0x33FFFFFF)
                    t.setTextColor(when {
                        on && active -> Theme.DARK
                        on -> Color.WHITE
                        active -> Theme.GREEN
                        else -> Theme.MUTED
                    })
                    t.text = if (active) fmtShort(n) else if (on) "✓" else ""
                }
            }
        }
        fun showMatrix(on: Boolean) {
            matrixBox.visibility = if (on) View.VISIBLE else View.GONE
            body.visibility = if (on) View.GONE else View.VISIBLE
            bottomBar.visibility = if (on) View.GONE else View.VISIBLE
            scroll.scrollTo(0, 0)
            if (on) styleSrc()
        }
        resetPage = { showPicker(false); showMatrix(false) }
        matrixBack.setOnClickListener { showMatrix(false) }
        matrixReset.setOnClickListener { resetMatrix() }
        openMatrix.setOnClickListener { showMatrix(true) }
        for (i in 0 until tiles.size) tiles[i].box.setOnClickListener { toggleColumn(i) }

        appCard.setOnClickListener {
            status.text = "جاري تحميل القائمة..."
            Engine.listApps(applicationContext) { apps ->
                listBox.removeAllViews()
                if (apps.isEmpty()) {
                    status.text = "ما لقيت تطبيقات (تأكد من الروت)"
                } else {
                    apps.forEach { a -> listBox.addView(appRow(a) { choose(a) }) }
                    val n = apps.count { it.running }
                    pickerTitle.text = "اختر اللعبة · $n شغّال من ${apps.size}"
                    status.text = ""
                    showPicker(true)
                }
            }
        }

        toggle.setOnClickListener {
            if (Engine.running) {
                Engine.stop { status.text = "تم الإيقاف"; refresh() }
                refresh()
                return@setOnClickListener
            }
            status.text = "جاري التشغيل..."
            Engine.start(applicationContext) { msg -> status.text = msg; refresh() }
            refresh()
        }
        closeIcon.setOnClickListener { stopSelf() }
        quit.setOnClickListener { Engine.quitAll(applicationContext) }

        // حالة البداية
        val pk0 = Engine.pkg
        if (pk0 != null) { Engine.mode = Engine.modeFor(applicationContext, pk0); Engine.matrix = Engine.matrixFor(applicationContext, pk0) }
        styleModes()
        styleSrc()
        showApp(pk0)
        refresh()

        // لو اللعبة أُغلقت يموت الحاقن؛ نكتشفه ونرجّع الواجهة وSELinux بدل ما نقول "شغّال" وهو ميّت
        val w = object : Runnable {
            override fun run() {
                if (Engine.running && System.currentTimeMillis() - Engine.startedAt > 8000) {
                    Engine.alive { ok ->
                        if (!ok && Engine.running) {
                            Engine.stop()
                            status.text = "الحاقن توقف (اللعبة أُغلقت؟). افتحها واضغط ابدأ من جديد."
                            refresh()
                        }
                    }
                }
                ui.postDelayed(this, 10000)
            }
        }
        watchdog = w
        ui.postDelayed(w, 10000)
    }

    override fun onDestroy() {
        watchdog?.let { ui.removeCallbacks(it) }
        ui.removeCallbacksAndMessages(null)
        probeGen++
        if (Engine.running) Engine.stop()          // يرجّع السرعة وSELinux
        Engine.closeRootShell()
        try { if (panelOpen) wm.removeView(full) } catch (e: Exception) {}
        panelOpen = false
        try { wm.removeView(root) } catch (e: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "speedtool_overlay"
        const val ACTION_QUIT = "com.example.speedtool.QUIT"
        private const val MIN_SPEED = 0.01
        private const val MAX_SPEED = 100.0
        private const val BAR_MAX = 1000
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

        private const val PROBE_MS = 1500L      // كل كم نفحص اللعبة (ونقرأ المصادر النشطة)
    }
}
