package com.example.speedtool

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var log: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.TOP
        }
        val floatBtn = Button(this).apply { text = "تشغيل الأيقونة العائمة"; setOnClickListener { openFloating() } }
        val logBtn = Button(this).apply { text = "عرض السجل"; setOnClickListener { Engine.readLog { log.text = it } } }
        log = TextView(this).apply { textSize = 12f }
        val tip = TextView(this).apply {
            textSize = 12f
            text = "1) ضع frida-inject (arm64) في /data/local/tmp\n" +
                   "2) اضغط تشغيل الأيقونة العائمة\n" +
                   "3) افتح اللعبة، اضغط ⚡ ثم اختر التطبيق من القائمة، وبعدها ابدأ التسريع."
        }
        listOf(floatBtn, logBtn, tip, log).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
        // إذن الإشعارات (أندرويد 13+): الخدمة الأمامية تشتغل بدونه لكن الإشعار ما يظهر
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun openFloating() {
        if (Settings.canDrawOverlays(this)) { launchFloating(); return }
        Engine.su("appops set $packageName SYSTEM_ALERT_WINDOW allow") { _ ->
            if (Settings.canDrawOverlays(this)) {
                launchFloating()
            } else {
                log.text = "فعّل إذن «الظهور فوق التطبيقات» ثم ارجع واضغط الزر مرة ثانية"
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
    }

    private fun launchFloating() {
        stopService(Intent(this, FloatingService::class.java))
        val svc = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
        log.text = "تم. افتح اللعبة واضغط ⚡ ثم اختر التطبيق"
        moveTaskToBack(true)
    }
}
