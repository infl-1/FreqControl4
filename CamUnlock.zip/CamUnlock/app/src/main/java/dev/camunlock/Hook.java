package dev.camunlock;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Forces selected SUPPORT_* feature flags to true inside Samsung Camera.
 *
 * Class names below are obfuscated and match ONE specific camera build
 * (the APK analysed, looks like 17.0.00.43). If the camera updates, they change
 * and this module logs "class not found" instead of crashing the camera.
 */
public class Hook implements IXposedHookLoadPackage {

    private static final String TAG = "CamUnlock: ";
    private static final String PKG = "com.sec.android.app.camera";

    // Obfuscated names in this build:
    private static final String FEATURE_ENUM = "e5.d";   // enum of all feature keys
    private static final String FEATURE_GETTER = "e5.g"; // static boolean o(e5.d)
    private static final String FEATURE_HELPER = "e5.f"; // static boolean s1(e5.d, boolean)

    // Group 1: app-level features. Delete a line to leave that one alone.
    private static final Set<String> FORCE_ON = new HashSet<>(Arrays.asList(
            "SUPPORT_SHUTTER_SOUND_MENU",
            "SUPPORT_PRO_WHITE_BALANCE_TINT",
            "SUPPORT_PRO_RAW_ONLY_PICTURE_FORMAT",
            "SUPPORT_JPEGR_PICTURE_FORMAT",
            "SUPPORT_AUTO_HDR_MENU",
            "SUPPORT_FRAME_WATERMARK",
            "SUPPORT_VIDEO_MODE_ZOOM_ROCKER",
            "SUPPORT_CAMERA_ASSISTANT_AUTO_EXPOSURE_LIMIT",
            "SUPPORT_CAMERA_ASSISTANT_FOCUS_SPEED_SETTINGS",
            "SUPPORT_CAMERA_ASSISTANT_CAMERA_TIMEOUT",
            "SUPPORT_CAMERA_ASSISTANT_WIDE_FLASH_MENU",
            "SUPPORT_CAMERA_ASSISTANT_AUTO_ZOOM_STYLE"
    ));

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if (!PKG.equals(lp.packageName)) return;
        try {
            final Class<?> featureEnum = XposedHelpers.findClass(FEATURE_ENUM, lp.classLoader);

            XC_MethodHook hook = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    Object f = param.args[0];
                    if (f instanceof Enum && FORCE_ON.contains(((Enum<?>) f).name())) {
                        param.setResult(Boolean.TRUE);
                    }
                }
            };

            XposedHelpers.findAndHookMethod(FEATURE_GETTER, lp.classLoader, "o", featureEnum, hook);
            XposedHelpers.findAndHookMethod(FEATURE_HELPER, lp.classLoader, "s1", featureEnum, boolean.class, hook);
            XposedBridge.log(TAG + "hooked OK, forcing " + FORCE_ON.size() + " flags");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook failed (camera version mismatch?): " + t);
        }
    }
}
