package com.example.tiksaver

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow

/** يراقب توفر الإنترنت الفعلي (متصل + مُتحقَّق منه). */
class NetworkMonitor(context: Context) {

    private val cm = context.getSystemService(ConnectivityManager::class.java)

    val online = MutableStateFlow(computeOnline())

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            online.value = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        }

        override fun onLost(network: Network) {
            // عند التحويل واي فاي ↔ بيانات، onLost للقديمة قد يجي بعد توفر الجديدة،
            // فنسأل النظام عن الشبكة الافتراضية الحالية بدل ما نفترض الانقطاع.
            online.value = computeOnline()
        }
    }

    fun start() {
        online.value = computeOnline()
        cm.registerDefaultNetworkCallback(callback)
    }

    fun stop() {
        try { cm.unregisterNetworkCallback(callback) } catch (_: Exception) {}
    }

    private fun computeOnline(): Boolean {
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
}
