package com.example.tiksaver

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException

/** خدمة التحميل: تكمل التحميل بالخلفية مع إشعار فيه نسبة التقدم وزر إلغاء. */
class DownloadService : Service() {

    companion object {
        const val ACTION_START = "com.example.tiksaver.action.START"
        const val ACTION_CANCEL = "com.example.tiksaver.action.CANCEL"
        const val EXTRA_URL = "url"
        const val EXTRA_QUALITY = "quality"
        const val PROCESS_ID = "tiksaver-download"

        private const val CHANNEL_ID = "downloads"
        private const val ONGOING_ID = 1001
        private const val DONE_ID = 1002
        private val mediaExtensions = setOf(
            "mp4", "mkv", "webm", "mov",
            "mp3", "m4a", "opus", "ogg", "aac", "wav", "flac"
        )

        fun start(context: Context, url: String, quality: Quality) {
            val intent = Intent(context, DownloadService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_URL, url)
                .putExtra(EXTRA_QUALITY, quality.name)
            ContextCompat.startForegroundService(context, intent)
        }

        fun cancel(context: Context) {
            context.startService(
                Intent(context, DownloadService::class.java).setAction(ACTION_CANCEL)
            )
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    @Volatile
    private var cancelRequested = false
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            CHANNEL_ID, "التحميلات", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                // لازم نستدعي startForeground بسرعة بعد startForegroundService
                ServiceCompat.startForeground(
                    this,
                    ONGOING_ID,
                    buildOngoing("جاري التحميل...", 0),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
                if (job?.isActive == true) return START_NOT_STICKY

                val url = intent?.getStringExtra(EXTRA_URL)
                val quality = try {
                    Quality.valueOf(intent?.getStringExtra(EXTRA_QUALITY) ?: Quality.ORIGINAL.name)
                } catch (e: IllegalArgumentException) {
                    Quality.ORIGINAL
                }
                if (url == null) {
                    stopSelf()
                } else {
                    runDownload(url, quality)
                }
            }
            ACTION_CANCEL -> {
                cancelRequested = true
                try {
                    YoutubeDL.getInstance().destroyProcessById(PROCESS_ID)
                } catch (e: Exception) {
                    // ما فيه عملية شغالة
                }
                if (job?.isActive != true) stopSelf()
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun runDownload(url: String, quality: Quality) {
        cancelRequested = false
        DownloadState.update(DownloadState.State.RUNNING, 0, "جاري التحميل...")
        acquireWakeLock()

        job = scope.launch {
            var finalState = DownloadState.State.FAILED
            var finalMessage = "فشل التحميل"
            try {
                val file = downloadFile(url, quality)
                if (quality.audioOnly) {
                    MediaSaver.saveAudio(applicationContext, file)
                    finalMessage = "تم حفظ الصوت في المعرض (Music/TikSaver) ✅"
                } else {
                    MediaSaver.saveVideo(applicationContext, file)
                    finalMessage = "تم الحفظ في المعرض (Movies/TikSaver) ✅"
                }
                file.delete()
                finalState = DownloadState.State.DONE
            } catch (e: Exception) {
                if (cancelRequested) {
                    finalState = DownloadState.State.CANCELLED
                    finalMessage = "تم الإلغاء"
                } else {
                    val reason = e.message?.lineSequence()?.firstOrNull { it.isNotBlank() }?.take(160)
                        ?: e.javaClass.simpleName
                    finalMessage = "فشل التحميل. تأكد من الرابط، أو اضغط «تحديث المحرك» وحاول مرة ثانية.\n[تفاصيل] $reason"
                }
            } finally {
                releaseWakeLock()
            }
            finish(finalState, finalMessage)
        }
    }

    private fun downloadFile(url: String, quality: Quality): File {
        try {
            YoutubeDL.getInstance().init(applicationContext)
            FFmpeg.getInstance().init(applicationContext)
        } catch (e: Exception) {
            throw IOException("تعذر تجهيز المحرك: ${e.message}")
        }

        val dir = File(cacheDir, "dl").apply {
            deleteRecursively()
            mkdirs()
        }
        val request = YoutubeDLRequest(url)
        request.addOption("-o", "${dir.absolutePath}/%(id)s.%(ext)s")
        request.addOption("-f", quality.formatSelector())
        if (quality.audioOnly) {
            request.addOption("-x")
            request.addOption("--audio-format", "mp3")
            request.addOption("--audio-quality", "0")
        } else {
            request.addOption("--merge-output-format", "mp4")
        }
        request.addOption("--no-playlist")

        var lastPercent = -1
        YoutubeDL.getInstance().execute(request, PROCESS_ID) { p, _, _ ->
            val percent = p.toInt().coerceIn(0, 100)
            if (percent != lastPercent) {
                lastPercent = percent
                onProgress(percent)
            }
        }

        return dir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in mediaExtensions }
            ?.maxByOrNull { it.length() }
            ?: throw IOException("لم يتم العثور على الملف")
    }

    private fun onProgress(percent: Int) {
        val text = "جاري التحميل... $percent%"
        DownloadState.update(DownloadState.State.RUNNING, percent, text)
        getSystemService(NotificationManager::class.java)
            .notify(ONGOING_ID, buildOngoing(text, percent))
    }

    private fun finish(state: DownloadState.State, message: String) {
        DownloadState.update(
            state,
            if (state == DownloadState.State.DONE) 100 else DownloadState.progress,
            message
        )
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        if (state != DownloadState.State.CANCELLED) {
            val done = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("محمّل الفيديوهات")
                .setContentText(message.lineSequence().first())
                .setContentIntent(openAppIntent())
                .setAutoCancel(true)
                .build()
            getSystemService(NotificationManager::class.java).notify(DONE_ID, done)
        }
        stopSelf()
    }

    private fun buildOngoing(text: String, percent: Int): Notification {
        val cancelIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("محمّل الفيديوهات")
            .setContentText(text)
            .setContentIntent(openAppIntent())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, percent, percent == 0)
            .addAction(0, "إلغاء", cancelIntent)
            .build()
    }

    private fun openAppIntent(): PendingIntent {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tiksaver:download").apply {
                acquire(30 * 60 * 1000L)
            }
        } catch (e: Exception) {
            // مو ضروري
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
            // مو ضروري
        }
        wakeLock = null
    }

    override fun onDestroy() {
        if (job?.isActive == true) {
            try {
                YoutubeDL.getInstance().destroyProcessById(PROCESS_ID)
            } catch (e: Exception) {
                // ما فيه عملية شغالة
            }
        }
        scope.cancel()
        releaseWakeLock()
        super.onDestroy()
    }
}
