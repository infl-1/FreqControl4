package com.example.tiksaver

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume

class MainActivity : AppCompatActivity() {

    private class HttpResult(val body: ByteArray, val finalUrl: String)
    private class PhotoPost(val id: String, val imageUrls: List<String>)

    // ───────── الواجهة ─────────
    private lateinit var linkInput: EditText
    private lateinit var downloadBtn: Button
    private lateinit var pauseBtn: Button
    private lateinit var cancelBtn: Button
    private lateinit var updateBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var webContainer: FrameLayout
    private lateinit var pickerContainer: LinearLayout
    private lateinit var pickerInfo: TextView
    private lateinit var imageGrid: GridLayout
    private lateinit var selectAllBtn: Button
    private lateinit var clearAllBtn: Button
    private lateinit var saveSelectedBtn: Button
    private lateinit var pickerCancelBtn: Button

    // ───────── الحالة ─────────
    private var ready = false
    private var activeJob: Job? = null
    private var thumbJob: Job? = null
    private var webView: WebView? = null
    private var currentPost: PhotoPost? = null
    private var lastResolvedUrl: String? = null
    private var photoDebug: String = ""
    private val cookies = LinkedHashMap<String, String>()
    private val selected = LinkedHashSet<Int>()
    private val cellImages = ArrayList<ImageView>()
    private val cellMarks = ArrayList<TextView>()

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val stateListener: () -> Unit = { renderState() }

    private val USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val urlRegex = Regex("https?://\\S+")
    private val supportedDomains = listOf(
        "tiktok.com", "snapchat.com", "x.com", "twitter.com", "t.co", "youtube.com", "youtu.be"
    )
    private val pageDataJs =
        "(function(){var ids=['__UNIVERSAL_DATA_FOR_REHYDRATION__','SIGI_STATE','__NEXT_DATA__'];" +
            "for(var i=0;i<ids.length;i++){var e=document.getElementById(ids[i]);" +
            "if(e&&e.textContent){return e.textContent;}}return '';})()"

    // ───────────────────────── دورة الحياة ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        linkInput = findViewById(R.id.linkInput)
        downloadBtn = findViewById(R.id.downloadBtn)
        pauseBtn = findViewById(R.id.pauseBtn)
        cancelBtn = findViewById(R.id.cancelBtn)
        updateBtn = findViewById(R.id.updateBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        webContainer = findViewById(R.id.webContainer)
        pickerContainer = findViewById(R.id.pickerContainer)
        pickerInfo = findViewById(R.id.pickerInfo)
        imageGrid = findViewById(R.id.imageGrid)
        selectAllBtn = findViewById(R.id.selectAllBtn)
        clearAllBtn = findViewById(R.id.clearAllBtn)
        saveSelectedBtn = findViewById(R.id.saveSelectedBtn)
        pickerCancelBtn = findViewById(R.id.pickerCancelBtn)

        findViewById<Button>(R.id.pasteBtn).setOnClickListener { pasteFromClipboard() }
        downloadBtn.setOnClickListener { startDownload() }
        pauseBtn.setOnClickListener { togglePause() }
        cancelBtn.setOnClickListener { cancelCurrent() }
        updateBtn.setOnClickListener { updateEngine() }
        selectAllBtn.setOnClickListener {
            currentPost?.let { post ->
                selected.clear()
                selected.addAll(post.imageUrls.indices)
                refreshCells()
            }
        }
        clearAllBtn.setOnClickListener {
            selected.clear()
            refreshCells()
        }
        saveSelectedBtn.setOnClickListener { saveSelected() }
        pickerCancelBtn.setOnClickListener {
            hidePicker()
            status.text = "تم الإلغاء"
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        handleShareIntent(intent)
        initEngine()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        DownloadState.addListener(stateListener)
        renderState()
    }

    override fun onPause() {
        DownloadState.removeListener(stateListener)
        super.onPause()
    }

    override fun onDestroy() {
        destroyWebView()
        super.onDestroy()
    }

    // ───────────────────────── مساعدات الواجهة ─────────────────────────

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun busy(show: Boolean, determinate: Boolean = false) {
        progress.visibility = if (show) View.VISIBLE else View.GONE
        progress.isIndeterminate = !determinate
        progress.progress = 0
        downloadBtn.isEnabled = !show && ready
        updateBtn.isEnabled = !show
    }

    private fun setPauseButton(visible: Boolean, paused: Boolean = false) {
        pauseBtn.visibility = if (visible) View.VISIBLE else View.GONE
        pauseBtn.text = if (paused) "استئناف" else "إيقاف مؤقت"
    }

    private fun hideControls() {
        cancelBtn.visibility = View.GONE
        pauseBtn.visibility = View.GONE
    }

    private fun isDownloadActive(): Boolean = when (DownloadState.state) {
        DownloadState.State.RUNNING,
        DownloadState.State.PAUSED,
        DownloadState.State.WAITING_NETWORK -> true
        else -> false
    }

    private fun renderState() {
        when (DownloadState.state) {
            DownloadState.State.IDLE -> Unit
            DownloadState.State.RUNNING,
            DownloadState.State.PAUSED,
            DownloadState.State.WAITING_NETWORK -> {
                val st = DownloadState.state
                if (progress.visibility != View.VISIBLE) busy(true, true)
                progress.isIndeterminate = false
                progress.progress = DownloadState.progress
                status.text = DownloadState.message
                cancelBtn.visibility = View.VISIBLE
                setPauseButton(true, paused = st == DownloadState.State.PAUSED)
            }
            DownloadState.State.DONE,
            DownloadState.State.FAILED,
            DownloadState.State.CANCELLED -> {
                status.text = DownloadState.message
                busy(false)
                hideControls()
                DownloadState.reset()
            }
        }
    }

    // ───────────────────────── إجراءات الأزرار ─────────────────────────

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString()
        val url = extractUrl(text)
        if (url != null) linkInput.setText(url) else status.text = "ما لقيت رابط في الحافظة"
    }

    private fun togglePause() {
        when (DownloadState.state) {
            DownloadState.State.PAUSED -> DownloadService.resume(this)
            DownloadState.State.RUNNING,
            DownloadState.State.WAITING_NETWORK -> DownloadService.pause(this)
            else -> Unit
        }
    }

    private fun cancelCurrent() {
        if (isDownloadActive()) {
            DownloadService.cancel(this)
            status.text = "جاري الإلغاء..."
        } else {
            activeJob?.cancel()
        }
    }

    private fun handleShareIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            val url = extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT))
            if (url != null) linkInput.setText(url)
        }
    }

    // ───────────────────────── الروابط ─────────────────────────

    private fun extractUrl(text: String?): String? = text?.let { urlRegex.find(it)?.value }

    private fun hostOf(url: String): String? = Uri.parse(url).host?.lowercase()

    private fun isSupported(url: String): Boolean {
        val host = hostOf(url) ?: return false
        return supportedDomains.any { host == it || host.endsWith(".$it") }
    }

    private fun isTikTok(url: String): Boolean {
        val host = hostOf(url) ?: return false
        return host == "tiktok.com" || host.endsWith(".tiktok.com")
    }

    // ───────────────────────── المحرك ─────────────────────────

    private fun initEngine() {
        busy(true)
        status.text = "جاري تجهيز المحرك (أول مرة فقط، ممكن ياخذ شوي)..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().init(applicationContext)
                    FFmpeg.getInstance().init(applicationContext)
                }
                ready = true
                status.text = "جاهز ✅"
            } catch (e: Exception) {
                status.text = "تعذر تجهيز المحرك: ${e.message}"
            }
            busy(false)
        }
    }

    private fun updateEngine() {
        busy(true)
        status.text = "جاري تحديث المحرك..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().updateYoutubeDL(applicationContext, YoutubeDL.UpdateChannel.STABLE)
                }
                status.text = "تم تحديث المحرك ✅"
            } catch (e: Exception) {
                status.text = "فشل التحديث، تأكد من الإنترنت"
            }
            busy(false)
        }
    }

    // ───────────────────────── بدء التحميل ─────────────────────────

    private fun startDownload() {
        val url = extractUrl(linkInput.text.toString())
        if (url == null || !isSupported(url)) {
            status.text = "الرابط غير مدعوم. المدعوم: تيك توك، سناب شات، X، يوتيوب"
            return
        }
        if (isDownloadActive()) {
            status.text = "فيه تحميل شغال حالياً، انتظر أو اضغط إلغاء"
            return
        }
        linkInput.setText(url)
        hidePicker()

        if (!isTikTok(url)) {
            askQuality(url)
            return
        }

        // تيك توك: نفحص أولاً إذا البوست صور (Carousel) أو فيديو
        busy(true)
        cancelBtn.visibility = View.VISIBLE
        setPauseButton(false)
        status.text = "جاري فحص الرابط..."
        activeJob = lifecycleScope.launch {
            try {
                var found = withContext(Dispatchers.IO) { findPhotoPost(url) }
                val isPhoto = url.contains("/photo/") || lastResolvedUrl?.contains("/photo/") == true
                if (found == null && isPhoto) {
                    status.text = "جاري فتح البوست..."
                    found = findPhotoPostWebView(lastResolvedUrl ?: url)
                }
                when {
                    found != null -> showPicker(found)
                    isPhoto -> status.text = "تعذر تحميل صور البوست\n[صور] $photoDebug"
                    else -> askQuality(url)
                }
                busy(false)
                hideControls()
            } catch (e: kotlinx.coroutines.CancellationException) {
                status.text = "تم الإلغاء"
                busy(false)
                hideControls()
            } catch (e: Exception) {
                val detail = e.message?.lineSequence()?.firstOrNull { it.isNotBlank() }?.take(160)
                    ?: e.javaClass.simpleName
                status.text = "فشل التحميل. تأكد من الرابط، أو اضغط «تحديث المحرك» وحاول مرة ثانية.\n[تفاصيل] $detail"
                busy(false)
                hideControls()
            }
        }
    }

    private fun askQuality(url: String) {
        val qualities = Quality.values()
        val dialog = AlertDialog.Builder(this)
            .setTitle("اختر الجودة")
            .setItems(qualities.map { it.label }.toTypedArray()) { _, which ->
                beginVideoDownload(url, qualities[which])
            }
            .setNegativeButton("إلغاء", null)
            .show()
        dialog.window?.decorView?.layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun beginVideoDownload(url: String, quality: Quality) {
        DownloadState.update(DownloadState.State.RUNNING, 0, "جاري التحميل...")
        DownloadService.start(this, url, quality)
        renderState()
    }

    // ───────────────────────── منشورات الصور (تيك توك) ─────────────────────────

    private fun httpGet(startUrl: String, referer: String?): HttpResult {
        var current = startUrl
        repeat(10) {
            val conn = URL(current).openConnection() as HttpURLConnection
            try {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.setRequestProperty("User-Agent", USER_AGENT)
                conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                if (referer != null) conn.setRequestProperty("Referer", referer)
                if (cookies.isNotEmpty()) {
                    conn.setRequestProperty("Cookie", cookies.entries.joinToString("; ") { "${it.key}=${it.value}" })
                }
                val code = conn.responseCode
                for ((key, values) in conn.headerFields) {
                    if (key != null && key.equals("set-cookie", ignoreCase = true)) {
                        values.forEach { raw ->
                            val pair = raw.substringBefore(';')
                            val name = pair.substringBefore('=').trim()
                            if (name.isNotEmpty()) cookies[name] = pair.substringAfter('=', "")
                        }
                    }
                }
                if (code in 300..399) {
                    val location = conn.getHeaderField("Location") ?: throw IOException("redirect without location")
                    current = URL(URL(current), location).toString()
                    return@repeat
                }
                if (code in 200..299) {
                    val body = conn.inputStream.use { it.readBytes() }
                    return HttpResult(body, current)
                }
                throw IOException("HTTP $code")
            } finally {
                conn.disconnect()
            }
        }
        throw IOException("too many redirects")
    }

    private fun extractPageData(html: String): JSONObject? {
        for (id in listOf("__UNIVERSAL_DATA_FOR_REHYDRATION__", "SIGI_STATE", "__NEXT_DATA__")) {
            val marker = html.indexOf("id=\"$id\"")
            if (marker < 0) continue
            val gt = html.indexOf('>', marker)
            val start = gt + 1
            val end = html.indexOf("</script>", start)
            if (start <= 0 || end < 0) continue
            try {
                return JSONObject(html.substring(start, end))
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun extractJsonObjectAfter(text: String, marker: String): JSONObject? {
        val idx = text.indexOf(marker)
        if (idx < 0) return null
        val start = text.indexOf('{', idx + marker.length)
        if (start < 0) return null
        var depth = 0
        var inString = false
        var escape = false
        var i = start
        while (i < text.length) {
            val c = text[i]
            if (inString) {
                if (escape) escape = false
                else if (c == '\\') escape = true
                else if (c == '"') inString = false
            } else {
                when (c) {
                    '"' -> inString = true
                    '{' -> depth++
                    '}' -> {
                        depth--
                        if (depth == 0) {
                            return try {
                                JSONObject(text.substring(start, i + 1))
                            } catch (_: Exception) {
                                null
                            }
                        }
                    }
                }
            }
            i++
        }
        return null
    }

    private fun findItemWithImages(node: Any?): JSONObject? {
        when (node) {
            is JSONObject -> {
                val images = node.optJSONObject("imagePost")?.optJSONArray("images")
                if (images != null && images.length() > 0) return node
                val keys = node.keys()
                while (keys.hasNext()) {
                    val found = findItemWithImages(node.opt(keys.next()))
                    if (found != null) return found
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    val found = findItemWithImages(node.opt(i))
                    if (found != null) return found
                }
            }
        }
        return null
    }

    private fun buildPhotoPost(item: JSONObject, fallbackId: String): PhotoPost? {
        val images = item.getJSONObject("imagePost").getJSONArray("images")
        val urls = ArrayList<String>()
        for (i in 0 until images.length()) {
            val image = images.optJSONObject(i) ?: continue
            val list = image.optJSONObject("imageURL")?.optJSONArray("urlList")
                ?: image.optJSONObject("displayImage")?.optJSONArray("urlList")
                ?: continue
            val candidates = (0 until list.length()).map { list.getString(it) }
            val best = candidates.firstOrNull { it.contains(".jpeg") || it.contains(".jpg") }
                ?: candidates.firstOrNull()
                ?: continue
            urls.add(best)
        }
        if (urls.isEmpty()) {
            photoDebug = "لقيت imagePost بدون روابط صور"
            return null
        }
        photoDebug = "ok"
        return PhotoPost(item.optString("id", fallbackId), urls)
    }

    private fun postFromText(text: String, id: String): PhotoPost? {
        val parsed = try { JSONObject(text) } catch (_: Exception) { null }
        var item = parsed?.let { findItemWithImages(it) }
        if (item == null) {
            val obj = extractJsonObjectAfter(text, "\"imagePost\":")
            if (obj != null && (obj.optJSONArray("images")?.length() ?: 0) > 0) {
                item = JSONObject().put("imagePost", obj)
            }
        }
        return item?.let { buildPhotoPost(it, id) }
    }

    /** المحاولة الأولى: طلب HTTP مباشر وقراءة بيانات الصفحة. */
    private fun findPhotoPost(url: String): PhotoPost? {
        lastResolvedUrl = null
        photoDebug = ""
        cookies.clear()
        return try {
            val res = httpGet(url, null)
            lastResolvedUrl = res.finalUrl
            val text = String(res.body, Charsets.UTF_8)
            val data = extractPageData(text)
            var item = data?.let { findItemWithImages(it) }
            if (item == null) {
                val obj = extractJsonObjectAfter(text, "\"imagePost\":")
                if (obj != null && (obj.optJSONArray("images")?.length() ?: 0) > 0) {
                    item = JSONObject().put("imagePost", obj)
                }
            }
            if (item == null) {
                photoDebug = if (data == null) {
                    if (text.contains("captcha", ignoreCase = true)) "تيك توك طلب كابتشا"
                    else "الصفحة بدون بيانات (حجمها ${text.length})"
                } else {
                    "ما فيه صور بالبوست (فيديو عادي؟)"
                }
                return null
            }
            val id = res.finalUrl.substringBefore('?').trimEnd('/').substringAfterLast('/')
            buildPhotoPost(item, id)
        } catch (e: Exception) {
            photoDebug = "تعذر فتح الصفحة: ${e.message}"
            null
        }
    }

    private suspend fun evalJs(web: WebView, js: String): String =
        suspendCancellableCoroutine { cont ->
            web.evaluateJavascript(js) { value ->
                val result = try {
                    if (value == null || value == "null") "" else (JSONTokener(value).nextValue() as? String) ?: ""
                } catch (_: Exception) {
                    ""
                }
                if (cont.isActive) cont.resume(result)
            }
        }

    /** المحاولة الثانية: WebView مرئي (يسمح بحل الكابتشا يدوياً). */
    private suspend fun findPhotoPostWebView(url: String): PhotoPost? {
        photoDebug = ""
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = USER_AGENT
        web.webViewClient = WebViewClient()
        web.setOnTouchListener { v, _ ->
            v.parent?.requestDisallowInterceptTouchEvent(true)
            false
        }
        webContainer.removeAllViews()
        webContainer.addView(
            web,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        webContainer.visibility = View.VISIBLE
        webView = web
        web.loadUrl(url)

        val id = url.substringBefore('?').trimEnd('/').substringAfterLast('/')
        try {
            var elapsed = 0L
            while (elapsed < 60000) {
                delay(1500)
                elapsed += 1500
                val text = evalJs(web, pageDataJs)
                if (text.isNotEmpty()) {
                    val post = withContext(Dispatchers.Default) { postFromText(text, id) }
                    if (post != null) return post
                }
                if (elapsed >= 6000) {
                    status.text = "إذا ظهر تحقق (كابتشا) في الصفحة تحت، حلّه وانتظر..."
                }
            }
            photoDebug = "انتهى الوقت بدون بيانات (تحقق/كابتشا؟)"
            return null
        } finally {
            destroyWebView()
        }
    }

    private fun destroyWebView() {
        webView?.let {
            webContainer.removeView(it)
            it.stopLoading()
            it.destroy()
        }
        webView = null
        webContainer.visibility = View.GONE
    }

    // ───────────────────────── معاينة واختيار الصور ─────────────────────────

    private fun createCell(index: Int, size: Int): FrameLayout {
        val cell = FrameLayout(this)
        val lp = GridLayout.LayoutParams()
        lp.width = size
        lp.height = size
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        cell.layoutParams = lp

        val image = ImageView(this)
        image.scaleType = ImageView.ScaleType.CENTER_CROP
        image.setBackgroundColor(0xFF444444.toInt())
        cell.addView(image, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val mark = TextView(this)
        mark.text = "✓"
        mark.setTextColor(0xFFFFFFFF.toInt())
        mark.textSize = 16f
        mark.setPadding(dp(6), dp(2), dp(6), dp(2))
        mark.setBackgroundColor(0xCC2E7D32.toInt())
        cell.addView(
            mark,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.TOP)
        )

        cell.setOnClickListener {
            if (!selected.add(index)) selected.remove(index)
            refreshCells()
        }
        cellImages.add(image)
        cellMarks.add(mark)
        return cell
    }

    private fun refreshCells() {
        cellImages.forEachIndexed { i, img -> img.alpha = if (selected.contains(i)) 1f else 0.4f }
        cellMarks.forEachIndexed { i, mark -> mark.visibility = if (selected.contains(i)) View.VISIBLE else View.GONE }
        pickerInfo.text = "المحدد: ${selected.size} من ${cellImages.size}"
        saveSelectedBtn.isEnabled = selected.isNotEmpty()
    }

    private fun setPickerEnabled(enabled: Boolean) {
        selectAllBtn.isEnabled = enabled
        clearAllBtn.isEnabled = enabled
        saveSelectedBtn.isEnabled = enabled && selected.isNotEmpty()
        pickerCancelBtn.isEnabled = enabled
    }

    private fun hidePicker() {
        thumbJob?.cancel()
        pickerContainer.visibility = View.GONE
        imageGrid.removeAllViews()
        cellImages.clear()
        cellMarks.clear()
        selected.clear()
        currentPost = null
    }

    private fun decodeThumb(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 600) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    private fun showPicker(post: PhotoPost) {
        currentPost = post
        selected.clear()
        selected.addAll(post.imageUrls.indices)
        imageGrid.removeAllViews()
        cellImages.clear()
        cellMarks.clear()

        val cellSize = (resources.displayMetrics.widthPixels - dp(48)) / 3 - dp(6)
        for (i in post.imageUrls.indices) imageGrid.addView(createCell(i, cellSize))
        pickerContainer.visibility = View.VISIBLE
        setPickerEnabled(true)
        refreshCells()
        status.text = "جاري تجهيز المعاينة (${post.imageUrls.size} صور)..."

        thumbJob = lifecycleScope.launch {
            post.imageUrls.forEachIndexed { i, imageUrl ->
                val bitmap = withContext(Dispatchers.IO) {
                    try {
                        decodeThumb(httpGet(imageUrl, "https://www.tiktok.com/").body)
                    } catch (_: Exception) {
                        null
                    }
                }
                if (bitmap != null && i < cellImages.size) cellImages[i].setImageBitmap(bitmap)
            }
            status.text = "اختر الصور اللي تبيها:"
        }
    }

    private fun imageExtension(url: String): String {
        val path = Uri.parse(url).path ?: return "jpg"
        val ext = path.substringAfterLast('.', "jpg").lowercase()
        return when {
            ext == "jpeg" -> "jpg"
            ext.length in 3..4 -> ext
            else -> "jpg"
        }
    }

    private fun imageMime(ext: String): String = when (ext) {
        "webp" -> "image/webp"
        "heic" -> "image/heic"
        "png" -> "image/png"
        else -> "image/jpeg"
    }

    private fun savePhoto(post: PhotoPost, index: Int) {
        val url = post.imageUrls[index]
        val result = httpGet(url, "https://www.tiktok.com/")
        val ext = imageExtension(url)
        val name = "tiktok_${post.id}_${"%02d".format(index + 1)}.$ext"
        MediaSaver.saveImage(applicationContext, result.body, name, imageMime(ext))
    }

    private fun saveSelected() {
        val post = currentPost ?: return
        if (selected.isEmpty()) {
            status.text = "ما حددت أي صورة"
            return
        }
        val indices = selected.sorted()
        thumbJob?.cancel()
        setPickerEnabled(false)
        busy(true, true)
        cancelBtn.visibility = View.VISIBLE
        setPauseButton(false)
        activeJob = lifecycleScope.launch {
            try {
                indices.forEachIndexed { n, index ->
                    status.text = "جاري حفظ ${n + 1} من ${indices.size} صور..."
                    withContext(Dispatchers.IO) { savePhoto(post, index) }
                    progress.progress = (n + 1) * 100 / indices.size
                }
                status.text = "تم حفظ ${indices.size} صور في المعرض (Pictures/TikSaver) ✅"
                busy(false)
                hideControls()
                hidePicker()
            } catch (e: kotlinx.coroutines.CancellationException) {
                status.text = "تم الإلغاء"
                busy(false)
                hideControls()
                setPickerEnabled(true)
            } catch (e: Exception) {
                val detail = e.message?.lineSequence()?.firstOrNull { it.isNotBlank() }?.take(160)
                    ?: e.javaClass.simpleName
                status.text = "تعذر تحميل صور البوست\n[تفاصيل] $detail"
                busy(false)
                hideControls()
                setPickerEnabled(true)
            }
        }
    }
}
