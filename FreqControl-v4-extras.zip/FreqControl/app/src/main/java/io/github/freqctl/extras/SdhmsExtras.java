package io.github.freqctl.extras;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import de.robv.android.xposed.XposedBridge;

/**
 * Runs INSIDE com.sec.android.sdhms (Xposed). Features:
 *  1) thermal switches (brightness limit / CP thermal mitigation / master) by calling SDHMS's own limiter,
 *     exactly like its hidden ThermalLimitSettingActivity does (learned from the One UI SDHMS dex);
 *  2) touch boost through the GOS TSP broadcast (learned from the Chinese module);
 *  3) safety: when the FreqControl thermal guard trips, thermal limits and touch boost are released.
 *
 * Source of truth is Settings.Global (see ExtraSettings), so the state survives reboots.
 */
public final class SdhmsExtras {
    public static final String ACTION = "io.github.freqctl.SDHMS_CMD";
    public static final String PERM   = "io.github.freqctl.permission.COMMAND";
    private static final String TAG = "FreqCtl/SDHMS: ";
    private static final String ACTIVITY = "com.sec.android.sdhms.debugger.ThermalLimitSettingActivity";
    // obfuscated limiter names seen so far (fallback only; the structural lookup comes first)
    private static final String[] LIMITER_CANDIDATES = {"j5.m5", "k5.m5", "Q1.j2"};

    private static boolean installed;
    private static Context ctx;
    private static ClassLoader cl;
    private static Handler h;
    private static Object limiter;
    private static boolean screenOn = true;

    private SdhmsExtras() {}

    /** Called by Entry from SDHMS MainApplication.onCreate (after FreqController.install). */
    public static synchronized void install(Context app, ClassLoader loader) {
        if (installed) return;
        installed = true; ctx = app; cl = loader;
        h = new Handler(Looper.getMainLooper());

        try {
            IntentFilter f = new IntentFilter(ACTION);
            app.registerReceiver(new BroadcastReceiver() {
                @Override public void onReceive(Context c, Intent i) {
                    if ("master".equals(i.getStringExtra("cmd"))) setMaster(i.getBooleanExtra("enabled", false));
                    else applyAll("cmd");
                }
            }, f, PERM, h, Context.RECEIVER_EXPORTED);

            IntentFilter sf = new IntentFilter();
            sf.addAction(Intent.ACTION_SCREEN_OFF);
            sf.addAction(Intent.ACTION_SCREEN_ON);
            sf.addAction(Intent.ACTION_USER_PRESENT);
            app.registerReceiver(new BroadcastReceiver() {
                @Override public void onReceive(Context c, Intent i) {
                    String a = i.getAction();
                    if (Intent.ACTION_SCREEN_OFF.equals(a)) { screenOn = false; h.removeCallbacks(keepAlive); }
                    else { // SCREEN_ON / USER_PRESENT: pulse off->on so the touch driver re-latches the mode
                        screenOn = true;
                        if (wantTouch()) { sendTouch(false); h.postDelayed(new Runnable() {
                            @Override public void run() { applyTouch(); } }, 300); }
                    }
                }
            }, sf, null, h);

            ContentObserver obs = new ContentObserver(h) {
                @Override public void onChange(boolean s) { applyAll("setting"); }
            };
            for (String k : new String[]{ExtraSettings.K_TOUCH, ExtraSettings.K_BRIGHT,
                    ExtraSettings.K_CP, ExtraSettings.K_GUARD})
                app.getContentResolver().registerContentObserver(Settings.Global.getUriFor(k), false, obs);
        } catch (Throwable t) { XposedBridge.log(TAG + "install failed: " + t); }

        h.postDelayed(new Runnable() { @Override public void run() { applyAll("boot"); } }, 5000);
    }

    // ------------------------------------------------------------------ state
    private static boolean tripped() { return ExtraSettings.get(ctx, ExtraSettings.K_GUARD, 0) == 1; }
    private static boolean wantTouch() { return ExtraSettings.get(ctx, ExtraSettings.K_TOUCH, 0) == 1 && !tripped(); }

    private static void applyAll(String why) {
        boolean t = tripped();
        setBoolean("h", "k", ExtraSettings.get(ctx, ExtraSettings.K_BRIGHT, 0) == 1 && !t);
        setBoolean("i", "l", ExtraSettings.get(ctx, ExtraSettings.K_CP, 0) == 1 && !t);
        applyTouch();
        XposedBridge.log(TAG + "applied (" + why + ") guardTripped=" + t);
    }

    // ---------------------------------------------------------------- thermal
    private static boolean hasFactory(Class<?> t) {
        for (Method m : t.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (Modifier.isStatic(m.getModifiers()) && p.length == 1 && p[0] == Context.class
                    && m.getReturnType() == t) return true;
        }
        return false;
    }

    private static Object limiter() {
        if (limiter != null) return limiter;
        try {
            Class<?> k = null;
            try {
                Class<?> act = Class.forName(ACTIVITY, false, cl);
                for (Field f : act.getDeclaredFields())
                    if (!f.getType().isPrimitive() && hasFactory(f.getType())) { k = f.getType(); break; }
            } catch (Throwable ignore) {}
            if (k == null) for (String n : LIMITER_CANDIDATES) {
                try { Class<?> c = Class.forName(n, false, cl); if (hasFactory(c)) { k = c; break; } }
                catch (Throwable ignore) {}
            }
            if (k == null) { XposedBridge.log(TAG + "limiter class not found"); return null; }
            for (Method m : k.getDeclaredMethods()) {
                Class<?>[] p = m.getParameterTypes();
                if (Modifier.isStatic(m.getModifiers()) && p.length == 1 && p[0] == Context.class && m.getReturnType() == k) {
                    m.setAccessible(true);
                    limiter = m.invoke(null, ctx);
                    XposedBridge.log(TAG + "limiter = " + k.getName() + "." + m.getName());
                    return limiter;
                }
            }
        } catch (Throwable t) { XposedBridge.log(TAG + "limiter lookup: " + t); }
        return null;
    }

    /** getter = public ()Z (h = brightness, i = CP), setter = public (Z)V (k = brightness, l = CP) in the SDHMS we studied. */
    private static void setBoolean(String getter, String setter, boolean want) {
        Object l = limiter();
        if (l == null) return;
        try {
            Method g = l.getClass().getMethod(getter);
            boolean cur = (Boolean) g.invoke(l);
            if (cur == want) return;
            l.getClass().getMethod(setter, boolean.class).invoke(l, want);
            boolean now = (Boolean) g.invoke(l);
            if (now != want) XposedBridge.log(TAG + setter + "(" + want + ") did not change state - method names differ in this SDHMS build");
        } catch (Throwable t) { XposedBridge.log(TAG + "setBoolean " + setter + ": " + t); }
    }

    /** Master switch. SDHMS restarts the device itself after this, so the app asks for confirmation first. */
    private static void setMaster(boolean disable) {
        Object l = limiter();
        if (l == null) return;
        try { l.getClass().getMethod("d", boolean.class).invoke(l, disable); }
        catch (Throwable t) { XposedBridge.log(TAG + "master: " + t); }
    }

    // ------------------------------------------------------------------ touch
    private static final Runnable keepAlive = new Runnable() {
        @Override public void run() {
            if (wantTouch() && screenOn) { sendTouch(true); h.postDelayed(this, 10000); }
        }
    };

    private static void applyTouch() {
        h.removeCallbacks(keepAlive);
        if (wantTouch() && isInteractive()) { sendTouch(true); h.postDelayed(keepAlive, 10000); }
        else sendTouch(false);
    }

    private static boolean isInteractive() {
        try { return ((PowerManager) ctx.getSystemService(Context.POWER_SERVICE)).isInteractive(); }
        catch (Throwable t) { return true; }
    }

    private static void sendTouch(boolean on) {
        try {
            Intent i = new Intent("com.samsung.android.game.gos.action.TSP");
            i.putExtra("set_game_mode", on ? "1" : "0");
            i.putExtra("set_scan_rate", on ? "1,2" : "0");
            i.putExtra("set_fast_response", on ? "1" : "0");
            ctx.sendBroadcast(i);
        } catch (Throwable t) { XposedBridge.log(TAG + "touch: " + t); }
    }
}
