
# ===== MOD methods (injected by apply_mod.py) =====
.method private static modApply(Landroidx/preference/DropDownPreference;[Ljava/lang/CharSequence;)V
    .locals 4

    iput-object p1, p0, Landroidx/preference/ListPreference;->s:[Ljava/lang/CharSequence;

    iput-object p1, p0, Landroidx/preference/ListPreference;->t:[Ljava/lang/CharSequence;

    iget-object v0, p0, Landroidx/preference/DropDownPreference;->x:Landroidx/appcompat/widget/m2;

    invoke-virtual {v0}, Landroid/widget/ArrayAdapter;->clear()V

    array-length v1, p1

    const/4 v2, 0x0

    :loop
    if-ge v2, v1, :done

    aget-object v3, p1, v2

    invoke-interface {v3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/ArrayAdapter;->add(Ljava/lang/Object;)V

    add-int/lit8 v2, v2, 0x1

    goto :loop

    :done
    return-void
.end method

.method private modSetup()V
    .locals 3

    iget-object v0, p0, Lcom/samsung/android/app/settings/SettingsFragment;->mScreenRecorderVideoSettings:Landroidx/preference/DropDownPreference;

    if-eqz v0, :cond_fps

    sget-object v1, Lcom/mod/RecorderMod;->Q_LABELS:[Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/samsung/android/app/settings/SettingsFragment;->modApply(Landroidx/preference/DropDownPreference;[Ljava/lang/CharSequence;)V

    :cond_fps
    const-string v0, "key_screen_recorder_frame_rate"

    invoke-virtual {p0, v0}, Landroidx/preference/PreferenceFragmentCompat;->findPreference(Ljava/lang/CharSequence;)Landroidx/preference/Preference;

    move-result-object v0

    check-cast v0, Landroidx/preference/DropDownPreference;

    iput-object v0, p0, Lcom/samsung/android/app/settings/SettingsFragment;->mModFpsPref:Landroidx/preference/DropDownPreference;

    if-eqz v0, :cond_done

    sget-object v1, Lcom/mod/RecorderMod;->F_LABELS:[Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/samsung/android/app/settings/SettingsFragment;->modApply(Landroidx/preference/DropDownPreference;[Ljava/lang/CharSequence;)V

    invoke-virtual {v0, p0}, Landroidx/preference/Preference;->setOnPreferenceChangeListener(Landroidx/preference/Preference$OnPreferenceChangeListener;)V

    :cond_done
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/samsung/android/app/settings/SettingsFragment;->mModReady:Z

    invoke-direct {p0}, Lcom/samsung/android/app/settings/SettingsFragment;->modRefresh()V

    return-void
.end method

.method private modRefresh()V
    .locals 5

    iget-boolean v0, p0, Lcom/samsung/android/app/settings/SettingsFragment;->mModReady:Z

    if-nez v0, :cond_go

    return-void

    :cond_go
    iget-object v0, p0, Lcom/samsung/android/app/settings/SettingsFragment;->mScreenRecorderVideoSettings:Landroidx/preference/DropDownPreference;

    iget-object v1, p0, Lcom/samsung/android/app/settings/SettingsFragment;->mContext:Landroid/content/Context;

    if-eqz v0, :cond_fps

    const/4 v2, 0x0

    invoke-static {v1, v2}, Lcom/mod/RecorderMod;->index(Landroid/content/Context;Z)I

    move-result v3

    invoke-static {v2, v3}, Lcom/mod/RecorderMod;->label(ZI)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroidx/preference/ListPreference;->setSummary(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, v3}, Landroidx/preference/DropDownPreference;->h(I)V

    :cond_fps
    iget-object v0, p0, Lcom/samsung/android/app/settings/SettingsFragment;->mModFpsPref:Landroidx/preference/DropDownPreference;

    if-eqz v0, :cond_end

    const/4 v2, 0x1

    invoke-static {v1, v2}, Lcom/mod/RecorderMod;->index(Landroid/content/Context;Z)I

    move-result v3

    invoke-static {v2, v3}, Lcom/mod/RecorderMod;->label(ZI)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroidx/preference/ListPreference;->setSummary(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, v3}, Landroidx/preference/DropDownPreference;->h(I)V

    iget-object v1, p0, Lcom/samsung/android/app/settings/SettingsFragment;->mScreenRecorderVideoSettings:Landroidx/preference/DropDownPreference;

    if-eqz v1, :cond_end

    invoke-virtual {v1}, Landroidx/preference/Preference;->isEnabled()Z

    move-result v2

    invoke-virtual {v0, v2}, Landroidx/preference/Preference;->setEnabled(Z)V

    invoke-virtual {v0, v2}, Landroidx/preference/Preference;->setSelectable(Z)V

    invoke-direct {p0, v2}, Lcom/samsung/android/app/settings/SettingsFragment;->getColorPrimaryDark(Z)I

    move-result v3

    invoke-virtual {v0, v3}, Landroidx/preference/Preference;->seslSetSummaryColor(I)V

    :cond_end
    return-void
.end method

.method private modOnChange(Landroidx/preference/Preference;Ljava/lang/Object;)Z
    .locals 6

    invoke-virtual {p1}, Landroidx/preference/Preference;->getKey()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_has_key

    const/4 v0, 0x0

    return v0

    :cond_has_key
    const-string v1, "key_screen_recorder_video_settings"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_try_fps

    const/4 v2, 0x0

    goto :cond_ours

    :cond_try_fps
    const-string v1, "key_screen_recorder_frame_rate"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_fps_key

    const/4 v0, 0x0

    return v0

    :cond_fps_key
    const/4 v2, 0x1

    :cond_ours
    if-nez p2, :cond_val

    const/4 v0, 0x1

    return v0

    :cond_val
    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/mod/RecorderMod;->labelIndex(ZLjava/lang/String;)I

    move-result v3

    if-gez v3, :cond_idx

    const/4 v0, 0x1

    return v0

    :cond_idx
    invoke-static {v2, v3}, Lcom/mod/RecorderMod;->value(ZI)Ljava/lang/String;

    move-result-object v4

    if-eqz v2, :cond_q

    const-string v0, "video_frame_rate"

    goto :cond_save

    :cond_q
    const-string v0, "video_quality"

    :cond_save
    iget-object v1, p0, Lcom/samsung/android/app/settings/SettingsFragment;->mScreenRecorderSharedPreference:Lcom/samsung/android/app/smartcapture/screenrecorder/util/ScreenRecorderSharePreference;

    iget-object v5, p0, Lcom/samsung/android/app/settings/SettingsFragment;->mContext:Landroid/content/Context;

    invoke-virtual {v1, v5, v0, v4}, Lcom/samsung/android/app/smartcapture/screenrecorder/util/ScreenRecorderSharePreference;->saveStringState(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p0}, Lcom/samsung/android/app/settings/SettingsFragment;->modRefresh()V

    const/4 v0, 0x1

    return v0
.end method
