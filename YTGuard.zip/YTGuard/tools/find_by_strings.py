import sys,struct;sys.path.insert(0,'.')
from dex import *
dexes=load(sys.argv[1],True)
def method_strings(dx,co):
    s=set()
    for p,op,u,off,ln in dx.insns(co):
        if off is None:continue
        if op==0x1a: s.add(dx.string(struct.unpack_from('<H',dx.b,off+2)[0]))
        elif op==0x1b: s.add(dx.string(struct.unpack_from('<I',dx.b,off+2)[0]))
    return s
def find_by_strings(anchors):
    hits=[]
    for n,dx in dexes:
        # quick prefilter: anchors present in pool
        pool=set(dx.strings())
        if not all(a in pool for a in anchors):continue
        for cname,af,sup,cd in dx.classes():
            for mi,maf,co in dx.class_methods(cd):
                if not co:continue
                if all(a in method_strings(dx,co) for a in anchors):
                    c,m,r,ps=dx.method(mi);hits.append((n,c,m,r,ps,hex(maf)))
    return hits
if __name__=='__main__':
    a=sys.argv[2:]
    for h in find_by_strings(a):print(h)
