package io.github.freqctl.hook;

import android.content.Context;

import java.util.concurrent.atomic.AtomicInteger;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import io.github.freqctl.extras.ExtraSettings;

/**
 * Runs inside Samsung's Game Optimizing Service (com.samsung.android.game.gos).
 *
 * <p>GOS is the part of Game Booster that lowers CPU/GPU limits while a game is running. This hook
 * does not disable GOS: it only skips the calls that cap frequencies, one switch per path, so the rest
 * of GOS (game list, Game Launcher, categories, notifications) keeps working.
 *
 * <p>Targets GOS 4.4.00.30. Most class names in that build are not obfuscated (Ipm); the two Game SDK
 * classes are, so each hook is installed on its own and a missing one is only logged.
 *
 * <ul>
 *   <li>IPM / SPA engine ({@code gos.ipm.Ipm}): the native engine that adjusts maximum CPU/GPU/bus
 *       frequency to reach a target FPS and temperature.</li>
 *   <li>Game SDK levels ({@code gos.feature.externalsdk.n / .o}): setCpuLevel / setGpuLevel, which pass a
 *       performance level on to SPA or SSRM.</li>
 * </ul>
 */
final class GosHook {
    static final String PACKAGE = "com.samsung.android.game.gos";

    private static final String IPM = PACKAGE + ".ipm.Ipm";
    private static final String CONTROLLER_TYPE = PACKAGE + ".ipm.ControllerType";
    private static final String SDK_SPA = PACKAGE + ".feature.externalsdk.n";
    private static final String SDK_SSRM = PACKAGE + ".feature.externalsdk.o";

    /** Log only the first few blocked calls of each kind, so the LSPosed log stays readable. */
    private static final int LOG_LIMIT = 5;

    private GosHook() {
    }

    static void install(ClassLoader classLoader) {
        // IPM engine, stricter switch: do not let it start at all (this also stops its FPS statistics).
        hook(classLoader, IPM, "startNative", ExtraSettings.K_GOS_IPM, null);
        hook(classLoader, IPM, "startSpaIfPossible", ExtraSettings.K_GOS_IPM, Boolean.FALSE, String.class);

        // IPM engine, lighter switch: let it run but skip the calls that cap frequencies.
        hook(classLoader, IPM, "setControllerMax", ExtraSettings.K_GOS_CAPS, null, CONTROLLER_TYPE, Long.class);
        hook(classLoader, IPM, "setControllerMaxLevelAsPercentage", ExtraSettings.K_GOS_CAPS, null,
                CONTROLLER_TYPE, Float.class);
        hook(classLoader, IPM, "setMaxFreqs", ExtraSettings.K_GOS_CAPS, null, long.class, long.class);

        // Game SDK performance levels: report success without passing the level on.
        for (String className : new String[]{SDK_SPA, SDK_SSRM}) {
            hook(classLoader, className, "e", ExtraSettings.K_GOS_LEVELS, Boolean.TRUE, int.class); // setGpuLevel
            hook(classLoader, className, "h", ExtraSettings.K_GOS_LEVELS, Boolean.TRUE, int.class); // setCpuLevel
        }
    }

    /**
     * @param result what the skipped method returns (null for void)
     * @param params parameter types, as Class objects or class names
     */
    private static void hook(ClassLoader classLoader, String className, String method, String key,
                             Object result, Object... params) {
        final String label = className.substring(className.lastIndexOf('.') + 1) + "." + method;
        try {
            Object[] args = new Object[params.length + 1];
            System.arraycopy(params, 0, args, 0, params.length);
            args[params.length] = new Block(key, label, result);
            XposedHelpers.findAndHookMethod(className, classLoader, method, args);
        } catch (Throwable t) {
            XposedBridge.log("FreqCtl/GOS: could not hook " + label + " (GOS version differs?)");
            XposedBridge.log(t);
        }
    }

    private static final class Block extends XC_MethodHook {
        private final String key;
        private final String label;
        private final Object result;
        private final AtomicInteger blocked = new AtomicInteger();

        Block(String key, String label, Object result) {
            this.key = key;
            this.label = label;
            this.result = result;
        }

        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            if (!enabled(key)) {
                return;
            }
            param.setResult(result);
            if (blocked.incrementAndGet() <= LOG_LIMIT) {
                XposedBridge.log("FreqCtl/GOS: skipped " + label);
            }
        }
    }

    /** Reads the switch the UI wrote. Any failure means "off": GOS then behaves as stock. */
    private static boolean enabled(String key) {
        try {
            Object app = XposedHelpers.callStaticMethod(
                    XposedHelpers.findClass("android.app.ActivityThread", null), "currentApplication");
            if (!(app instanceof Context)) {
                return false;
            }
            return ExtraSettings.get((Context) app, key, 0) == 1;
        } catch (Throwable t) {
            return false;
        }
    }
}
