package com.example.speedtool

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View
import android.widget.ScrollView

/** ألوان الواجهة. */
object Theme {
    val CYAN = 0xFF00E5FF.toInt()
    val GREEN = 0xFF00E676.toInt()
    val ORANGE = 0xFFFF9100.toInt()
    val RED = 0xFFFF5252.toInt()
    val PURPLE = 0xFF7C4DFF.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val MUTED = 0xFF9AA3B2.toInt()
    val SURFACE = 0xFF1E2336.toInt()
    val SURFACE2 = 0xFF2A3050.toInt()
    val BG_TOP = 0xF21A1F33.toInt()
    val BG_BOTTOM = 0xF20C0E18.toInt()
    val DARK = 0xFF04130B.toInt()
}

fun rounded(color: Int, radius: Float, strokeW: Int = 0, strokeColor: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radius
        setColor(color)
        if (strokeW > 0) setStroke(strokeW, strokeColor)
    }

fun withRipple(content: GradientDrawable, radius: Float): RippleDrawable {
    val mask = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radius
        setColor(Color.WHITE)
    }
    return RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), content, mask)
}

/** ScrollView بحد أقصى للارتفاع (عشان اللوحة ما تطلع برا الشاشة). */
class MaxHeightScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

/** الأيقونة العائمة: دائرة داكنة فيها السرعة مكتوبة، والحلقة خضراء لما التسريع شغّال. */
class BubbleView(ctx: Context) : View(ctx) {
    var speedText = "1.0x"
    var active = false

    private val d = ctx.resources.displayMetrics.density
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
        textSize = 16f * d
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
        textSize = 8f * d
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val r = minOf(w, h) / 2f - 5f * d
        fill.shader = RadialGradient(
            w / 2f, h / 2f - r * 0.35f, r * 1.4f,
            0xFF2D3358.toInt(), 0xFF090A14.toInt(), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - 5f * d
        val accent = if (active) Theme.GREEN else Theme.CYAN

        glow.color = if (active) 0x6600E676 else 0x5500E5FF
        c.drawCircle(cx, cy, r + 3f * d, glow)
        c.drawCircle(cx, cy, r, fill)
        ring.color = accent
        c.drawCircle(cx, cy, r, ring)

        // نصغّر الخط للأرقام الطويلة (مثل 0.05x أو 100x) عشان تبقى داخل الدائرة
        txt.textSize = when {
            speedText.length >= 6 -> 12f * d
            speedText.length == 5 -> 14f * d
            else -> 16f * d
        }
        val fm = txt.fontMetrics
        c.drawText(speedText, cx, cy - (fm.ascent + fm.descent) / 2f - 3f * d, txt)
        small.color = accent
        c.drawText(if (active) "ON" else "OFF", cx, cy + 15f * d, small)
    }
}

/** سهم دائري: للأعلى (أخضر = أسرع) أو للأسفل (برتقالي = أبطأ). */
class ArrowView(ctx: Context, private val up: Boolean) : View(ctx) {
    var down = false

    private val d = ctx.resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
    }
    private val tri = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val accent = if (up) Theme.GREEN else Theme.ORANGE

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f - 2f * d
        bg.color = if (down) accent else 0xEE141830.toInt()
        c.drawCircle(cx, cy, r, bg)
        line.color = accent
        c.drawCircle(cx, cy, r, line)

        tri.color = if (down) 0xFF0B0D18.toInt() else accent
        val s = r * 0.42f
        path.reset()
        if (up) {
            path.moveTo(cx, cy - s)
            path.lineTo(cx - s * 1.15f, cy + s * 0.7f)
            path.lineTo(cx + s * 1.15f, cy + s * 0.7f)
        } else {
            path.moveTo(cx, cy + s)
            path.lineTo(cx - s * 1.15f, cy - s * 0.7f)
            path.lineTo(cx + s * 1.15f, cy - s * 0.7f)
        }
        path.close()
        c.drawPath(path, tri)
    }
}
