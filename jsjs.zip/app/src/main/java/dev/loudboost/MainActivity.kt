package dev.loudboost

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var info: TextView
    private lateinit var label: TextView

    private val tick = object : Runnable {
        override fun run() {
            info.text = GainService.status
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val saved = getSharedPreferences("p", MODE_PRIVATE).getInt("gain", 0)

        label = TextView(this).apply { textSize = 18f; text = "الكسب: $saved mB" }
        info = TextView(this).apply { textSize = 14f; setPadding(0, 48, 0, 0) }

        val sb = SeekBar(this).apply { max = 1200; progress = saved }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                label.text = "الكسب: $p mB (≈ ${p / 100f} dB)"
                if (fromUser) {
                    val svc = GainService.instance
                    if (svc != null) svc.setGain(p)
                    else getSharedPreferences("p", MODE_PRIVATE).edit().putInt("gain", p).apply()
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val start = Button(this).apply {
            text = "تشغيل"
            setOnClickListener {
                startForegroundService(Intent(this@MainActivity, GainService::class.java))
            }
        }
        val stop = Button(this).apply {
            text = "إيقاف"
            setOnClickListener {
                stopService(Intent(this@MainActivity, GainService::class.java))
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 140, 48, 48)
            addView(label)
            addView(sb)
            addView(start)
            addView(stop)
            addView(info)
        })
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }
}
