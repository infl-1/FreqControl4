package io.github.freqctl.ui;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.slider.Slider;

import io.github.freqctl.R;
import io.github.freqctl.extras.ExtraSettings;

/** Touch boost, thermal-limit switches and fingerprint icon size / image. All state lives in Settings.Global. */
final class ExtrasCard {
    interface Listener {
        void onExtraToggle(String key, boolean on);

        void onExtraValue(String key, int value);

        void onMasterThermalRequested();

        void onPickFingerprintIcon();

        void onPickFingerprintAnimation();

        void onResetFingerprintIcon();
    }

    private final Listener listener;
    private final MaterialSwitch touch;
    private final MaterialSwitch bright;
    private final MaterialSwitch cp;
    private final Slider scale;
    private final TextView scaleLabel;
    private final TextView state;
    private final MaterialSwitch loop;
    private final TextView current;

    private boolean binding;

    ExtrasCard(View root, Listener listener) {
        this.listener = listener;
        touch = root.findViewById(R.id.extras_touch_switch);
        bright = root.findViewById(R.id.extras_bright_switch);
        cp = root.findViewById(R.id.extras_cp_switch);
        scale = root.findViewById(R.id.extras_fp_slider);
        scaleLabel = root.findViewById(R.id.extras_fp_label);
        state = root.findViewById(R.id.extras_state);
        loop = root.findViewById(R.id.extras_fp_loop_switch);
        current = root.findViewById(R.id.extras_fp_current);

        wire(touch, ExtraSettings.K_TOUCH);
        wire(bright, ExtraSettings.K_BRIGHT);
        wire(cp, ExtraSettings.K_CP);
        wire(loop, ExtraSettings.K_FP_LOOP);

        ((Button) root.findViewById(R.id.extras_master_button))
                .setOnClickListener(v -> listener.onMasterThermalRequested());
        ((Button) root.findViewById(R.id.extras_fp_pick))
                .setOnClickListener(v -> listener.onPickFingerprintIcon());
        ((Button) root.findViewById(R.id.extras_fp_pick_json))
                .setOnClickListener(v -> listener.onPickFingerprintAnimation());
        ((Button) root.findViewById(R.id.extras_fp_reset))
                .setOnClickListener(v -> listener.onResetFingerprintIcon());

        scale.addOnChangeListener((s, value, fromUser) -> updateLabel());
        scale.addOnSliderTouchListener(new Slider.OnSliderTouchListener() {
            @Override
            public void onStartTrackingTouch(Slider slider) {
            }

            @Override
            public void onStopTrackingTouch(Slider slider) {
                listener.onExtraValue(ExtraSettings.K_FP_SCALE, Math.round(slider.getValue()));
            }
        });
    }

    private void wire(MaterialSwitch toggle, String key) {
        toggle.setOnCheckedChangeListener((button, checked) -> {
            if (!binding) {
                listener.onExtraToggle(key, checked);
            }
        });
    }

    void bind(boolean touchOn, boolean brightOff, boolean cpOff, int scalePercent, boolean guardTripped,
              int fpType, boolean loopOn) {
        binding = true;
        try {
            touch.setChecked(touchOn);
            bright.setChecked(brightOff);
            cp.setChecked(cpOff);
            loop.setChecked(loopOn);
            current.setText(fpType == ExtraSettings.FP_ANIM ? R.string.extras_fp_current_anim
                    : fpType == ExtraSettings.FP_PNG ? R.string.extras_fp_current_png
                    : R.string.extras_fp_current_none);
            float v = Math.max(scale.getValueFrom(), Math.min(scale.getValueTo(), scalePercent));
            scale.setValue(Math.round(v / 5f) * 5f);
            updateLabel();
            state.setText(guardTripped ? R.string.extras_state_tripped : R.string.extras_state_ok);
        } finally {
            binding = false;
        }
    }

    private void updateLabel() {
        scaleLabel.setText(scaleLabel.getContext().getString(R.string.extras_fp_label, Math.round(scale.getValue())));
    }
}
