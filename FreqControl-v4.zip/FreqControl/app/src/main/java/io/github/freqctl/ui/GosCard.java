package io.github.freqctl.ui;

import android.view.View;

import com.google.android.material.materialswitch.MaterialSwitch;

import io.github.freqctl.R;

/** Game Optimizing Service card: two switches that stop GOS from capping CPU/GPU frequency in games. */
final class GosCard {
    interface Listener {
        void onGosCommit(boolean blockIpm, boolean blockLevels);
    }

    private final Listener listener;
    private final MaterialSwitch ipmSwitch;
    private final MaterialSwitch levelsSwitch;
    private boolean binding;

    GosCard(View root, Listener listener) {
        this.listener = listener;
        ipmSwitch = root.findViewById(R.id.gos_ipm_switch);
        levelsSwitch = root.findViewById(R.id.gos_levels_switch);
        ipmSwitch.setOnCheckedChangeListener((button, checked) -> commit());
        levelsSwitch.setOnCheckedChangeListener((button, checked) -> commit());
    }

    void bind(boolean blockIpm, boolean blockLevels) {
        binding = true;
        try {
            ipmSwitch.setChecked(blockIpm);
            levelsSwitch.setChecked(blockLevels);
        } finally {
            binding = false;
        }
    }

    private void commit() {
        if (!binding) {
            listener.onGosCommit(ipmSwitch.isChecked(), levelsSwitch.isChecked());
        }
    }
}
