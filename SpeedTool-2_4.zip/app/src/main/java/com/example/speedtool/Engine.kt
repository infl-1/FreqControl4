package com.example.speedtool

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.Locale

object Engine {
    const val DIR = "/data/local/tmp"
    // ألعاب أونلاين تنحظر فيها الحسابات: الأداة ترفض تشتغل عليها
    private val blocked = listOf("callofduty", "codm", "com.tencent.ig", "com.pubg", "freefire")
    private val validName = Regex("^[A-Za-z0-9._]+$")
    private val main = Handler(Looper.getMainLooper())

    // يرجّع SELinux لحالته الأصلية (نحفظها قبل ما نخليه Permissive)
    private const val RESTORE_SELINUX =
        "p=\$(cat $DIR/selinux_prev 2>/dev/null); [ \"\$p\" = Enforcing ] && setenforce 1; rm -f $DIR/selinux_prev; true"

    class App(val pkg: String, val label: String, val icon: Drawable?, val running: Boolean = false)

    @Volatile var pkg: String? = null
    @Volatile var speed = 2.0
    @Volatile var running = false
    @Volatile var mode = "auto"          // auto | libc
    // جدول المصادر (مثل جيم جاردن): صف لكل دالة وقت، وكل صف فيه 4 بتات: 1=App 2=Java 4=System 8=Other
    const val ROWS = 10
    val ROW_NAMES = listOf(
        "clock_gettime · REALTIME + gettimeofday", "clock_gettime · MONOTONIC", "clock_gettime · MONOTONIC_RAW",
        "clock_gettime · BOOTTIME", "nanosleep", "usleep", "clock_nanosleep",
        "pthread_cond_*wait", "sem_*wait", "pthread_mutex/rwlock *lock"
    )
    fun defaultMatrix() = IntArray(ROWS) { 3 }          // App + Java لكل الصفوف (نفس افتراضي جيم جاردن)
    @Volatile var matrix: IntArray = defaultMatrix()
    /** الصيغة اللي يقرأها الحاقن: "0=AJ 1=AJ 2=A ..." */
    val cats: String
        get() = (0 until ROWS).joinToString(" ") { i ->
            val b = matrix[i]
            "$i=" + (if ((b and 1) != 0) "A" else "") + (if ((b and 2) != 0) "J" else "") +
                (if ((b and 4) != 0) "S" else "") + (if ((b and 8) != 0) "O" else "")
        }
    @Volatile var startedAt = 0L

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("st", Context.MODE_PRIVATE)
    fun modeFor(ctx: Context, name: String): String = prefs(ctx).getString("mode_$name", "auto") ?: "auto"
    fun saveMode(ctx: Context, name: String, m: String) { prefs(ctx).edit().putString("mode_$name", m).apply() }
    fun matrixFor(ctx: Context, name: String): IntArray {
        val m = defaultMatrix()
        val t = prefs(ctx).getString("mx_$name", null) ?: return m
        val p = t.split(",")
        for (i in 0 until ROWS) m[i] = (p.getOrNull(i)?.toIntOrNull() ?: 3) and 15
        return m
    }
    fun saveMatrix(ctx: Context, name: String, m: IntArray) {
        prefs(ctx).edit().putString("mx_$name", m.joinToString(",")).apply()
    }

    fun isBlocked(name: String) = blocked.any { name.contains(it, ignoreCase = true) }

    private fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)

    fun su(cmd: String, cb: ((String) -> Unit)? = null) {
        Thread {
            val out = try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                p.outputStream.close()
                val o = p.inputStream.bufferedReader().readText() +
                        p.errorStream.bufferedReader().readText()
                p.waitFor()
                o
            } catch (e: Exception) {
                "فشل: لا يوجد روت؟ ${e.message}"
            }
            if (cb != null) main.post { cb(out.trim().ifBlank { "تم" }) }
        }.start()
    }

    /** كل التطبيقات القابلة للفتح (الشغالة أولاً ثم الباقي بالاسم). */
    fun listApps(ctx: Context, cb: (List<App>) -> Unit) {
        val appCtx = ctx.applicationContext
        Thread {
            val names: Set<String> = try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "ps -A -o NAME 2>/dev/null"))
                p.outputStream.close()
                val set = p.inputStream.bufferedReader().readLines()
                    .map { it.trim().substringBefore(':') }.toSet()
                p.waitFor()
                set
            } catch (e: Exception) {
                emptySet()
            }
            val apps: List<App> = try {
                val pm = appCtx.packageManager
                pm.getInstalledApplications(0)
                    .filter {
                        (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                            (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                    }
                    .filter { it.packageName != appCtx.packageName }
                    .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
                    .map {
                        val ic = try { pm.getApplicationIcon(it) } catch (e: Exception) { null }
                        App(it.packageName, pm.getApplicationLabel(it).toString(), ic, it.packageName in names)
                    }
                    .sortedWith(compareByDescending<App> { it.running }.thenBy { it.label.lowercase() })
            } catch (e: Exception) {
                emptyList()
            }
            main.post { cb(apps) }
        }.start()
    }

    /** يفك ضغط frida-inject.xz المدمج في الـ APK إلى مجلد التطبيق (مرة وحدة، أو لما يتغير الملف). */
    private fun prepareBundled(ctx: Context): File? {
        val dst = File(ctx.filesDir, "frida-inject")
        val marker = File(ctx.filesDir, "frida-inject.ok")
        val tag = try {
            ctx.assets.open("frida-inject.xz").use { it.available().toString() }
        } catch (e: Exception) {
            return null                         // الـ APK مبني بدون frida-inject.xz
        }
        if (dst.exists() && dst.length() > 1_000_000L && marker.exists() && marker.readText() == tag) return dst
        marker.delete()
        ctx.assets.open("frida-inject.xz").use { raw ->
            org.tukaani.xz.XZInputStream(java.io.BufferedInputStream(raw, 1 shl 16)).use { xz ->
                dst.outputStream().use { o -> xz.copyTo(o, 1 shl 16) }
            }
        }
        marker.writeText(tag)
        return dst
    }

    fun start(ctx: Context, cb: (String) -> Unit) {
        val name = pkg
        if (name == null) { cb("اختر تطبيقًا أولًا"); return }
        if (isBlocked(name)) { cb("هذا تطبيق أونلاين وفيه حظر للحسابات، الأداة ترفض تشتغل عليه."); return }
        if (!validName.matches(name)) { cb("اسم الحزمة غير صالح"); return }
        running = true
        startedAt = System.currentTimeMillis()
        val appCtx = ctx.applicationContext
        Thread {
            val js = File(appCtx.filesDir, "speed.js")
            val bundled = try {
                appCtx.assets.open("speed.js").use { i -> js.outputStream().use { o -> i.copyTo(o) } }
                prepareBundled(appCtx)
            } catch (e: Exception) {
                null
            }
            // لو frida-inject مدمج: ننسخه لـ /data/local/tmp (إذا غير موجود أو حجمه مختلف)
            val install = if (bundled != null)
                "[ \"\$(stat -c %s $DIR/frida-inject 2>/dev/null)\" = \"${bundled.length()}\" ] || cp ${bundled.absolutePath} $DIR/frida-inject; "
            else ""
            su(
                install +
                "[ -f $DIR/frida-inject ] || { echo 'FC_ERR: frida-inject غير موجود (frida-inject.xz ناقص من الـ APK)'; exit 3; }; " +
                "PID=\$(pidof $name | cut -d' ' -f1); " +
                "[ -n \"\$PID\" ] || { echo 'FC_ERR: التطبيق غير شغّال، افتحه أولًا'; exit 4; }; " +
                "echo ${fmt(speed)} > $DIR/speed.txt; chmod 644 $DIR/speed.txt; " +
                "echo $cats > $DIR/cats.txt; chmod 644 $DIR/cats.txt; " +
                // الحاقن يشتغل بصلاحيات اللعبة فما يقدر ينشئ ملف في /data/local/tmp: ننشئ seen.txt له قابل للكتابة (كشف المصادر النشطة)
                "touch $DIR/seen.txt; chmod 666 $DIR/seen.txt; " +
                // نفس اللعبة ونفس الوضع والحاقن حيّ: نكتفي بإرجاع السرعة بدون إعادة حقن (إعادة الحقن تقطع الوقت وتكرّش اللعبة)
                "if [ \"\$(cat $DIR/inj.pid 2>/dev/null)\" = \"\$PID\" ] && [ \"\$(cat $DIR/inj.mode 2>/dev/null)\" = \"$mode\" ] && pgrep -x frida-inject >/dev/null; then " +
                "echo FC_REUSE; tail -n 8 $DIR/frida.log; exit 0; fi; " +
                "[ \"\$(getenforce)\" = Enforcing ] && echo Enforcing > $DIR/selinux_prev; " +
                "setenforce 0; " +
                "pkill -x frida-inject; " +
                "cp ${js.absolutePath} $DIR/speed.js; chmod 644 $DIR/speed.js; " +
                "echo $mode > $DIR/mode.txt; chmod 644 $DIR/mode.txt; " +
                "chmod 755 $DIR/frida-inject; " +
                "nohup $DIR/frida-inject -p \$PID -s $DIR/speed.js > $DIR/frida.log 2>&1 < /dev/null & " +
                "echo \$PID > $DIR/inj.pid; echo $mode > $DIR/inj.mode; " +
                // مراقب: لما يموت الحاقن (اللعبة أُغلقت) يرجّع SELinux وينظّف
                "[ -f $DIR/watch.pid ] && kill \$(cat $DIR/watch.pid) 2>/dev/null; " +
                "nohup sh -c 'while pgrep -x frida-inject >/dev/null || { sleep 3; pgrep -x frida-inject >/dev/null; }; do sleep 3; done; " +
                "$RESTORE_SELINUX; rm -f $DIR/inj.pid $DIR/inj.mode' > /dev/null 2>&1 < /dev/null & echo \$! > $DIR/watch.pid; " +
                "sleep 2; " +
                "pgrep -x frida-inject >/dev/null || echo 'FC_ERR: توقف الحاقن، شوف السجل'; " +
                "tail -n 8 $DIR/frida.log"
            ) { out ->
                if (out.contains("FC_ERR")) {
                    running = false
                    su(RESTORE_SELINUX)            // فشل التشغيل: لا نترك SELinux مفتوح
                }
                cb(out.replace("FC_ERR: ", "").replace("FC_REUSE", "رجع التسريع على نفس الجلسة (بدون إعادة حقن)"))
            }
        }.start()
    }

    fun updateSpeed(v: Double) {
        speed = v
        if (running) su("echo ${fmt(v)} > $DIR/speed.txt; chmod 644 $DIR/speed.txt")
    }

    /** إيقاف ناعم: نرجّع السرعة 1.0 ونترك الحاقن شغّال.
     *  لو قتلناه يرجع وقت اللعبة للحقيقي فجأة (متأخر دقايق عن الوقت المزيّف) وتكرّش اللعبة.
     *  الحاقن يموت لحاله لما تُقفل اللعبة، والمراقب (في start) يرجّع SELinux وقتها. */
    fun stop(cb: ((String) -> Unit)? = null) {
        running = false
        su("echo 1.00 > $DIR/speed.txt; chmod 644 $DIR/speed.txt", cb)
    }

    /** تبديل المصادر والحاقن حيّ: آمن لأن كل مصدر يحتفظ بساعته (ما يقفز الوقت). */
    fun updateCats() {
        su("echo $cats > $DIR/cats.txt; chmod 644 $DIR/cats.txt")
    }

    /** يطفي التطبيق بالكامل: يوقف الحاقن ويرجّع SELinux ثم يقفل الأيقونة والشاشة ويقتل العملية. */
    fun quitAll(ctx: Context) {
        val app = ctx.applicationContext
        val finish: () -> Unit = {
            closeRootShell()
            Mem.close()
            app.stopService(Intent(app, FloatingService::class.java))
            MainActivity.current?.get()?.finishAndRemoveTask()
            main.postDelayed({ android.os.Process.killProcess(android.os.Process.myPid()) }, 350)
        }
        if (running) stop { finish() } else finish()
    }

    /** هل الحاقن لسا شغّال؟ (يموت لو اللعبة أُغلقت) */
    fun alive(cb: (Boolean) -> Unit) =
        su("pgrep -x frida-inject >/dev/null && echo ON || echo OFF") { cb(it.trim() == "ON") }

    // ------------------------------------------------------------------ فحص جاهزية الحقن (قراءة فقط، بدون أي حقن)

    /** نتيجة فحص اللعبة من /proc (assets/probe.sh). */
    class Readiness(
        val alive: Boolean,        // العملية موجودة
        val age: Int,              // عمرها بالثواني
        val fg: Boolean,           // اللعبة في الواجهة (oom_score_adj <= 0)
        val engine: Boolean,       // خيط UnityMain ظهر (محرك Unity اشتغل)
        val nativeLibs: Boolean,   // كود native للتطبيق محمّل تحت /data/app
        val art: Boolean,          // بيئة Java (ART) شغّالة
        val maps: Int,             // عدد أسطر /proc/PID/maps (نقيس منه استقرار التحميل)
        val injected: Boolean,     // الحاقن شغّال أصلاً داخل نفس العملية
        val seen: IntArray = IntArray(ROWS * 4),   // استدعاءات بالثانية لكل (صف × مصدر) كما كشفها الحاقن: seen[صف*4 + عمود]
        val seenOk: Boolean = false         // وصلتنا أرقام حديثة من الحاقن
    )

    // شل روت واحد دائم للفحص: أمر su جديد كل ثانية ونص يزعج (وفلاش Magisk) وبطيء، فنفتح جلسة وحدة ونعيد استخدامها
    private val probeExec = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r).apply { isDaemon = true }
    }
    @Volatile private var rsh: Process? = null
    @Volatile private var rshOut: java.io.BufferedReader? = null
    private var probeScript: String? = null

    private fun openRootShell(): Process? {
        val cur = rsh
        if (cur != null) {
            val dead = try { cur.exitValue(); true } catch (e: IllegalThreadStateException) { false }
            if (!dead) return cur
        }
        return try {
            val p = ProcessBuilder("su").redirectErrorStream(true).start()
            rsh = p
            rshOut = p.inputStream.bufferedReader()
            p
        } catch (e: Exception) {
            rsh = null
            rshOut = null
            null
        }
    }

    fun closeRootShell() {
        try { rsh?.destroy() } catch (e: Exception) {}
        rsh = null
        rshOut = null
    }

    /** يشغّل سكربت داخل الشل الدائم ويرجّع مخرجاته (أو null لو علق/فشل: نغلق الشل ويُفتح من جديد بالفحص التالي). */
    private fun shellRun(script: String): String? {
        val p = openRootShell() ?: return null
        val rd = rshOut ?: return null
        val killer = Runnable { try { p.destroy() } catch (e: Exception) {} }
        main.postDelayed(killer, 8000)
        var result: String? = null
        try {
            // ( ... ) < /dev/null : أي أمر يحاول يقرأ stdin ما ياكل باقي السكربت، وexit داخله ما يقتل الشل
            p.outputStream.write(("(\n" + script + "\n) < /dev/null\necho PROBE_END\n").toByteArray())
            p.outputStream.flush()
            val sb = StringBuilder()
            while (true) {
                val line = rd.readLine() ?: break
                if (line == "PROBE_END") { result = sb.toString(); break }
                sb.append(line).append('\n')
            }
        } catch (e: Exception) {
            result = null
        } finally {
            main.removeCallbacks(killer)
        }
        if (result == null) closeRootShell()
        return result
    }

    private fun parseProbe(out: String?): Readiness? {
        if (out == null) return null
        val line = out.lines().lastOrNull { it.startsWith("PROBE") } ?: return null
        val t = line.trim().split(Regex("\\s+"))
        if (t.size < 2) return null
        if (t[1] == "none") return Readiness(false, 0, false, false, false, false, 0, false)
        if (t[1] != "ok" || t.size < 9) return null
        fun n(i: Int): Int = t[i].toIntOrNull() ?: 0
        val seen = IntArray(ROWS * 4)
        var seenOk = false
        val sl = out.lines().lastOrNull { it.startsWith("SEEN") }
        if (sl != null) {
            // الصيغة: SEEN 0:a,j,s,o 1:a,j,s,o ...
            for (tok in sl.trim().split(Regex("\\s+")).drop(1)) {
                val kv = tok.split(":")
                if (kv.size != 2) continue
                val r = kv[0].toIntOrNull() ?: continue
                val v = kv[1].split(",")
                if (r !in 0 until ROWS || v.size != 4) continue
                for (c in 0 until 4) seen[r * 4 + c] = v[c].toIntOrNull() ?: 0
                seenOk = true
            }
        }
        return Readiness(true, n(2), n(3) == 1, n(4) > 0, n(5) > 0, n(6) > 0, n(7), n(8) == 1, seen, seenOk)
    }

    /** يفحص حالة اللعبة (بدون حقن) ويرجّع النتيجة على الخيط الرئيسي؛ null = تعذّر الفحص. */
    fun probe(ctx: Context, name: String, cb: (Readiness?) -> Unit) {
        if (!validName.matches(name)) { cb(null); return }
        val app = ctx.applicationContext
        probeExec.execute {
            val res: Readiness? = try {
                var sc = probeScript
                if (sc == null) {
                    sc = app.assets.open("probe.sh").bufferedReader().use { it.readText() }
                    probeScript = sc
                }
                parseProbe(shellRun(sc.replace("__PKG__", name)))
            } catch (e: Exception) {
                null
            }
            main.post { cb(res) }
        }
    }

    /** سجل الحاقن + آخر كراش في النظام (لو اللعبة كرّشت): نرسل هذا الناتج لو صار كراش. */
    fun readLog(cb: (String) -> Unit) = su(
        "tail -n 12 $DIR/frida.log; " +
        "echo '--- crash log ---'; " +
        "logcat -b crash -d -t 60 2>/dev/null | grep -E 'Fatal signal|signal [0-9]+|backtrace|#0[0-9] pc|Abort message|>>> ' | tail -n 14; " +
        "echo '--- tombstones ---'; ls -t /data/tombstones 2>/dev/null | head -n 3",
        cb
    )
}
