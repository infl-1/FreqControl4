package com.example.tiksaver

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume

class MainActivity : AppCompatActivity() {

    private lateinit var linkInput: EditText
    private lateinit var downloadBtn: Button
    private lateinit var cancelBtn: Button
    private lateinit var updateBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var webContainer: FrameLayout
    private lateinit var pickerContainer: LinearLayout
    private lateinit var pickerInfo: TextView
    private lateinit var imageGrid: GridLayout
    private lateinit var selectAllBtn: Button
    private lateinit var clearAllBtn: Button
    private lateinit var saveSelectedBtn: Button
    private lateinit var pickerCancelBtn: Button

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var ready = false
    private val cookies = mutableMapOf<String, String>()
    private var lastResolvedUrl: String? = null
    private var photoDebug: String = ""
    private var webView: WebView? = null
    private var activeJob: Job? = null
    private var thumbJob: Job? = null
    private var currentPost: PhotoPost? = null
    private val selected = linkedSetOf<Int>()
    private val cellImages = mutableListOf<ImageView>()
    private val cellMarks = mutableListOf<TextView>()
    private val stateListener: () -> Unit = { renderState() }

    private val USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val urlRegex = Regex("""https?://\S+""")
    private val supportedDomains = listOf(
        "tiktok.com",
        "snapchat.com",
        "x.com", "twitter.com", "t.co",
        "youtube.com", "youtu.be"
    )
    private val pageDataJs =
        "(function(){var ids=['__UNIVERSAL_DATA_FOR_REHYDRATION__','SIGI_STATE','__NEXT_DATA__'];" +
            "for(var i=0;i<ids.length;i++){var e=document.getElementById(ids[i]);" +
            "if(e&&e.textContent){return e.textContent;}}return '';})()"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        linkInput = findViewById(R.id.linkInput)
        downloadBtn = findViewById(R.id.downloadBtn)
        cancelBtn = findViewById(R.id.cancelBtn)
        updateBtn = findViewById(R.id.updateBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        webContainer = findViewById(R.id.webContainer)
        pickerContainer = findViewById(R.id.pickerContainer)
        pickerInfo = findViewById(R.id.pickerInfo)
        imageGrid = findViewById(R.id.imageGrid)
        selectAllBtn = findViewById(R.id.selectAllBtn)
        clearAllBtn = findViewById(R.id.clearAllBtn)
        saveSelectedBtn = findViewById(R.id.saveSelectedBtn)
        pickerCancelBtn = findViewById(R.id.pickerCancelBtn)

        findViewById<Button>(R.id.pasteBtn).setOnClickListener { pasteFromClipboard() }
        downloadBtn.setOnClickListener { startDownload() }
        cancelBtn.setOnClickListener { cancelCurrent() }
        updateBtn.setOnClickListener { updateEngine() }

        selectAllBtn.setOnClickListener {
            currentPost?.let { post ->
                selected.clear()
                selected.addAll(post.imageUrls.indices)
                refreshCells()
            }
        }
        clearAllBtn.setOnClickListener {
            selected.clear()
            refreshCells()
        }
        saveSelectedBtn.setOnClickListener { saveSelected() }
        pickerCancelBtn.setOnClickListener {
            hidePicker()
            status.text = "تم الإلغاء"
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        handleShareIntent(intent)
        initEngine()
    }

    override fun onResume() {
        super.onResume()
        DownloadState.addListener(stateListener)
        renderState()
    }

    override fun onPause() {
        DownloadState.removeListener(stateListener)
        super.onPause()
    }

    override fun onDestroy() {
        destroyWebView()
        super.onDestroy()
    }

    // لو التطبيق مفتوح وجاء رابط جديد من "مشاركة" ما نفتح نسخة ثانية، نستخدم نفس الشاشة
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    private fun handleShareIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT))?.let { linkInput.setText(it) }
        }
    }

    // ---------- المحرك ----------

    private fun initEngine() {
        busy(true)
        status.text = "جاري تجهيز المحرك (أول مرة فقط، ممكن ياخذ شوي)..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().init(applicationContext)
                    FFmpeg.getInstance().init(applicationContext)
                }
                ready = true
                status.text = "جاهز ✅"
            } catch (e: Exception) {
                status.text = "تعذر تجهيز المحرك: ${e.message}"
            } finally {
                busy(false)
            }
        }
    }

    private fun updateEngine() {
        busy(true)
        status.text = "جاري تحديث المحرك..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().updateYoutubeDL(applicationContext, YoutubeDL.UpdateChannel.STABLE)
                }
                status.text = "تم تحديث المحرك ✅"
            } catch (e: Exception) {
                status.text = "فشل التحديث، تأكد من الإنترنت"
            } finally {
                busy(false)
            }
        }
    }

    // ---------- التحميل ----------

    private fun startDownload() {
        val url = extractUrl(linkInput.text.toString())
        if (url == null || !isSupported(url)) {
            status.text = "الرابط غير مدعوم. المدعوم: تيك توك، سناب شات، X، يوتيوب"
            return
        }
        if (DownloadState.state == DownloadState.State.RUNNING) {
            status.text = "فيه تحميل شغال حالياً، انتظر أو اضغط إلغاء"
            return
        }
        linkInput.setText(url)
        hidePicker()

        // غير تيك توك: ما فيه بوستات صور، نسأل عن الجودة مباشرة
        if (!isTikTok(url)) {
            askQuality(url)
            return
        }

        busy(true)
        cancelBtn.visibility = View.VISIBLE
        status.text = "جاري فحص الرابط..."
        activeJob = lifecycleScope.launch {
            try {
                var found = withContext(Dispatchers.IO) { findPhotoPost(url) }
                val isPhotoLink = url.contains("/photo/") ||
                    lastResolvedUrl?.contains("/photo/") == true
                if (found == null && isPhotoLink) {
                    status.text = "جاري فتح البوست..."
                    found = findPhotoPostWebView(lastResolvedUrl ?: url)
                }
                val post = found
                if (post != null) {
                    showPicker(post)
                } else if (isPhotoLink) {
                    status.text = "تعذر تحميل صور البوست\n[صور] $photoDebug"
                } else {
                    askQuality(url)
                }
            } catch (e: CancellationException) {
                status.text = "تم الإلغاء"
                throw e
            } catch (e: Exception) {
                val reason = e.message?.lineSequence()?.firstOrNull { it.isNotBlank() }?.take(160)
                    ?: e.javaClass.simpleName
                status.text = "فشل التحميل. تأكد من الرابط، أو اضغط «تحديث المحرك» وحاول مرة ثانية.\n[تفاصيل] $reason"
            } finally {
                busy(false)
                cancelBtn.visibility = View.GONE
            }
        }
    }

    /** قائمة الجودات: من الأصلية إلى 144p + صوت فقط */
    private fun askQuality(url: String) {
        val options = Quality.values()
        val dialog = AlertDialog.Builder(this)
            .setTitle("اختر الجودة")
            .setItems(options.map { it.label }.toTypedArray()) { _, which ->
                beginVideoDownload(url, options[which])
            }
            .setNegativeButton("إلغاء", null)
            .show()
        dialog.window?.decorView?.layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun beginVideoDownload(url: String, quality: Quality) {
        DownloadState.update(DownloadState.State.RUNNING, 0, "جاري التحميل...")
        DownloadService.start(this, url, quality)
        renderState()
    }

    private fun cancelCurrent() {
        if (DownloadState.state == DownloadState.State.RUNNING) {
            DownloadService.cancel(this)
            status.text = "جاري الإلغاء..."
        } else {
            activeJob?.cancel()
        }
    }

    /** يعرض حالة الخدمة (تقدم / نجاح / فشل / إلغاء) على الشاشة */
    private fun renderState() {
        when (DownloadState.state) {
            DownloadState.State.RUNNING -> {
                if (progress.visibility != View.VISIBLE) busy(true, determinate = true)
                progress.isIndeterminate = false
                progress.progress = DownloadState.progress
                status.text = DownloadState.message
                cancelBtn.visibility = View.VISIBLE
            }
            DownloadState.State.DONE,
            DownloadState.State.FAILED,
            DownloadState.State.CANCELLED -> {
                status.text = DownloadState.message
                busy(false)
                cancelBtn.visibility = View.GONE
                DownloadState.reset()
            }
            DownloadState.State.IDLE -> Unit
        }
    }

    // ---------- اختيار صور البوست ----------

    private fun showPicker(post: PhotoPost) {
        currentPost = post
        selected.clear()
        selected.addAll(post.imageUrls.indices)
        imageGrid.removeAllViews()
        cellImages.clear()
        cellMarks.clear()

        val size = (resources.displayMetrics.widthPixels - dp(48)) / 3 - dp(6)
        post.imageUrls.indices.forEach { index ->
            imageGrid.addView(createCell(index, size))
        }
        pickerContainer.visibility = View.VISIBLE
        setPickerEnabled(true)
        refreshCells()

        status.text = "جاري تجهيز المعاينة (${post.imageUrls.size} صور)..."
        thumbJob = lifecycleScope.launch {
            post.imageUrls.forEachIndexed { i, imageUrl ->
                val bitmap = withContext(Dispatchers.IO) {
                    try {
                        decodeThumb(httpGet(imageUrl, "https://www.tiktok.com/").body)
                    } catch (e: Exception) {
                        null
                    }
                }
                if (bitmap != null && i < cellImages.size) cellImages[i].setImageBitmap(bitmap)
            }
            status.text = "اختر الصور اللي تبيها:"
        }
    }

    private fun createCell(index: Int, size: Int): FrameLayout {
        val cell = FrameLayout(this)
        val lp = GridLayout.LayoutParams()
        lp.width = size
        lp.height = size
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        cell.layoutParams = lp

        val image = ImageView(this)
        image.scaleType = ImageView.ScaleType.CENTER_CROP
        image.setBackgroundColor(0xFF444444.toInt())
        cell.addView(
            image,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        val mark = TextView(this)
        mark.text = "✓"
        mark.setTextColor(Color.WHITE)
        mark.textSize = 16f
        mark.setPadding(dp(6), dp(2), dp(6), dp(2))
        mark.setBackgroundColor(0xCC2E7D32.toInt())
        cell.addView(
            mark,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            )
        )

        cell.setOnClickListener {
            if (!selected.add(index)) selected.remove(index)
            refreshCells()
        }
        cellImages.add(image)
        cellMarks.add(mark)
        return cell
    }

    private fun refreshCells() {
        cellImages.forEachIndexed { i, image -> image.alpha = if (i in selected) 1f else 0.4f }
        cellMarks.forEachIndexed { i, mark ->
            mark.visibility = if (i in selected) View.VISIBLE else View.GONE
        }
        pickerInfo.text = "المحدد: ${selected.size} من ${cellImages.size}"
        saveSelectedBtn.isEnabled = selected.isNotEmpty()
    }

    private fun setPickerEnabled(on: Boolean) {
        selectAllBtn.isEnabled = on
        clearAllBtn.isEnabled = on
        saveSelectedBtn.isEnabled = on && selected.isNotEmpty()
        pickerCancelBtn.isEnabled = on
    }

    private fun hidePicker() {
        thumbJob?.cancel()
        pickerContainer.visibility = View.GONE
        imageGrid.removeAllViews()
        cellImages.clear()
        cellMarks.clear()
        selected.clear()
        currentPost = null
    }

    private fun saveSelected() {
        val post = currentPost ?: return
        if (selected.isEmpty()) {
            status.text = "ما حددت أي صورة"
            return
        }
        val indices = selected.sorted()
        thumbJob?.cancel()
        setPickerEnabled(false)
        busy(true, determinate = true)
        cancelBtn.visibility = View.VISIBLE
        activeJob = lifecycleScope.launch {
            try {
                var saved = 0
                indices.forEachIndexed { n, index ->
                    status.text = "جاري حفظ ${n + 1} من ${indices.size} صور..."
                    withContext(Dispatchers.IO) { savePhoto(post, index) }
                    saved++
                    progress.progress = saved * 100 / indices.size
                }
                status.text = "تم حفظ $saved صور في المعرض (Pictures/TikSaver) ✅"
                hidePicker()
            } catch (e: CancellationException) {
                status.text = "تم الإلغاء"
                setPickerEnabled(true)
                throw e
            } catch (e: Exception) {
                val reason = e.message?.lineSequence()?.firstOrNull { it.isNotBlank() }?.take(160)
                    ?: e.javaClass.simpleName
                status.text = "تعذر تحميل صور البوست\n[تفاصيل] $reason"
                setPickerEnabled(true)
            } finally {
                busy(false)
                cancelBtn.visibility = View.GONE
            }
        }
    }

    private fun savePhoto(post: PhotoPost, index: Int) {
        val imageUrl = post.imageUrls[index]
        val result = httpGet(imageUrl, referer = "https://www.tiktok.com/")
        val ext = imageExtension(imageUrl)
        MediaSaver.saveImage(
            this,
            result.body,
            "tiktok_${post.id}_${"%02d".format(index + 1)}.$ext",
            imageMime(ext)
        )
    }

    private fun decodeThumb(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 600) sample *= 2
        val options = BitmapFactory.Options()
        options.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    }

    // ---------- بوستات الصور (تيك توك) ----------

    private class PhotoPost(val id: String, val imageUrls: List<String>)

    private class HttpResult(val body: ByteArray, val finalUrl: String)

    /**
     * يفتح صفحة البوست ويقرأ بياناتها ويدور على imagePost.
     * يرجع null إذا كان البوست فيديو عادي أو تعذر قراءة الصفحة (والسبب يتسجل في photoDebug).
     */
    private fun findPhotoPost(url: String): PhotoPost? {
        lastResolvedUrl = null
        photoDebug = ""
        return try {
            cookies.clear()
            val page = httpGet(url, referer = null)
            lastResolvedUrl = page.finalUrl
            val html = String(page.body, Charsets.UTF_8)

            val data = extractPageData(html)
            var item: JSONObject? = data?.let { findItemWithImages(it) }
            if (item == null) {
                // محاولة ثانية: نقتطع كائن imagePost مباشرة من نص الصفحة
                val post = extractJsonObjectAfter(html, "\"imagePost\":")
                if (post != null && (post.optJSONArray("images")?.length() ?: 0) > 0) {
                    item = JSONObject().put("imagePost", post)
                }
            }
            if (item == null) {
                photoDebug = when {
                    html.contains("captcha", ignoreCase = true) -> "تيك توك طلب كابتشا"
                    data == null -> "الصفحة بدون بيانات (حجمها ${html.length})"
                    else -> "ما فيه صور بالبوست (فيديو عادي؟)"
                }
                return null
            }
            buildPhotoPost(item, page.finalUrl.substringBefore('?').trimEnd('/').substringAfterLast('/'))
        } catch (e: Exception) {
            photoDebug = "تعذر فتح الصفحة: ${e.message}"
            null
        }
    }

    /** نفس الفكرة لكن من نص بيانات الصفحة اللي نجيبه من الـ WebView */
    private fun postFromText(text: String, fallbackId: String): PhotoPost? {
        val data = try {
            JSONObject(text)
        } catch (e: Exception) {
            null
        }
        var item: JSONObject? = data?.let { findItemWithImages(it) }
        if (item == null) {
            val post = extractJsonObjectAfter(text, "\"imagePost\":")
            if (post != null && (post.optJSONArray("images")?.length() ?: 0) > 0) {
                item = JSONObject().put("imagePost", post)
            }
        }
        return item?.let { buildPhotoPost(it, fallbackId) }
    }

    private fun buildPhotoPost(item: JSONObject, fallbackId: String): PhotoPost? {
        val images = item.getJSONObject("imagePost").getJSONArray("images")
        val urls = ArrayList<String>()
        for (i in 0 until images.length()) {
            val img = images.optJSONObject(i) ?: continue
            val list = img.optJSONObject("imageURL")?.optJSONArray("urlList")
                ?: img.optJSONObject("displayImage")?.optJSONArray("urlList")
                ?: continue
            val candidates = (0 until list.length()).map { list.getString(it) }
            val pick = candidates.firstOrNull { it.contains(".jpeg") || it.contains(".jpg") }
                ?: candidates.firstOrNull()
                ?: continue
            urls.add(pick)
        }
        if (urls.isEmpty()) {
            photoDebug = "لقيت imagePost بدون روابط صور"
            return null
        }
        photoDebug = "ok"
        return PhotoPost(item.optString("id", fallbackId), urls)
    }

    /**
     * يفتح البوست في WebView (يظهر تحت لو احتاج تحقق/كابتشا) وينتظر لين تظهر البيانات.
     */
    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun findPhotoPostWebView(url: String): PhotoPost? {
        photoDebug = ""
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.userAgentString = USER_AGENT
        wv.webViewClient = WebViewClient()
        wv.setOnTouchListener { v, _ ->
            v.parent?.requestDisallowInterceptTouchEvent(true)
            false
        }
        webContainer.removeAllViews()
        webContainer.addView(
            wv,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        webContainer.visibility = View.VISIBLE
        webView = wv
        wv.loadUrl(url)

        val fallbackId = url.substringBefore('?').trimEnd('/').substringAfterLast('/')
        try {
            var waited = 0L
            while (waited < 60_000L) {
                delay(1500)
                waited += 1500
                val raw = evalJs(wv, pageDataJs)
                if (raw.isNotEmpty()) {
                    val post = withContext(Dispatchers.Default) { postFromText(raw, fallbackId) }
                    if (post != null) return post
                }
                if (waited == 6000L) {
                    status.text = "إذا ظهر تحقق (كابتشا) في الصفحة تحت، حلّه وانتظر..."
                }
            }
            photoDebug = "انتهى الوقت بدون بيانات (تحقق/كابتشا؟)"
            return null
        } finally {
            destroyWebView()
        }
    }

    private suspend fun evalJs(wv: WebView, js: String): String =
        suspendCancellableCoroutine { cont ->
            wv.evaluateJavascript(js) { value ->
                val text = try {
                    if (value == null || value == "null") "" else (JSONTokener(value).nextValue() as? String) ?: ""
                } catch (e: Exception) {
                    ""
                }
                if (cont.isActive) cont.resume(text)
            }
        }

    private fun destroyWebView() {
        webView?.let {
            webContainer.removeView(it)
            it.stopLoading()
            it.destroy()
        }
        webView = null
        webContainer.visibility = View.GONE
    }

    /** يقرأ كتلة JSON من الصفحة (التسميات المعروفة لتيك توك) */
    private fun extractPageData(html: String): JSONObject? {
        for (id in listOf("__UNIVERSAL_DATA_FOR_REHYDRATION__", "SIGI_STATE", "__NEXT_DATA__")) {
            val marker = html.indexOf("id=\"$id\"")
            if (marker < 0) continue
            val start = html.indexOf('>', marker) + 1
            val end = html.indexOf("</script>", start)
            if (start <= 0 || end < 0) continue
            try {
                return JSONObject(html.substring(start, end))
            } catch (e: Exception) {
                // نجرب التالي
            }
        }
        return null
    }

    /** يطلع أول كائن JSON يجي بعد النص المعطى (مع تجاهل الأقواس داخل النصوص) */
    private fun extractJsonObjectAfter(text: String, key: String): JSONObject? {
        val at = text.indexOf(key)
        if (at < 0) return null
        val begin = text.indexOf('{', at + key.length)
        if (begin < 0) return null
        var depth = 0
        var inString = false
        var escaped = false
        var i = begin
        while (i < text.length) {
            val c = text[i]
            if (inString) {
                if (escaped) escaped = false
                else if (c == '\\') escaped = true
                else if (c == '"') inString = false
            } else {
                when (c) {
                    '"' -> inString = true
                    '{' -> depth++
                    '}' -> {
                        depth--
                        if (depth == 0) {
                            return try {
                                JSONObject(text.substring(begin, i + 1))
                            } catch (e: Exception) {
                                null
                            }
                        }
                    }
                }
            }
            i++
        }
        return null
    }

    /** يدور بشكل متداخل على الكائن اللي فيه imagePost.images */
    private fun findItemWithImages(node: Any?): JSONObject? {
        when (node) {
            is JSONObject -> {
                val images = node.optJSONObject("imagePost")?.optJSONArray("images")
                if (images != null && images.length() > 0) return node
                val keys = node.keys()
                while (keys.hasNext()) {
                    val found = findItemWithImages(node.opt(keys.next()))
                    if (found != null) return found
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    val found = findItemWithImages(node.opt(i))
                    if (found != null) return found
                }
            }
        }
        return null
    }

    private fun imageExtension(url: String): String {
        val path = Uri.parse(url).path ?: return "jpg"
        val ext = path.substringAfterLast('.', "jpg").lowercase()
        return when {
            ext == "jpeg" -> "jpg"
            ext.length in 2..4 -> ext
            else -> "jpg"
        }
    }

    private fun imageMime(ext: String): String = when (ext) {
        "webp" -> "image/webp"
        "png" -> "image/png"
        "heic" -> "image/heic"
        else -> "image/jpeg"
    }

    /** GET بسيط مع تتبع التحويلات وحفظ الكوكيز بين الطلبات */
    private fun httpGet(startUrl: String, referer: String?): HttpResult {
        var current = startUrl
        repeat(10) {
            val conn = URL(current).openConnection() as HttpURLConnection
            try {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.setRequestProperty("User-Agent", USER_AGENT)
                conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                if (referer != null) conn.setRequestProperty("Referer", referer)
                if (cookies.isNotEmpty()) {
                    conn.setRequestProperty("Cookie", cookies.entries.joinToString("; ") { "${it.key}=${it.value}" })
                }

                val code = conn.responseCode
                conn.headerFields
                    .filterKeys { it?.equals("set-cookie", ignoreCase = true) == true }
                    .values.flatten()
                    .forEach { header ->
                        val pair = header.substringBefore(';')
                        val name = pair.substringBefore('=').trim()
                        if (name.isNotEmpty()) cookies[name] = pair.substringAfter('=', "")
                    }

                if (code in 300..399) {
                    val location = conn.getHeaderField("Location") ?: throw IOException("redirect without location")
                    current = URL(URL(current), location).toString()
                } else {
                    if (code !in 200..299) throw IOException("HTTP $code")
                    return HttpResult(conn.inputStream.use { it.readBytes() }, current)
                }
            } finally {
                conn.disconnect()
            }
        }
        throw IOException("too many redirects")
    }

    private fun isTikTok(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        return host == "tiktok.com" || host.endsWith(".tiktok.com")
    }

    // ---------- أدوات مساعدة ----------

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString()
        val url = extractUrl(text)
        if (url != null) linkInput.setText(url) else status.text = "ما لقيت رابط في الحافظة"
    }

    private fun extractUrl(text: String?): String? = text?.let { urlRegex.find(it)?.value }

    private fun isSupported(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        return supportedDomains.any { host == it || host.endsWith(".$it") }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun busy(on: Boolean, determinate: Boolean = false) {
        progress.visibility = if (on) View.VISIBLE else View.GONE
        progress.isIndeterminate = !determinate
        progress.progress = 0
        downloadBtn.isEnabled = !on && ready
        updateBtn.isEnabled = !on
    }
}
