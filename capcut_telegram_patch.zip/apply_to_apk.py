#!/usr/bin/env python3
"""python3 apply_to_apk.py Capcut-v20_0_0.apk Capcut-clean-unsigned.apk
يبدّل classes.dex و classes40.dex المعدّلين داخل الـAPK ويحذف توقيع المعدّل القديم.
بعدها وقّع الملف (uber-apk-signer أو apksigner) وثبّته."""
import sys,zipfile,os
src,dst=sys.argv[1],sys.argv[2]
here=os.path.dirname(os.path.abspath(__file__))
rep={n:open(os.path.join(here,n),'rb').read() for n in('classes.dex','classes40.dex')}
with zipfile.ZipFile(src) as zi,zipfile.ZipFile(dst,'w',zipfile.ZIP_DEFLATED) as zo:
    for it in zi.infolist():
        n=it.filename
        if n.startswith('META-INF/') and n.upper().endswith(('.SF','.RSA','.DSA','.EC')) or n=='META-INF/MANIFEST.MF':
            continue
        if n in rep:
            zo.writestr(n,rep[n]);continue
        data=zi.read(n)
        zo.writestr(it,data,compress_type=it.compress_type)
print('done ->',dst,'(غير موقّع: وقّعه قبل التثبيت)')
