#!/system/bin/sh
# Freq Control root helper (1.12).
#  - applies per-cluster CPU min/max frequency through cpufreq sysfs (policy0/2/5/7 on SM8650)
#  - thermal guard: when a chosen sensor (hottest CPU core, AP, battery) reaches its limit it releases
#    the CPU limits first, then raises fcl_guard_tripped=1 so the SDHMS hook releases GPU/DDR as well
#  - "live" mode: streams temperatures + current frequencies for the app screen (only while the app is open)
# Usage: freqctl.sh start | stop | live     (the app and /data/adb/service.d call "start")

DIR=${FC_DIR:-/data/adb/freqctl}
CPUF=${FC_CPUF:-/sys/devices/system/cpu/cpufreq}
THERM=${FC_THERM:-/sys/class/thermal}
BATT=${FC_BATT:-/sys/class/power_supply/battery/temp}
CONF=$DIR/config
STAMP=$DIR/.loaded
PIDF=$DIR/run.pid

put() { settings put global "$1" "$2" >/dev/null 2>&1; }

# true when the pid in $1 is one of our own processes (the pid file survives reboots)
is_ours() {
  [ -n "$1" ] && [ -r "/proc/$1/cmdline" ] || return 1
  tr '\0' ' ' < "/proc/$1/cmdline" 2>/dev/null | grep -q freqctl
}

# sysfs temperature -> whole degrees C in N (-1 when unreadable). Handles milli-degrees, tenths, whole.
to_c() {
  N=-1
  case "$1" in ''|*[!0-9]*) return ;; esac
  if [ "$1" -ge 1000 ]; then N=$(($1 / 1000))
  elif [ "$1" -ge 200 ]; then N=$(($1 / 10))
  else N=$1; fi
}

# Finds the per-core CPU zones and the AP sensor. An override for AP can be put in $DIR/ap_path.
find_sensors() {
  CORE_Z=""; ANY=""; AP_F=""
  [ -r "$DIR/ap_path" ] && read AP_F < "$DIR/ap_path"
  for z in "$THERM"/thermal_zone*; do
    [ -r "$z/type" ] || continue
    t=""
    read t < "$z/type"
    case "$t" in
      *step*|cpuss*) ;;
      cpu-[0-9]*|cpu[0-9]*|apc*cpu*) CORE_Z="$CORE_Z $z/temp" ;;
      cpu*|gpu*) ANY="$ANY $z/temp" ;;
    esac
    if [ -z "$AP_F" ]; then
      case "$t" in
        ap-therm*|ap_therm*|*-ap-therm*|*_ap_therm*|sec-ap*|sec_ap*|AP|ap|AP_THERM) AP_F=$z/temp ;;
      esac
    fi
  done
  [ -n "$CORE_Z" ] || CORE_Z=$ANY
}

CORE=-1; AP=-1; BT=0
read_temps() {
  m=-1
  for f in $CORE_Z; do
    [ -r "$f" ] || continue
    v=""
    read v < "$f"
    to_c "$v"
    [ "$N" -gt "$m" ] && m=$N
  done
  CORE=$m
  AP=-1
  if [ -n "$AP_F" ] && [ -r "$AP_F" ]; then
    v=""
    read v < "$AP_F"
    to_c "$v"
    AP=$N
  fi
  b=""
  [ -r "$BATT" ] && read b < "$BATT"
  case "$b" in ''|*[!0-9]*) b=0 ;; esac
  BT=$((b / 10))
}

live_loop() {
  find_sensors
  while true; do
    read_temps
    line="L core=$CORE ap=$AP batt=$BT"
    for p in 0 2 5 7; do
      cf=0
      [ -r "$CPUF/policy$p/scaling_cur_freq" ] && read cf < "$CPUF/policy$p/scaling_cur_freq"
      line="$line f$p=${cf:-0}"
    done
    echo "$line" || exit 0
    sleep 1
  done
}

case "$1" in
  stop)
    if [ -f "$PIDF" ]; then
      pid=$(cat "$PIDF")
      is_ours "$pid" && kill "$pid" 2>/dev/null
      rm -f "$PIDF"
    fi
    exit 0 ;;
  live)
    live_loop
    exit 0 ;;
  run) ;;
  *)
    if [ -f "$PIDF" ]; then
      pid=$(cat "$PIDF")
      if is_ours "$pid" && kill -0 "$pid" 2>/dev/null; then
        kill -USR1 "$pid" 2>/dev/null   # wake it up: re-read the config right now
        exit 0
      fi
    fi
    if command -v setsid >/dev/null 2>&1; then
      setsid nohup sh "$0" run >/dev/null 2>&1 </dev/null &
    else
      nohup sh "$0" run >/dev/null 2>&1 </dev/null &
    fi
    exit 0 ;;
esac

# ---- daemon ---------------------------------------------------------------------------
mkdir -p "$DIR"
if [ -f "$PIDF" ]; then
  old=$(cat "$PIDF")
  if [ "$old" != "$$" ] && is_ours "$old" && kill -0 "$old" 2>/dev/null; then exit 0; fi
fi
# traps first, pid file second: once the pid file exists the app may send USR1 at any moment, and a
# shell that has no USR1 handler yet would simply be killed by it
SP=""
trap 'kill $SP 2>/dev/null; rm -f "$PIDF"; exit 0' TERM INT
RELOAD=1
trap 'RELOAD=1' USR1
echo $$ > "$PIDF"

rm -f "$DIR"/orig_*
up=${FC_UPTIME:-$(cut -d. -f1 /proc/uptime 2>/dev/null)}   # FC_UPTIME: for tests only
up=${up:-9999}
if [ "$up" -lt 180 ]; then
  # fresh boot: sysfs is back to defaults, forget what we applied; wait for the system and settings
  rm -f "$DIR"/applied_*
  until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 3; done
  sleep 25
fi

POLICIES=""
for d in "$CPUF"/policy*; do
  [ -d "$d" ] && POLICIES="$POLICIES ${d##*policy}"
done

BOOT=$(settings get global boot_count 2>/dev/null)
case "$BOOT" in ''|*[!0-9]*) BOOT=-1 ;; esac

# publish the frequency table of every cluster so the app can draw its slider
for p in $POLICIES; do
  d=$CPUF/policy$p
  tbl=""
  if [ -r "$d/scaling_available_frequencies" ]; then
    tbl=$(tr ' ' '\n' < "$d/scaling_available_frequencies" | grep -E '^[0-9]+$' | sort -n | tr '\n' ',' | sed 's/,$//')
  fi
  if [ -z "$tbl" ]; then
    a=""; b=""
    read a < "$d/cpuinfo_min_freq"
    read b < "$d/cpuinfo_max_freq"
    tbl="$a,$b"
  fi
  # real top frequency of each cluster (SM8650): the kernel table can hide the boost step
  case "$p" in
    0) TOP=2265600 ;;
    2) TOP=3148800 ;;
    5) TOP=2956800 ;;
    7) TOP=3398400 ;;
    *) TOP="" ;;
  esac
  if [ -n "$TOP" ]; then
    nt=""
    for f in $(echo "$tbl" | tr ',' ' '); do
      [ "$f" -lt "$TOP" ] && nt="$nt,$f"
    done
    tbl="${nt#,},$TOP"
    tbl=${tbl#,}
  fi
  lo=${tbl%%,*}
  hi=${tbl##*,}
  eval "LO_$p=$lo; HI_$p=$hi"
  put "fcl_cpu${p}_table" "$BOOT:$tbl"
  # a limit applied by an earlier run of this helper is still in sysfs: remember that, so it is undone later
  [ -f "$DIR/applied_$p" ] && eval "AP_$p=1"
done

find_sensors
{
  echo "core zones:$CORE_Z"
  echo "ap file: ${AP_F:-none}"
} > "$DIR/sensors.txt"
{
  for z in "$THERM"/thermal_zone*; do
    t=""; v=""
    [ -r "$z/type" ] && read t < "$z/type"
    [ -r "$z/temp" ] && read v < "$z/temp"
    echo "${z##*/} $t $v"
  done
} > "$DIR/zones.txt" 2>/dev/null

if sleep 0.01 2>/dev/null; then
  S_FAST=0.25; S_NEAR=0.5; S_MID=1; S_FAR=2
else
  S_FAST=1; S_NEAR=1; S_MID=1; S_FAR=2
fi

set_freq() { # policy min max
  d=$CPUF/policy$1
  cmin=""; cmax=""
  read cmin < "$d/scaling_min_freq"
  read cmax < "$d/scaling_max_freq"
  if [ "$cmin" != "$2" ] || [ "$cmax" != "$3" ]; then
    # max first so a higher min is accepted, then min, then max again for a lower max
    echo "$3" > "$d/scaling_max_freq"
    echo "$2" > "$d/scaling_min_freq"
    echo "$3" > "$d/scaling_max_freq"
  fi
}

# Back to the full range of the cluster. (Not to "what it was when we started": that value could be a
# throttled one and would leave the cluster stuck.) The kernel's own thermal limits are separate requests.
drop_policy() {
  eval "a=\$LO_$1; b=\$HI_$1"
  set_freq "$1" "$a" "$b"
  rm -f "$DIR/applied_$1"
  eval "AP_$1=0"
}

apply_policy() {
  p=$1
  [ -d "$CPUF/policy$p" ] || return
  eval "en=\${CPU${p}_EN:-0}; mn=\${CPU${p}_MIN:-0}; mx=\${CPU${p}_MAX:-0}; ap=\${AP_$p:-0}"
  if [ "$en" = 1 ] && [ "$mn" -gt 0 ] && [ "$mx" -ge "$mn" ]; then
    if [ "$TRIPPED" = 1 ]; then
      [ "$ap" = 1 ] && drop_policy "$p"
      st=guard_tripped
    else
      [ "$ap" = 1 ] || : > "$DIR/applied_$p"
      set_freq "$p" "$mn" "$mx"
      eval "AP_$p=1"
      st=active
    fi
  else
    [ "$ap" = 1 ] && drop_policy "$p"
    st=disabled
  fi
  eval "last=\${ST_$p:-}"
  if [ "$last" != "$st" ]; then
    put "fcl_cpu${p}_status" "$st"
    eval "ST_$p=$st"
  fi
}

apply_all() {
  for p in $POLICIES; do apply_policy "$p"; done
}

# sleep that a signal (USR1 from the app) cuts short
nap() {
  sleep "$1" &
  SP=$!
  wait "$SP" 2>/dev/null
  kill "$SP" 2>/dev/null
  SP=""
}

TRIPPED=0
put fcl_guard_tripped 0
rm -f "$DIR/tripped"

while true; do
  if [ "$RELOAD" = 1 ] || [ "$CONF" -nt "$STAMP" ]; then
    RELOAD=0
    [ -f "$CONF" ] && . "$CONF"
    : > "$STAMP"
  fi
  read_temps
  gc=${GUARD_CORE:-85}
  ga=${GUARD_AP:-50}
  gb=${GUARD_BATT:-45}

  hot=0      # some watched sensor is at its limit
  cool=1     # every watched sensor is back below its limit (with a margin)
  margin=99  # degrees left before the nearest limit (decides how fast we poll)
  if [ "${GUARD_EN:-1}" = 1 ]; then
    if [ "${GUARD_CORE_EN:-1}" = 1 ] && [ "$CORE" -ge 0 ]; then
      [ "$CORE" -ge "$gc" ] && hot=1
      [ "$CORE" -gt $((gc - 5)) ] && cool=0
      m=$((gc - CORE)); [ "$m" -lt "$margin" ] && margin=$m
    fi
    if [ "${GUARD_AP_EN:-0}" = 1 ] && [ "$AP" -ge 0 ]; then
      [ "$AP" -ge "$ga" ] && hot=1
      [ "$AP" -gt $((ga - 3)) ] && cool=0
      m=$((ga - AP)); [ "$m" -lt "$margin" ] && margin=$m
    fi
    if [ "$BT" -gt 0 ]; then
      [ "$BT" -ge "$gb" ] && hot=1
      [ "$BT" -gt $((gb - 2)) ] && cool=0
    fi
  fi

  want=$TRIPPED
  if [ "${GUARD_EN:-1}" != 1 ]; then
    want=0
  elif [ "$TRIPPED" = 0 ]; then
    [ "$hot" = 1 ] && want=1
  else
    [ "$cool" = 1 ] && want=0
  fi

  if [ "$want" != "$TRIPPED" ]; then
    TRIPPED=$want
    apply_all                          # CPU first: no waiting for the settings provider
    if [ "$TRIPPED" = 1 ]; then : > "$DIR/tripped"; else rm -f "$DIR/tripped"; fi
    put fcl_guard_tripped "$TRIPPED"   # then GPU / DDR / extras in SDHMS
  else
    apply_all
  fi

  if [ "$TRIPPED" = 1 ]; then s=$S_MID
  elif [ "$margin" -le 3 ]; then s=$S_FAST
  elif [ "$margin" -le 8 ]; then s=$S_NEAR
  elif [ "$margin" -le 15 ]; then s=$S_MID
  else s=$S_FAR
  fi
  nap "$s"
done
