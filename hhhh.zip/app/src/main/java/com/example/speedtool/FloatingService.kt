package com.example.speedtool

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var params: WindowManager.LayoutParams
    private val ui = Handler(Looper.getMainLooper())
    private var watchdog: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // السرعة بالأعداد الصحيحة: 0.2 .. 8.0 بخطوة 0.1 بدون تراكم أخطاء الكسور
    private fun speedOf(progress: Int) = (2 + progress) / 10.0
    private fun progressOf(speed: Double) = (Math.round(speed * 10).toInt() - 2).coerceIn(0, 78)

    /** خدمة أمامية: بدونها أندرويد يقتل الأيقونة العائمة بعد ما التطبيق يروح للخلفية. */
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Speed Tool", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
                      else Notification.Builder(this)
        val notif = builder
            .setContentTitle("Speed Tool")
            .setContentText("الأيقونة العائمة شغّالة")
            .setSmallIcon(android.R.drawable.ic_media_ff)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notif)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val bubble = TextView(this).apply {
            text = "⚡"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC1565C0.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }
        val panel = buildPanel()
        panel.visibility = View.GONE
        root.addView(bubble)
        root.addView(panel)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8); y = dp(120)
        }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = params.x; startY = params.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) moved = true
                    if (moved) {
                        params.x = startX + dx; params.y = startY + dy
                        wm.updateViewLayout(root, params)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        panel.visibility =
                            if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                    }
                }
            }
            true
        }
        wm.addView(root, params)
    }

    private fun buildPanel(): LinearLayout {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0xEE202124.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(dp(240), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        val title = TextView(this).apply {
            setTextColor(Color.LTGRAY); textSize = 11f
            text = Engine.pkg ?: "لم يتم اختيار تطبيق"
        }
        val label = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 18f
            text = "السرعة: x%.1f".format(java.util.Locale.US, Engine.speed)
        }
        val bar = SeekBar(this).apply {
            max = 78
            progress = progressOf(Engine.speed)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, pr: Int, u: Boolean) {
                    label.text = "السرعة: x%.1f".format(java.util.Locale.US, speedOf(pr))
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    Engine.setSpeed(speedOf(s?.progress ?: 0))
                }
            })
        }
        val status = TextView(this).apply { setTextColor(Color.GRAY); textSize = 10f }
        val toggle = Button(this)
        fun refresh() { toggle.text = if (Engine.running) "إيقاف" else "ابدأ التسريع" }
        refresh()
        toggle.setOnClickListener {
            if (Engine.running) {
                Engine.stop { status.text = "تم الإيقاف"; refresh() }
            } else {
                Engine.speed = speedOf(bar.progress)
                status.text = "جاري التشغيل..."
                Engine.start(applicationContext) { msg -> status.text = msg; refresh() }
            }
            refresh()
        }
        val close = Button(this).apply {
            text = "إغلاق الأيقونة"
            setOnClickListener { stopSelf() }
        }
        listOf(title, label, bar, toggle, status, close).forEach { p.addView(it) }

        // لو اللعبة أُغلقت يموت الحاقن؛ نكتشفه ونرجّع الواجهة وSELinux بدل ما نقول "شغّال" وهو ميّت
        val w = object : Runnable {
            override fun run() {
                if (Engine.running && System.currentTimeMillis() - Engine.startedAt > 8000) {
                    Engine.alive { ok ->
                        if (!ok && Engine.running) {
                            Engine.stop()
                            status.text = "الحاقن توقف (اللعبة أُغلقت؟). افتحها واضغط ابدأ من جديد."
                            refresh()
                        }
                    }
                }
                ui.postDelayed(this, 10000)
            }
        }
        watchdog = w
        ui.postDelayed(w, 10000)
        return p
    }

    override fun onDestroy() {
        watchdog?.let { ui.removeCallbacks(it) }
        if (Engine.running) Engine.stop()          // يرجّع السرعة وSELinux
        try { wm.removeView(root) } catch (e: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "speedtool_overlay"
    }
}
