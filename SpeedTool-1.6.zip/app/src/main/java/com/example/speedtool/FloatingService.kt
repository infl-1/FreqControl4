package com.example.speedtool

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.util.Locale

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var bubble: BubbleView
    private lateinit var upBtn: ArrowView
    private lateinit var downBtn: ArrowView
    private lateinit var panel: MaxHeightScroll
    private lateinit var speedLabel: TextView
    private lateinit var bar: SeekBar
    private lateinit var status: TextView
    private lateinit var toggle: TextView

    private val ui = Handler(Looper.getMainLooper())
    private var watchdog: Runnable? = null
    private var arrowsShown = false
    private var shift = 0
    private var lastCommit = 0L
    private var refreshAll: () -> Unit = {}

    // إرسال السرعة للحاقن: مرة كل 250ms كحد أقصى (كل إرسال يشغّل su)
    private val commit = Runnable {
        lastCommit = SystemClock.uptimeMillis()
        Engine.updateSpeed(Engine.speed)
    }
    private val hideArrowsRun = Runnable { hideArrows() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_QUIT) Engine.quitAll(applicationContext)
        return START_NOT_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // السرعة من 0.01 إلى 100 (الشريط لوغاريتمي: يغطي القيم الصغيرة والكبيرة بنفس الدقة)
    private fun roundSpeed(v: Double): Double {
        val c = v.coerceIn(MIN_SPEED, MAX_SPEED)
        return if (c < 1.0) Math.round(c * 100) / 100.0 else Math.round(c * 10) / 10.0
    }
    private fun speedOf(progress: Int) =
        roundSpeed(MIN_SPEED * Math.pow(10.0, 4.0 * progress / BAR_MAX))
    private fun progressOf(speed: Double) =
        Math.round(Math.log10(speed.coerceIn(MIN_SPEED, MAX_SPEED) / MIN_SPEED) / 4.0 * BAR_MAX).toInt()
            .coerceIn(0, BAR_MAX)
    private fun fmtSpeed(v: Double) = when {
        v < 1.0 -> String.format(Locale.US, "%.2fx", v)
        v < 100.0 -> String.format(Locale.US, "%.1fx", v)
        else -> String.format(Locale.US, "%.0fx", v)
    }
    // حجم الخطوة حسب القيمة: صغيرة تحت 0.2، ثم 0.1، ثم 1.0 فوق 10
    private fun stepFor(v: Double, dir: Int): Double {
        val eps = 1e-9
        return when {
            v < 0.2 - eps || (dir < 0 && v <= 0.2 + eps) -> 0.01
            v < 10.0 - eps || (dir < 0 && v <= 10.0 + eps) -> 0.1
            else -> 1.0
        }
    }

    /** خدمة أمامية: بدونها أندرويد يقتل الأيقونة العائمة بعد ما التطبيق يروح للخلفية. */
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Speed Tool", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val quitIntent = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingService::class.java).setAction(ACTION_QUIT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val quitAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "إيقاف التطبيق", quitIntent
        ).build()
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
                      else Notification.Builder(this)
        val notif = builder
            .setContentTitle("Speed Tool")
            .setContentText("الأيقونة العائمة شغّالة")
            .setSmallIcon(android.R.drawable.ic_media_ff)
            .setOngoing(true)
            .addAction(quitAction)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notif)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        upBtn = ArrowView(this, true).apply { visibility = View.GONE }
        downBtn = ArrowView(this, false).apply { visibility = View.GONE }
        bubble = BubbleView(this).apply { speedText = fmtSpeed(Engine.speed) }
        head.addView(upBtn, LinearLayout.LayoutParams(dp(40), dp(40)).apply { bottomMargin = dp(6) })
        head.addView(bubble, LinearLayout.LayoutParams(dp(60), dp(60)))
        head.addView(downBtn, LinearLayout.LayoutParams(dp(40), dp(40)).apply { topMargin = dp(6) })

        buildPanel()
        panel.visibility = View.GONE

        root.addView(head, LinearLayout.LayoutParams(WRAP, WRAP))
        root.addView(panel, LinearLayout.LayoutParams(dp(268), WRAP).apply { topMargin = dp(8) })

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8); y = dp(140)
        }

        // لمسة: سحب = تحريك | ضغطة = فتح/إغلاق اللوحة | ضغط مطوّل = ظهور سهمين (أسرع/أبطأ)
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var moved = false; var longPressed = false
        val longPress = Runnable {
            longPressed = true
            bubble.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            showArrows()
        }
        bubble.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = params.x; startY = params.y
                    moved = false; longPressed = false
                    ui.postDelayed(longPress, 450)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (!moved && (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8))) {
                        moved = true
                        ui.removeCallbacks(longPress)
                    }
                    if (moved) {
                        params.x = startX + dx; params.y = startY + dy
                        updateRoot()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    ui.removeCallbacks(longPress)
                    if (!moved && !longPressed) togglePanel()
                }
                MotionEvent.ACTION_CANCEL -> ui.removeCallbacks(longPress)
            }
            true
        }

        // السهمين: ضغطة = 0.1، وإذا بقيت ضاغط يتكرر ويتسارع
        attachRepeat(upBtn, +1, true) { upBtn.down = it; upBtn.invalidate() }
        attachRepeat(downBtn, -1, true) { downBtn.down = it; downBtn.invalidate() }

        wm.addView(root, params)
        refreshAll()
    }

    // ---------------------------------------------------------------- السرعة

    private fun applySpeed(v: Double, fromBar: Boolean = false) {
        val sp = roundSpeed(v)
        Engine.speed = sp
        val t = fmtSpeed(sp)
        bubble.speedText = t
        bubble.invalidate()
        speedLabel.text = t
        if (!fromBar) bar.progress = progressOf(sp)
        ui.removeCallbacks(commit)
        val wait = (lastCommit + 250 - SystemClock.uptimeMillis()).coerceAtLeast(0)
        ui.postDelayed(commit, wait)
    }

    // كل ما طوّلت الضغط تكبر الخطوة
    private fun mult(count: Int) = when {
        count > 50 -> 10.0
        count > 30 -> 5.0
        count > 14 -> 2.0
        else -> 1.0
    }

    private fun attachRepeat(v: View, dir: Int, consume: Boolean, onPress: (Boolean) -> Unit = {}) {
        var count = 0
        val rep = object : Runnable {
            override fun run() {
                count++
                applySpeed(Engine.speed + dir * stepFor(Engine.speed, dir) * mult(count))
                armHide()
                ui.postDelayed(this, 90)
            }
        }
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    count = 0
                    onPress(true)
                    applySpeed(Engine.speed + dir * stepFor(Engine.speed, dir))
                    armHide()
                    ui.postDelayed(rep, 420)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(rep)
                    onPress(false)
                    armHide()
                }
            }
            consume
        }
    }

    // ---------------------------------------------------------------- الأسهم واللوحة

    private fun updateRoot() {
        try { wm.updateViewLayout(root, params) } catch (e: Exception) {}
    }

    private fun arrowSpace() = dp(46)

    private fun showArrows() {
        if (!arrowsShown) {
            arrowsShown = true
            upBtn.visibility = View.VISIBLE
            downBtn.visibility = View.VISIBLE
            // نرفع النافذة بمقدار السهم العلوي عشان الأيقونة تبقى مكانها
            val newY = (params.y - arrowSpace()).coerceAtLeast(0)
            shift = params.y - newY
            params.y = newY
            updateRoot()
        }
        armHide()
    }

    private fun hideArrows() {
        if (!arrowsShown) return
        arrowsShown = false
        upBtn.visibility = View.GONE
        downBtn.visibility = View.GONE
        params.y += shift
        shift = 0
        updateRoot()
    }

    private fun armHide() {
        if (!arrowsShown) return
        ui.removeCallbacks(hideArrowsRun)
        ui.postDelayed(hideArrowsRun, 4000)
    }

    private fun togglePanel() {
        panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        fitOnScreen()
    }

    /** لو اللوحة طلعت تحت الشاشة نرفع النافذة. */
    private fun fitOnScreen() {
        root.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val maxY = resources.displayMetrics.heightPixels - root.measuredHeight - dp(8)
        if (params.y > maxY) {
            params.y = maxY.coerceAtLeast(0)
            updateRoot()
        }
    }

    // ---------------------------------------------------------------- عناصر الواجهة

    private fun tv(text: String, size: Float = 13f, color: Int = Theme.TEXT, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun pill(
        text: String, bg: Int, fg: Int = Color.WHITE, size: Float = 13f,
        strokeColor: Int = 0, radiusDp: Int = 12
    ): TextView {
        val r = dp(radiusDp).toFloat()
        return tv(text, size, fg, true).apply {
            gravity = Gravity.CENTER
            isClickable = true
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = withRipple(rounded(bg, r, if (strokeColor != 0) dp(1) else 0, strokeColor), r)
        }
    }

    private fun stepBtn(sym: String, dir: Int): TextView {
        val b = pill(sym, Theme.SURFACE2, Theme.TEXT, 22f, 0x4400E5FF, 24)
        attachRepeat(b, dir, false)
        return b
    }

    private fun appRow(a: Engine.App, onClick: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(7), dp(10), dp(7))
            isClickable = true
            background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null, ColorDrawable(Color.WHITE))
            setOnClickListener { onClick() }
        }
        val img = ImageView(this).apply { if (a.icon != null) setImageDrawable(a.icon) }
        row.addView(img, LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(10) })
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(tv(a.label, 13f, Theme.TEXT, true).apply { maxLines = 1 })
        texts.addView(tv(a.pkg, 10f, Theme.MUTED).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
        })
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (a.running) row.addView(tv("● شغّال", 10f, Theme.GREEN, true))
        return row
    }

    private fun buildPanel() {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Theme.BG_TOP, Theme.BG_BOTTOM)
            ).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), 0x4400E5FF)
            }
        }

        // ---- العنوان
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(tv("⚡ Speed Tool", 16f, Theme.TEXT, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(tv("✕", 16f, Theme.MUTED, true).apply {
            setPadding(dp(10), dp(4), dp(4), dp(4))
            setOnClickListener { panel.visibility = View.GONE }
        })
        card.addView(header)

        // كل محتوى اللوحة (ما عدا العنوان) داخل mainBox، وقائمة التطبيقات صفحة منفصلة pickerBox
        val mainBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(mainBox, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- اختيار التطبيق
        val appIcon = ImageView(this).apply { visibility = View.GONE }
        val appName = tv("اختر اللعبة", 14f, Theme.TEXT, true).apply { maxLines = 1 }
        val appPkg = tv("اضغط لعرض التطبيقات الشغالة", 10f, Theme.MUTED).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
        }
        val appTexts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(appName)
            addView(appPkg)
        }
        val appCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = withRipple(rounded(Theme.SURFACE, dp(14).toFloat(), dp(1), 0x2200E5FF), dp(14).toFloat())
            addView(appIcon, LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(10) })
            addView(appTexts, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(tv("▾", 16f, Theme.CYAN, true))
        }
        mainBox.addView(appCard, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

        val listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Theme.SURFACE, dp(12).toFloat())
        }
        val pickerTitle = tv("اختر اللعبة", 14f, Theme.TEXT, true)
        val backBtn = pill("رجوع", Theme.SURFACE2, Theme.TEXT, 12f, 0, 10)
        val pickerHead = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(pickerTitle, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(backBtn, LinearLayout.LayoutParams(WRAP, WRAP))
        }
        val pickerBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            addView(pickerHead, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
            addView(listBox, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        }
        card.addView(pickerBox, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- عرض السرعة + - +
        speedLabel = tv(fmtSpeed(Engine.speed), 34f, Theme.CYAN, true).apply { gravity = Gravity.CENTER }
        val speedRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(stepBtn("−", -1), LinearLayout.LayoutParams(dp(48), dp(48)))
            addView(speedLabel, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(stepBtn("+", +1), LinearLayout.LayoutParams(dp(48), dp(48)))
        }
        mainBox.addView(speedRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        bar = SeekBar(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            max = BAR_MAX
            progress = progressOf(Engine.speed)
            progressTintList = ColorStateList.valueOf(Theme.CYAN)
            thumbTintList = ColorStateList.valueOf(Theme.CYAN)
            progressBackgroundTintList = ColorStateList.valueOf(0x33FFFFFF)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, pr: Int, u: Boolean) {
                    if (u) applySpeed(speedOf(pr), true)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        mainBox.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })

        // ---- قيم جاهزة
        val presets = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        listOf(0.5, 1.0, 2.0, 5.0, 10.0).forEach { v ->
            val chip = pill(fmtSpeed(v), Theme.SURFACE, Theme.TEXT, 12f, 0x2200E5FF, 10)
            chip.setPadding(dp(2), dp(7), dp(2), dp(7))
            chip.setOnClickListener { applySpeed(v) }
            presets.addView(chip, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                marginStart = dp(3); marginEnd = dp(3)
            })
        }
        mainBox.addView(presets, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        // ---- الوضع (تلقائي / ساعة النظام)
        val modeAuto = pill("تلقائي · Unity", 0, Theme.MUTED, 12f, 0, 10)
        val modeLibc = pill("ساعة النظام", 0, Theme.MUTED, 12f, 0, 10)
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            background = rounded(Theme.SURFACE, dp(13).toFloat())
            addView(modeAuto, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(modeLibc, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        mainBox.addView(modeRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

        fun styleModes() {
            val r = dp(10).toFloat()
            val libc = Engine.mode == "libc"
            modeAuto.background = withRipple(rounded(if (!libc) Theme.PURPLE else 0, r), r)
            modeAuto.setTextColor(if (!libc) Color.WHITE else Theme.MUTED)
            modeLibc.background = withRipple(rounded(if (libc) Theme.PURPLE else 0, r), r)
            modeLibc.setTextColor(if (libc) Color.WHITE else Theme.MUTED)
        }

        fun showApp(pkg: String?, labelOverride: String? = null, icon: Drawable? = null) {
            if (pkg == null) {
                appName.text = "اختر اللعبة"
                appPkg.text = "اضغط لعرض التطبيقات الشغالة"
                appIcon.visibility = View.GONE
                return
            }
            val pm = packageManager
            val lbl = labelOverride ?: try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) { pkg }
            val ic = icon ?: try { pm.getApplicationIcon(pkg) } catch (e: Exception) { null }
            appName.text = lbl
            appPkg.text = pkg
            if (ic != null) {
                appIcon.setImageDrawable(ic)
                appIcon.visibility = View.VISIBLE
            } else {
                appIcon.visibility = View.GONE
            }
        }

        // ---- زر التشغيل
        toggle = pill("ابدأ التسريع", Theme.GREEN, Theme.DARK, 15f, 0, 14)
        toggle.setPadding(dp(8), dp(13), dp(8), dp(13))
        mainBox.addView(toggle, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        fun refresh() {
            val on = Engine.running
            val r = dp(14).toFloat()
            toggle.text = if (on) "إيقاف التسريع" else "ابدأ التسريع"
            toggle.background = withRipple(rounded(if (on) Theme.RED else Theme.GREEN, r), r)
            toggle.setTextColor(if (on) Color.WHITE else Theme.DARK)
            bubble.active = on
            bubble.invalidate()
        }
        refreshAll = { refresh() }

        status = tv("", 11f, Theme.MUTED).apply { setPadding(dp(2), dp(8), dp(2), 0) }
        mainBox.addView(status, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- أسفل: إغلاق الأيقونة + إيقاف التطبيق
        val closeIcon = pill("إغلاق الأيقونة", Theme.SURFACE, Theme.MUTED, 12f, 0x33FFFFFF, 12)
        val quit = pill("⏻  إيقاف التطبيق", 0x33FF5252, Theme.RED, 12f, 0x88FF5252.toInt(), 12)
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(closeIcon, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(4) })
            addView(quit, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(4) })
        }
        mainBox.addView(footer, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

        // ---- السلوك
        fun showPicker(on: Boolean) {
            pickerBox.visibility = if (on) View.VISIBLE else View.GONE
            mainBox.visibility = if (on) View.GONE else View.VISIBLE
            fitOnScreen()
        }
        backBtn.setOnClickListener { showPicker(false) }

        fun choose(a: Engine.App) {
            showPicker(false)
            if (Engine.isBlocked(a.pkg)) {
                status.text = "هذا تطبيق أونلاين وفيه حظر للحسابات، الأداة ترفض تشتغل عليه."
                fitOnScreen()
                return
            }
            if (Engine.running) Engine.stop()
            Engine.pkg = a.pkg
            Engine.mode = Engine.modeFor(applicationContext, a.pkg)
            styleModes()
            showApp(a.pkg, a.label, a.icon)
            status.text = "تم اختيار: " + a.pkg
            refresh()
            fitOnScreen()
        }

        fun setMode(m: String) {
            val pk = Engine.pkg
            if (Engine.running) {
                status.text = "أوقف التسريع أول، ثم غيّر الوضع"
                return
            }
            Engine.mode = m
            if (pk != null) Engine.saveMode(applicationContext, pk, m)
            styleModes()
            status.text = "الوضع يتطبق عند الضغط على ابدأ التسريع"
        }
        modeAuto.setOnClickListener { setMode("auto") }
        modeLibc.setOnClickListener { setMode("libc") }

        appCard.setOnClickListener {
            status.text = "جاري تحميل القائمة..."
            Engine.listApps(applicationContext) { apps ->
                listBox.removeAllViews()
                if (apps.isEmpty()) {
                    status.text = "ما لقيت تطبيقات (تأكد من الروت)"
                    fitOnScreen()
                } else {
                    apps.forEach { a -> listBox.addView(appRow(a) { choose(a) }) }
                    val n = apps.count { it.running }
                    pickerTitle.text = "اختر اللعبة · $n شغّال من ${apps.size}"
                    status.text = ""
                    showPicker(true)
                }
            }
        }

        toggle.setOnClickListener {
            if (Engine.running) {
                Engine.stop { status.text = "تم الإيقاف"; refresh() }
            } else {
                status.text = "جاري التشغيل..."
                Engine.start(applicationContext) { msg -> status.text = msg; refresh() }
            }
            refresh()
        }
        closeIcon.setOnClickListener { stopSelf() }
        quit.setOnClickListener { Engine.quitAll(applicationContext) }

        // حالة البداية
        val pk0 = Engine.pkg
        if (pk0 != null) Engine.mode = Engine.modeFor(applicationContext, pk0)
        styleModes()
        showApp(pk0)
        refresh()

        // لو اللعبة أُغلقت يموت الحاقن؛ نكتشفه ونرجّع الواجهة وSELinux بدل ما نقول "شغّال" وهو ميّت
        val w = object : Runnable {
            override fun run() {
                if (Engine.running && System.currentTimeMillis() - Engine.startedAt > 8000) {
                    Engine.alive { ok ->
                        if (!ok && Engine.running) {
                            Engine.stop()
                            status.text = "الحاقن توقف (اللعبة أُغلقت؟). افتحها واضغط ابدأ من جديد."
                            refresh()
                        }
                    }
                }
                ui.postDelayed(this, 10000)
            }
        }
        watchdog = w
        ui.postDelayed(w, 10000)

        panel = MaxHeightScroll(this, (resources.displayMetrics.heightPixels * 0.7).toInt()).apply {
            isVerticalScrollBarEnabled = false
            addView(card, ViewGroup.LayoutParams(MATCH, WRAP))
        }
    }

    override fun onDestroy() {
        watchdog?.let { ui.removeCallbacks(it) }
        ui.removeCallbacksAndMessages(null)
        if (Engine.running) Engine.stop()          // يرجّع السرعة وSELinux
        try { wm.removeView(root) } catch (e: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "speedtool_overlay"
        const val ACTION_QUIT = "com.example.speedtool.QUIT"
        private const val MIN_SPEED = 0.01
        private const val MAX_SPEED = 100.0
        private const val BAR_MAX = 1000
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }
}
