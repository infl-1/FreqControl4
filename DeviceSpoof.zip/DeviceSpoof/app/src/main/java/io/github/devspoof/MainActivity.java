package io.github.devspoof;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/**
 * Changes the product properties the system reports (ro.product.model and friends) through root
 * (resetprop). The change lives in memory only: a normal reboot brings the real values back.
 * The original values are saved the first time, so "Restore" can put them back without rebooting.
 */
public class MainActivity extends Activity {
    private static final String[] SUFFIXES = {"", ".system", ".vendor", ".odm", ".product", ".system_ext"};
    private static final String PREFIX = "o_";
    private static final Pattern SAFE = Pattern.compile("[A-Za-z0-9 ._+\\-]{1,64}");

    // finds resetprop for Magisk, KernelSU and APatch
    private static final String FIND_RP =
            "RP=$(command -v resetprop); "
                    + "[ -n \"$RP\" ] || for f in /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop "
                    + "/data/adb/ap/bin/resetprop; do [ -x \"$f\" ] && RP=$f && break; done; "
                    + "[ -n \"$RP\" ] || { echo NO_RESETPROP; exit 127; }; ";

    private SharedPreferences prefs;
    private EditText model;
    private EditText market;
    private EditText device;
    private TextView out;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("spoof", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        root.addView(text("تغيير خصائص الجهاز (مؤقت)", 22, true));
        root.addView(text("يحتاج روت. يرجع للأصل بعد إعادة التشغيل أو بزر الاسترجاع.", 14, false));

        root.addView(label("الموديل (ro.product.model)"));
        model = field("SM-S948B");
        root.addView(model);

        root.addView(label("الاسم التجاري (marketname)"));
        market = field("Galaxy S26 Ultra");
        root.addView(market);

        root.addView(label("اسم الجهاز الداخلي codename (اختياري، فاضي = بدون تغيير)"));
        device = field("");
        root.addView(device);

        root.addView(button("تفعيل", v -> apply()));
        root.addView(button("استرجاع القيم الأصلية", v -> restore()));
        root.addView(button("إعادة تشغيل ناعمة (تطبيق على الألعاب)", v -> confirmSoftRestart()));
        root.addView(button("تحديث الحالة", v -> refresh()));

        out = text("", 14, false);
        out.setTypeface(Typeface.MONOSPACE);
        root.addView(out);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
        refresh();
    }

    // ---- actions -------------------------------------------------------------------------

    private void apply() {
        String m = model.getText().toString().trim();
        String k = market.getText().toString().trim();
        String d = device.getText().toString().trim();
        for (String v : new String[]{m, k, d}) {
            if (!v.isEmpty() && !SAFE.matcher(v).matches()) {
                show("قيمة غير مسموحة: حروف إنجليزية وأرقام ومسافة و . _ + - فقط (حتى 64).");
                return;
            }
        }
        final StringBuilder cmd = new StringBuilder(FIND_RP);
        final SharedPreferences.Editor ed = prefs.edit();
        int changed = 0;
        String[][] wanted = {{"model", m}, {"marketname", k}, {"device", d}};
        for (String[] w : wanted) {
            if (w[1].isEmpty()) {
                continue;
            }
            for (String suffix : SUFFIXES) {
                String key = "ro.product" + suffix + "." + w[0];
                String current = getprop(key);
                if (current.isEmpty()) {
                    continue; // only touch properties that exist on this phone
                }
                if (!prefs.contains(PREFIX + key)) {
                    ed.putString(PREFIX + key, current); // keep the REAL value, never overwrite it later
                }
                cmd.append("\"$RP\" -n ").append(quote(key)).append(' ').append(quote(w[1])).append("; ");
                changed++;
            }
        }
        if (changed == 0) {
            show("ما لقيت خصائص أغيّرها.");
            return;
        }
        ed.commit();
        final int n = changed;
        runRoot(cmd.toString(), result -> {
            if (result.contains("NO_RESETPROP")) {
                show("ما لقيت resetprop. تأكد إن الروت (Magisk / KernelSU / APatch) شغال.");
            } else {
                show("تم تغيير " + n + " خاصية.\nالألعاب تقرأ الموديل عند تشغيل نظام التطبيقات، "
                        + "فاضغط «إعادة تشغيل ناعمة» ثم افتح اللعبة.");
            }
        });
    }

    private void restore() {
        final StringBuilder cmd = new StringBuilder(FIND_RP);
        final SharedPreferences.Editor ed = prefs.edit();
        int n = 0;
        for (Map.Entry<String, ?> e : prefs.getAll().entrySet()) {
            if (e.getKey().startsWith(PREFIX) && e.getValue() instanceof String) {
                String key = e.getKey().substring(PREFIX.length());
                cmd.append("\"$RP\" -n ").append(quote(key)).append(' ').append(quote((String) e.getValue())).append("; ");
                ed.remove(e.getKey());
                n++;
            }
        }
        if (n == 0) {
            show("ما فيه قيم محفوظة. الجهاز على وضعه الأصلي.");
            return;
        }
        final int count = n;
        runRoot(cmd.toString(), result -> {
            if (result.contains("NO_RESETPROP")) {
                show("ما لقيت resetprop، ما انسترجع شي.");
            } else {
                ed.commit();
                show("انسترجعت " + count + " خاصية. اعمل إعادة تشغيل ناعمة عشان تتحدث التطبيقات.");
            }
        });
    }

    private void confirmSoftRestart() {
        new AlertDialog.Builder(this)
                .setTitle("إعادة تشغيل ناعمة")
                .setMessage("تقفل كل التطبيقات وتعيد تشغيل الواجهة (مثل إعادة تشغيل سريعة). متأكد؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("نعم", (d, w) -> runRoot("setprop ctl.restart zygote", r -> { }))
                .show();
    }

    private void refresh() {
        StringBuilder sb = new StringBuilder();
        sb.append("الموديل الحالي: ").append(getprop("ro.product.model")).append('\n');
        sb.append("الاسم التجاري: ").append(getprop("ro.product.marketname")).append('\n');
        sb.append("الجهاز: ").append(getprop("ro.product.device")).append('\n');
        int saved = 0;
        for (String key : prefs.getAll().keySet()) {
            if (key.startsWith(PREFIX)) {
                saved++;
            }
        }
        sb.append(saved > 0 ? "\nالتغيير مفعّل (" + saved + " خاصية محفوظة الأصل)." : "\nالقيم أصلية.");
        out.setText(sb.toString());
    }

    // ---- helpers -------------------------------------------------------------------------

    private interface Done {
        void onResult(String output);
    }

    /** Runs a command as root on a background thread, then reports on the UI thread. */
    private void runRoot(final String command, final Done done) {
        show("...");
        new Thread(() -> {
            String result;
            try {
                Process p = new ProcessBuilder("su", "-c", command).redirectErrorStream(true).start();
                StringBuilder sb = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        sb.append(line).append('\n');
                    }
                }
                if (!p.waitFor(20, TimeUnit.SECONDS)) {
                    p.destroyForcibly();
                    sb.append("TIMEOUT");
                }
                result = sb.toString();
            } catch (Exception e) {
                result = "NO_ROOT: " + e.getMessage();
            }
            final String finalResult = result;
            runOnUiThread(() -> {
                if (finalResult.startsWith("NO_ROOT")) {
                    show("ما قدرت أشغل su. اعطِ التطبيق صلاحية الروت.");
                } else {
                    done.onResult(finalResult);
                }
                refresh();
            });
        }).start();
    }

    private void show(String message) {
        out.setText(message);
    }

    private static String getprop(String key) {
        try {
            Process p = new ProcessBuilder("getprop", key).redirectErrorStream(true).start();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line = r.readLine();
                p.waitFor();
                return line == null ? "" : line.trim();
            }
        } catch (Exception e) {
            return "";
        }
    }

    private static String quote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setPadding(0, dp(6), 0, dp(6));
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 13, false);
        t.setPadding(0, dp(14), 0, 0);
        return t;
    }

    private EditText field(String initial) {
        EditText e = new EditText(this);
        e.setText(initial);
        e.setSingleLine(true);
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        return e;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }
}
