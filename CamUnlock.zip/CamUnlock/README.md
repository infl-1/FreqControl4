# CamUnlock
LSPosed module (scope: com.sec.android.app.camera) that forces selected SUPPORT_* flags to true.
Built against the camera build 17.0.00.43 (obfuscated class names e5.d / e5.g / e5.f).

Build: push to GitHub, Actions builds the APK (artifact CamUnlock-apk), or open in Android Studio.
Install, enable in LSPosed for "Camera", force-stop the camera, reopen.
Log line on success: "CamUnlock: hooked OK".
