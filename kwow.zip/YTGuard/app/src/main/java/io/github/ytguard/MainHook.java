package io.github.ytguard;

import android.content.Context;
import android.content.pm.PackageInfo;

import java.util.List;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * YouTube-only LSPosed module.
 *
 * Features that exist so far (each one was located by analysing the stock
 * YouTube 21.41.526 dex files, see tools/ and COMPAT_REPORT.md):
 *   1. Hide the "Get Premium" upsell view.
 *   2. Block the video-ad trigger handler.
 *   3. Allow background playback (keep playing when leaving the app / screen off).
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String YOUTUBE = "com.google.android.youtube";

    /** Obfuscated names below are only valid for this exact build. */
    private static final String VERIFIED_VERSION = "21.41.526";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!YOUTUBE.equals(lp.packageName)) return;

        ClassLoader cl = lp.classLoader;
        String version = versionOf(lp.packageName);
        log("YouTube version = " + version);

        run("hide-get-premium", () -> hideGetPremium(cl));

        if (VERIFIED_VERSION.equals(version)) {
            run("block-video-ads", () -> blockVideoAds(cl));
            run("background-playback", () -> enableBackgroundPlayback(cl));
        } else {
            log("block-video-ads skipped: obfuscated names are only verified for " + VERIFIED_VERSION);
        }
    }

    /** CompactYpcOfferModuleView is not obfuscated, so this hook is version-independent. */
    private static void hideGetPremium(ClassLoader cl) {
        XposedHelpers.findAndHookMethod(
                "com.google.android.apps.youtube.app.red.presenter.CompactYpcOfferModuleView",
                cl, "onMeasure", int.class, int.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        XposedHelpers.callMethod(param.thisObject, "setMeasuredDimension", 0, 0);
                    }
                });
    }

    /**
     * acve.t(List) is the ad slot trigger handler. It is the method that contains the strings
     * "TriggerBundle doesn't have the required metadata ..." and "Ping migration no associated ...".
     * Turning it into a no-op stops video ad slots from being entered.
     */
    private static void blockVideoAds(ClassLoader cl) {
        XposedHelpers.findAndHookMethod("acve", cl, "t", List.class, XC_MethodReplacement.DO_NOTHING);
    }

    /**
     * arkm.s(bgtc) is the gate that decides whether the current video may keep playing in the
     * background. It reads a flag (0x800) on the player response, compares a oneof case id
     * (64657230) and finally returns a boolean field; returning true always allows background playback.
     */
    private static void enableBackgroundPlayback(ClassLoader cl) {
        XposedHelpers.findAndHookMethod("arkm", cl, "s", "bgtc", new XC_MethodReplacement() {
            @Override
            protected Object replaceHookedMethod(MethodHookParam param) {
                return Boolean.TRUE;
            }
        });
    }

    // ------------------------------------------------------------------

    private interface Task { void run() throws Throwable; }

    private static void run(String name, Task task) {
        try {
            task.run();
            log(name + ": hooked");
        } catch (Throwable t) {
            log(name + ": FAILED -> " + t);
        }
    }

    private static String versionOf(String pkg) {
        try {
            Object at = XposedHelpers.callStaticMethod(
                    XposedHelpers.findClass("android.app.ActivityThread", null), "currentActivityThread");
            Context ctx = (Context) XposedHelpers.callMethod(at, "getSystemContext");
            PackageInfo pi = ctx.getPackageManager().getPackageInfo(pkg, 0);
            return pi.versionName;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void log(String msg) {
        XposedBridge.log("[YTGuard] " + msg);
    }
}
