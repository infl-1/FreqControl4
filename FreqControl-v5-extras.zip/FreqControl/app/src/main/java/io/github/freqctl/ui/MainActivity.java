package io.github.freqctl.ui;

import android.content.ContentResolver;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.ContentObserver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.github.freqctl.Domain;
import io.github.freqctl.FreqTable;
import io.github.freqctl.R;
import io.github.freqctl.RootControl;
import io.github.freqctl.SettingsAccess;
import io.github.freqctl.extras.ExtraSettings;
import io.github.freqctl.extras.SdhmsExtras;

public class MainActivity extends AppCompatActivity implements DomainCard.Listener, GuardCard.Listener, ExtrasCard.Listener {
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Map<Domain, DomainCard> cards = new EnumMap<>(Domain.class);

    private GuardCard guardCard;
    private ExtrasCard extrasCard;
    private ActivityResultLauncher<String[]> iconPicker;
    private ActivityResultLauncher<String[]> animPicker;
    private TextView accessText;
    private ContentObserver observer;
    /** Writes in progress; the screen is not refreshed from half-written settings meanwhile. */
    private int writesInFlight;
    /** The root helper is installed once per app process; later checks only make sure it is running. */
    private static boolean helperInstalled;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        accessText = findViewById(R.id.access_status);
        accessText.setText(R.string.access_checking);
        guardCard = new GuardCard(findViewById(R.id.card_guard), this);
        extrasCard = new ExtrasCard(findViewById(R.id.card_extras), this);
        iconPicker = registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::saveFingerprintIcon);
        animPicker = registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::saveFingerprintAnimation);

        LinearLayout container = findViewById(R.id.cards_container);
        LayoutInflater inflater = LayoutInflater.from(this);
        int gap = Math.round(16 * getResources().getDisplayMetrics().density);
        for (Domain domain : Domain.values()) {
            View view = inflater.inflate(R.layout.card_domain, container, false);
            ((ViewGroup.MarginLayoutParams) view.getLayoutParams()).topMargin = gap;
            container.addView(view);
            cards.put(domain, new DomainCard(view, domain, titleFor(domain), this));
        }

        observer = new ContentObserver(main) {
            @Override
            public void onChange(boolean selfChange) {
                refresh();
            }
        };
    }

    private static int titleFor(Domain domain) {
        switch (domain) {
            case GPU:
                return R.string.card_gpu_title;
            case DDR:
                return R.string.card_ddr_title;
            case CPU0:
                return R.string.card_cpu0_title;
            case CPU2:
                return R.string.card_cpu2_title;
            case CPU5:
                return R.string.card_cpu5_title;
            default:
                return R.string.card_cpu7_title;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        ContentResolver resolver = getContentResolver();
        for (Domain domain : Domain.values()) {
            String[] keys = {domain.keyTable(), domain.keyStatus(), domain.keyEnabled(), domain.keyMin(), domain.keyMax()};
            for (String key : keys) {
                resolver.registerContentObserver(Settings.Global.getUriFor(key), false, observer);
            }
        }
        String[] guardKeys = {Domain.KEY_GUARD_ENABLED, Domain.KEY_GUARD_SOC, Domain.KEY_GUARD_BATT, Domain.KEY_GUARD_TRIPPED};
        for (String key : guardKeys) {
            resolver.registerContentObserver(Settings.Global.getUriFor(key), false, observer);
        }
        String[] extraKeys = {ExtraSettings.K_TOUCH, ExtraSettings.K_BRIGHT, ExtraSettings.K_CP, ExtraSettings.K_FP_SCALE,
                ExtraSettings.K_FP_TYPE, ExtraSettings.K_FP_LOOP, ExtraSettings.K_FP_REV};
        for (String key : extraKeys) {
            resolver.registerContentObserver(Settings.Global.getUriFor(key), false, observer);
        }
        refresh();
        checkAccess();
    }

    @Override
    protected void onStop() {
        super.onStop();
        getContentResolver().unregisterContentObserver(observer);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdown();
    }

    // ---- reading state ----------------------------------------------------------------------

    private void refresh() {
        if (writesInFlight > 0) {
            return;
        }
        ContentResolver resolver = getContentResolver();
        int boot = Settings.Global.getInt(resolver, Settings.Global.BOOT_COUNT, -1);
        boolean rootReady = false;
        for (Domain domain : Domain.values()) {
            boolean loaded = bindCard(cards.get(domain), domain, resolver, boot);
            if (loaded && domain.mechanism == Domain.Mechanism.ROOT_SYSFS) {
                rootReady = true;
            }
        }
        guardCard.bind(
                Settings.Global.getInt(resolver, Domain.KEY_GUARD_ENABLED, 1) == 1,
                Settings.Global.getInt(resolver, Domain.KEY_GUARD_SOC, Domain.DEFAULT_GUARD_SOC),
                Settings.Global.getInt(resolver, Domain.KEY_GUARD_BATT, Domain.DEFAULT_GUARD_BATT),
                rootReady,
                Settings.Global.getInt(resolver, Domain.KEY_GUARD_TRIPPED, 0) == 1);
        extrasCard.bind(
                Settings.Global.getInt(resolver, ExtraSettings.K_TOUCH, 0) == 1,
                Settings.Global.getInt(resolver, ExtraSettings.K_BRIGHT, 0) == 1,
                Settings.Global.getInt(resolver, ExtraSettings.K_CP, 0) == 1,
                Settings.Global.getInt(resolver, ExtraSettings.K_FP_SCALE, 100),
                Settings.Global.getInt(resolver, Domain.KEY_GUARD_TRIPPED, 0) == 1,
                currentFingerprintType(resolver),
                Settings.Global.getInt(resolver, ExtraSettings.K_FP_LOOP, ExtraSettings.DEF_LOOP) == 1);
    }

    private static int currentFingerprintType(ContentResolver resolver) {
        int rev = Settings.Global.getInt(resolver, ExtraSettings.K_FP_REV, 0);
        int type = Settings.Global.getInt(resolver, ExtraSettings.K_FP_TYPE, -1);
        if (rev == 0) {
            return ExtraSettings.FP_NONE;
        }
        return type < 0 ? ExtraSettings.FP_PNG : type;
    }

    /** Returns true when the hook / root helper published a table during this boot. */
    private boolean bindCard(DomainCard card, Domain domain, ContentResolver resolver, int boot) {
        FreqTable.Snapshot snapshot = FreqTable.decode(Settings.Global.getString(resolver, domain.keyTable()));
        // A table from an earlier boot means the module / helper did not run this time.
        boolean loaded = snapshot != null && (boot < 0 || snapshot.bootCount == boot);
        int[] table = loaded ? snapshot.table : new int[0];
        int first = table.length > 0 ? table[0] : 0;
        int last = table.length > 0 ? table[table.length - 1] : 0;
        card.bind(
                loaded,
                table,
                Settings.Global.getString(resolver, domain.keyStatus()),
                Settings.Global.getInt(resolver, domain.keyEnabled(), 0) == 1,
                Settings.Global.getInt(resolver, domain.keyMin(), first),
                Settings.Global.getInt(resolver, domain.keyMax(), last));
        return loaded;
    }

    // ---- writing state ----------------------------------------------------------------------

    @Override
    public void onCommit(Domain domain, boolean enabled, int minValue, int maxValue) {
        // "enabled" goes last so the limit is applied once, with the final range.
        final Map<String, String> values = new LinkedHashMap<>();
        values.put(domain.keyMin(), String.valueOf(minValue));
        values.put(domain.keyMax(), String.valueOf(maxValue));
        values.put(domain.keyEnabled(), enabled ? "1" : "0");
        write(values, domain.mechanism == Domain.Mechanism.ROOT_SYSFS);
    }

    @Override
    public void onGuardCommit(boolean enabled, int socLimit, int battLimit) {
        final Map<String, String> values = new LinkedHashMap<>();
        values.put(Domain.KEY_GUARD_SOC, String.valueOf(socLimit));
        values.put(Domain.KEY_GUARD_BATT, String.valueOf(battLimit));
        values.put(Domain.KEY_GUARD_ENABLED, enabled ? "1" : "0");
        write(values, true);
    }

    // ---- extras -----------------------------------------------------------------------------

    @Override
    public void onExtraToggle(String key, boolean on) {
        write(single(key, on ? 1 : 0), false);
    }

    @Override
    public void onExtraValue(String key, int value) {
        write(single(key, value), false);
    }

    private static Map<String, String> single(String key, int value) {
        final Map<String, String> values = new LinkedHashMap<>();
        values.put(key, String.valueOf(value));
        return values;
    }

    @Override
    public void onMasterThermalRequested() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.extras_master_title)
                .setMessage(R.string.extras_master_message)
                .setNegativeButton(R.string.extras_cancel, null)
                .setPositiveButton(R.string.extras_master_confirm, (d, w) -> sendToSdhms("master", true))
                .show();
    }

    private void sendToSdhms(String command, boolean enabled) {
        Intent intent = new Intent(SdhmsExtras.ACTION).setPackage("com.sec.android.sdhms");
        intent.putExtra("cmd", command).putExtra("enabled", enabled);
        sendBroadcast(intent);
    }

    @Override
    public void onPickFingerprintIcon() {
        iconPicker.launch(new String[]{"image/*"});
    }

    @Override
    public void onPickFingerprintAnimation() {
        // file managers report .json as json, text or octet-stream; the content is validated after picking
        animPicker.launch(new String[]{"*/*"});
    }

    @Override
    public void onResetFingerprintIcon() {
        final Context app = getApplicationContext();
        new File(app.getFilesDir(), "fp_icon.png").delete();
        new File(app.getFilesDir(), "fp_anim.json").delete();
        final Map<String, String> values = new LinkedHashMap<>();
        values.put(ExtraSettings.K_FP_SCALE, "100");
        values.put(ExtraSettings.K_FP_TYPE, String.valueOf(ExtraSettings.FP_NONE));
        values.put(ExtraSettings.K_FP_REV, "0");
        write(values, false);
    }

    /** The settings that tell the hook what to show. The revision goes last: it is what the hook reacts to. */
    private static Map<String, String> iconSettings(int type) {
        final Map<String, String> values = new LinkedHashMap<>();
        values.put(ExtraSettings.K_FP_TYPE, String.valueOf(type));
        values.put(ExtraSettings.K_FP_REV, String.valueOf((int) (System.currentTimeMillis() / 1000L)));
        return values;
    }

    /** Shrinks the picked image to at most 512 px, stores it for the provider, then publishes it to the hook. */
    private void saveFingerprintIcon(Uri uri) {
        if (uri == null) {
            return;
        }
        final Context app = getApplicationContext();
        io.execute(() -> {
            boolean ok = false;
            try {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                try (InputStream in = app.getContentResolver().openInputStream(uri)) {
                    BitmapFactory.decodeStream(in, null, bounds);
                }
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = Math.max(1, Math.max(bounds.outWidth, bounds.outHeight) / 1024);
                Bitmap bitmap;
                try (InputStream in = app.getContentResolver().openInputStream(uri)) {
                    bitmap = BitmapFactory.decodeStream(in, null, opts);
                }
                if (bitmap != null) {
                    int longSide = Math.max(bitmap.getWidth(), bitmap.getHeight());
                    if (longSide > 512) {
                        float k = 512f / longSide;
                        bitmap = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth() * k),
                                Math.round(bitmap.getHeight() * k), true);
                    }
                    try (FileOutputStream out = new FileOutputStream(new File(app.getFilesDir(), "fp_icon.png"))) {
                        ok = bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                    }
                }
            } catch (Exception ignored) {
                ok = false;
            }
            if (ok) {
                new File(app.getFilesDir(), "fp_anim.json").delete();   // one custom icon at a time
            }
            final boolean saved = ok && SettingsAccess.putAll(app, iconSettings(ExtraSettings.FP_PNG));
            main.post(() -> Toast.makeText(this,
                    saved ? R.string.extras_icon_saved : R.string.extras_icon_failed, Toast.LENGTH_LONG).show());
        });
    }

    /** Checks that the picked file is a Lottie animation, stores it for the provider, then publishes it. */
    private void saveFingerprintAnimation(Uri uri) {
        if (uri == null) {
            return;
        }
        final Context app = getApplicationContext();
        io.execute(() -> {
            int message = R.string.extras_json_invalid;
            try {
                byte[] data = readAll(app, uri, 4 * 1024 * 1024);
                if (data != null && looksLikeLottie(data)) {
                    File dir = app.getFilesDir();
                    File tmp = new File(dir, "fp_anim.json.tmp");
                    try (FileOutputStream out = new FileOutputStream(tmp)) {
                        out.write(data);
                    }
                    File dst = new File(dir, "fp_anim.json");
                    if (tmp.renameTo(dst)) {
                        new File(dir, "fp_icon.png").delete();   // one custom icon at a time
                        message = SettingsAccess.putAll(app, iconSettings(ExtraSettings.FP_ANIM))
                                ? R.string.extras_anim_saved : R.string.extras_icon_failed;
                    } else {
                        message = R.string.extras_icon_failed;
                    }
                }
            } catch (Exception e) {
                message = R.string.extras_icon_failed;
            }
            final int shown = message;
            main.post(() -> Toast.makeText(this, shown, Toast.LENGTH_LONG).show());
        });
    }

    private static byte[] readAll(Context context, Uri uri, int max) throws IOException {
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) {
                return null;
            }
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) > 0) {
                bytes.write(buffer, 0, n);
                if (bytes.size() > max) {
                    return null;
                }
            }
            return bytes.toByteArray();
        }
    }

    /** A Lottie file has a frame rate, an in/out point and a layer list. */
    private static boolean looksLikeLottie(byte[] data) {
        try {
            String text = new String(data, StandardCharsets.UTF_8);
            if (text.startsWith("\uFEFF")) {
                text = text.substring(1);
            }
            JSONObject json = new JSONObject(text);
            return json.optJSONArray("layers") != null && json.has("fr") && json.has("ip") && json.has("op");
        } catch (Exception e) {
            return false;
        }
    }

    /** Saves settings, then (when the root helper reads them) pushes them to the helper. */
    private void write(final Map<String, String> values, final boolean syncRoot) {
        final Context app = getApplicationContext();
        writesInFlight++;
        io.execute(() -> {
            final boolean saved = SettingsAccess.putAll(app, values);
            if (saved && syncRoot) {
                RootControl.sync(app);
            }
            main.post(() -> {
                writesInFlight--;
                if (!saved) {
                    Toast.makeText(this, R.string.write_failed, Toast.LENGTH_LONG).show();
                }
                refresh();
                checkAccess();
            });
        });
    }

    /**
     * Makes sure the app can write settings (root grants the permission once) and that the root
     * helper script is installed and running.
     */
    private void checkAccess() {
        final Context app = getApplicationContext();
        io.execute(() -> {
            boolean granted = SettingsAccess.hasPermission(app);
            if (!granted) {
                main.post(() -> accessText.setText(R.string.access_granting));
                granted = SettingsAccess.grantViaRoot(app);
            }
            final boolean ok = granted;
            if (ok && !helperInstalled) {
                helperInstalled = RootControl.install(app);
            }
            main.post(() -> {
                if (ok) {
                    accessText.setText(helperInstalled ? R.string.access_ok : R.string.access_ok_no_helper);
                } else {
                    accessText.setText(getString(R.string.access_missing, getPackageName()));
                }
            });
        });
    }
}
