package io.github.freqctl.extras;

import android.content.Context;
import android.provider.Settings;

import io.github.freqctl.Domain;

/** Keys shared (through Settings.Global) between the app and the hooked processes. Read side only. */
public final class ExtraSettings {
    public static final String K_TOUCH    = "fcl_touch_boost";            // 0/1
    public static final String K_BRIGHT   = "fcl_thermal_brightness_off"; // 0/1
    public static final String K_CP       = "fcl_thermal_cp_off";         // 0/1
    public static final String K_MASTER   = "fcl_thermal_master_off";     // 0/1 (app-side mirror of SDHMS master switch)
    public static final String K_STATUS   = "fcl_sdhms_status";           // written by the SDHMS hook: key=value;key=value
    public static final String K_FP_SCALE = "fcl_fp_scale";               // percent, 50..200
    public static final String K_FP_REV   = "fcl_fp_rev";                 // changes when the custom icon changes, 0 = none
    public static final String K_FP_TYPE  = "fcl_fp_type";                // FP_NONE / FP_PNG / FP_ANIM
    public static final String K_FP_LOOP  = "fcl_fp_loop";                // 0/1: repeat the custom animation (default 1)
    public static final String K_GUARD    = Domain.KEY_GUARD_TRIPPED;     // written by freqctl.sh
    public static final String K_GOS_CAPS   = "fcl_gos_block_caps";       // 0/1: GOS may not set CPU/GPU/bus maximums (engine keeps running)
    public static final String K_GOS_IPM    = "fcl_gos_block_ipm";        // 0/1: GOS may not start its IPM/SPA engine at all
    public static final String K_GOS_LEVELS = "fcl_gos_block_levels";     // 0/1: GOS ignores game CPU/GPU levels
    public static final String K_GOS_DEBUG  = "fcl_gos_debug";            // 0/1: log what GOS asks for (LSPosed log, tag FreqCtl/GOS)

    public static final int FP_NONE = 0;   // Samsung's own icon
    public static final int FP_PNG  = 1;   // custom PNG
    public static final int FP_ANIM = 2;   // custom Lottie JSON
    public static final int DEF_LOOP = 1;

    private ExtraSettings() {
    }

    public static int get(Context c, String key, int def) {
        try {
            return Settings.Global.getInt(c.getContentResolver(), key, def);
        } catch (Throwable t) {
            return def;
        }
    }
}
