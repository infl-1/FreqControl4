package io.github.freqctl.extras;

import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ColorFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.ViewParent;
import android.widget.ImageView;

import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Runs inside com.samsung.android.biometrics.app.setting (the under-display fingerprint UI).
 * Same hook points as the Chinese module (Lottie setAnimation/setProgress, ImageView setImageResource/setColorFilter,
 * asset / resource names copied from it), re-implemented in source, plus a NEW icon size (50-200 %).
 */
public final class FingerprintExtras {
    public static final String PKG = "com.samsung.android.biometrics.app.setting";
    private static final String TAG = "FreqCtl/FP: ";
    private static final String CUSTOM = "fcl_custom";
    private static final Uri PNG = Uri.parse("content://io.github.freqctl.extra/png");
    private static final Uri ANIM = Uri.parse("content://io.github.freqctl.extra/animation");

    private static final String[] ASSETS = {"ic_fingerprint_prompt.json", "ic_fingerprint_aod.json",
            "ic_fingerprint_dark_theme.json", "ic_fingerprint_dark_theme_non_alpha.json",
            "ic_fingerprint_light_theme.json", "ic_fingerprint_light_theme_non_alpha.json",
            "prompt_btn_fingerprint.json"};
    private static final String[] RES = {"sem_fingerprint_icon_bg_white", "sem_fingerprint_icon_bg_black",
            "sem_fingerprint_icon_bg", "sem_biometric_prompt_dialog_fingerprint"};

    private static final List<WeakReference<View>> tracked = new ArrayList<>();
    private static boolean observing;
    private static long cachedRev = -1;
    private static Bitmap cachedBitmap;
    private static byte[] cachedAnim;

    private FingerprintExtras() {}

    public static void install(ClassLoader cl) {
        try {
            Class<?> lottie = XposedHelpers.findClass("com.airbnb.lottie.LottieAnimationView", cl);
            XposedBridge.hookAllMethods(lottie, "setAnimation", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (p.args.length == 1 && p.args[0] instanceof String && isAsset((String) p.args[0])) {
                        View v = (View) p.thisObject;
                        track(v);
                        replaceAnimation(v);
                        scale(v);
                    }
                }
            });
            XposedBridge.hookAllMethods(lottie, "setProgress", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    View v = (View) p.thisObject;
                    if (isTracked(v)) scale(v);
                }
            });
            XposedBridge.hookAllMethods(ImageView.class, "setImageResource", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    ImageView v = (ImageView) p.thisObject;
                    String n = resName(v.getContext(), (Integer) p.args[0]);
                    if (isRes(n)) { track(v); replacePng(v); scale(v); }
                }
            });
            XposedBridge.hookAllMethods(ImageView.class, "setColorFilter", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    // keep the user's PNG un-tinted
                    if (Boolean.TRUE.equals(XposedHelpers.getAdditionalInstanceField(p.thisObject, CUSTOM)))
                        if (p.args.length > 0 && p.args[0] instanceof ColorFilter) p.setResult(null);
                }
            });
            XposedBridge.log(TAG + "hooks installed");
        } catch (Throwable t) { XposedBridge.log(TAG + "install failed: " + t); }
    }

    // ------------------------------------------------------------ matching
    private static boolean isAsset(String s) { for (String a : ASSETS) if (a.equals(s)) return true; return false; }
    private static boolean isRes(String s) { for (String r : RES) if (r.equals(s)) return true; return false; }
    private static String resName(Context c, int id) {
        try { return c.getResources().getResourceEntryName(id); } catch (Throwable t) { return ""; }
    }

    // ------------------------------------------------------------ tracking / scaling
    private static synchronized void track(final View v) {
        if (!isTracked(v)) tracked.add(new WeakReference<>(v));
        if (!observing) {
            observing = true;
            Handler h = new Handler(Looper.getMainLooper());
            ContentResolver cr = v.getContext().getContentResolver();
            ContentObserver o = new ContentObserver(h) {
                @Override public void onChange(boolean s) { refreshAll(); }
            };
            cr.registerContentObserver(Settings.Global.getUriFor(ExtraSettings.K_FP_SCALE), false, o);
            cr.registerContentObserver(Settings.Global.getUriFor(ExtraSettings.K_FP_REV), false, o);
        }
    }

    private static synchronized boolean isTracked(View v) {
        for (WeakReference<View> r : tracked) if (r.get() == v) return true;
        return false;
    }

    private static synchronized void refreshAll() {
        for (WeakReference<View> r : tracked) {
            View v = r.get();
            if (v == null) continue;
            if (v instanceof ImageView) replacePng((ImageView) v); else replaceAnimation(v);
            scale(v);
        }
    }

    private static void scale(View v) {
        int pct = Math.max(50, Math.min(200, ExtraSettings.get(v.getContext(), ExtraSettings.K_FP_SCALE, 100)));
        float s = pct / 100f;
        v.setPivotX(v.getWidth() / 2f);
        v.setPivotY(v.getHeight() / 2f);
        v.setScaleX(s);
        v.setScaleY(s);
        // let the enlarged icon draw outside its parent bounds
        ViewParent p = v.getParent();
        for (int i = 0; i < 3 && p instanceof android.view.ViewGroup; i++) {
            ((android.view.ViewGroup) p).setClipChildren(false);
            ((android.view.ViewGroup) p).setClipToPadding(false);
            p = p.getParent();
        }
    }

    // ------------------------------------------------------------ custom icon (optional)
    private static void loadCache(Context c) {
        long rev = ExtraSettings.get(c, ExtraSettings.K_FP_REV, 0);
        if (rev == cachedRev) return;
        cachedRev = rev; cachedBitmap = null; cachedAnim = null;
        if (rev == 0) return;
        ContentResolver cr = c.getContentResolver();
        try (InputStream in = cr.openInputStream(PNG)) { if (in != null) cachedBitmap = BitmapFactory.decodeStream(in); }
        catch (Throwable ignore) {}
        try (InputStream in = cr.openInputStream(ANIM)) {
            if (in != null) {
                java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
                cachedAnim = b.toByteArray();
            }
        } catch (Throwable ignore) {}
    }

    private static void replacePng(ImageView v) {
        loadCache(v.getContext());
        if (cachedBitmap == null) return;
        XposedHelpers.setAdditionalInstanceField(v, CUSTOM, Boolean.TRUE);
        v.clearColorFilter();
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        v.setImageBitmap(cachedBitmap);
    }

    private static void replaceAnimation(View v) {
        loadCache(v.getContext());
        if (cachedAnim == null) return;
        try {
            XposedHelpers.callMethod(v, "setAnimation",
                    new java.io.ByteArrayInputStream(cachedAnim), "fcl_fingerprint_icon_" + cachedRev);
            XposedHelpers.setAdditionalInstanceField(v, CUSTOM, Boolean.TRUE);
        } catch (Throwable t) { XposedBridge.log(TAG + "animation replace failed: " + t); }
    }
}
