package io.github.freqctl.extras;

import android.content.Context;
import android.provider.Settings;

import io.github.freqctl.Domain;

/** Keys shared (through Settings.Global) between the app and the hooked processes. Read side only. */
public final class ExtraSettings {
    public static final String K_TOUCH    = "fcl_touch_boost";            // 0/1
    public static final String K_BRIGHT   = "fcl_thermal_brightness_off"; // 0/1
    public static final String K_CP       = "fcl_thermal_cp_off";         // 0/1
    public static final String K_FP_SCALE = "fcl_fp_scale";               // percent, 50..200
    public static final String K_FP_REV   = "fcl_fp_rev";                 // changes when the custom icon changes, 0 = none
    public static final String K_GUARD    = Domain.KEY_GUARD_TRIPPED;     // written by freqctl.sh

    private ExtraSettings() {
    }

    public static int get(Context c, String key, int def) {
        try {
            return Settings.Global.getInt(c.getContentResolver(), key, def);
        } catch (Throwable t) {
            return def;
        }
    }
}
