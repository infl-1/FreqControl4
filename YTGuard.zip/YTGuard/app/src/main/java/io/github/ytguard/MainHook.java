package io.github.ytguard;

import android.content.Context;
import android.content.pm.PackageInfo;

import java.util.List;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * YouTube-only LSPosed module.
 *
 * Features that exist so far (each one was located by analysing the stock
 * YouTube 21.41.526 dex files, see tools/ and COMPAT_REPORT.md):
 *   1. Hide the "Get Premium" upsell view.
 *   2. Block the video-ad trigger handler.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String YOUTUBE = "com.google.android.youtube";

    /** Obfuscated names below are only valid for this exact build. */
    private static final String VERIFIED_VERSION = "21.41.526";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!YOUTUBE.equals(lp.packageName)) return;

        ClassLoader cl = lp.classLoader;
        String version = versionOf(lp.packageName);
        log("YouTube version = " + version);

        run("hide-get-premium", () -> hideGetPremium(cl));

        if (VERIFIED_VERSION.equals(version)) {
            run("block-video-ads", () -> blockVideoAds(cl));
        } else {
            log("block-video-ads skipped: obfuscated names are only verified for " + VERIFIED_VERSION);
        }
    }

    /** CompactYpcOfferModuleView is not obfuscated, so this hook is version-independent. */
    private static void hideGetPremium(ClassLoader cl) {
        XposedHelpers.findAndHookMethod(
                "com.google.android.apps.youtube.app.red.presenter.CompactYpcOfferModuleView",
                cl, "onMeasure", int.class, int.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        XposedHelpers.callMethod(param.thisObject, "setMeasuredDimension", 0, 0);
                    }
                });
    }

    /**
     * acve.t(List) is the ad slot trigger handler. It is the method that contains the strings
     * "TriggerBundle doesn't have the required metadata ..." and "Ping migration no associated ...".
     * Turning it into a no-op stops video ad slots from being entered.
     */
    private static void blockVideoAds(ClassLoader cl) {
        XposedHelpers.findAndHookMethod("acve", cl, "t", List.class, XC_MethodReplacement.DO_NOTHING);
    }

    // ------------------------------------------------------------------

    private interface Task { void run() throws Throwable; }

    private static void run(String name, Task task) {
        try {
            task.run();
            log(name + ": hooked");
        } catch (Throwable t) {
            log(name + ": FAILED -> " + t);
        }
    }

    private static String versionOf(String pkg) {
        try {
            Object at = XposedHelpers.callStaticMethod(
                    XposedHelpers.findClass("android.app.ActivityThread", null), "currentActivityThread");
            Context ctx = (Context) XposedHelpers.callMethod(at, "getSystemContext");
            PackageInfo pi = ctx.getPackageManager().getPackageInfo(pkg, 0);
            return pi.versionName;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void log(String msg) {
        XposedBridge.log("[YTGuard] " + msg);
    }
}
