plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.speedtool"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.speedtool"
        minSdk = 24
        targetSdk = 34
        versionCode = 5
        versionName = "1.4"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    // frida-inject.xz مضغوط أصلاً: نخزّنه كما هو بدون ضغط إضافي
    androidResources { noCompress += "xz" }
}
dependencies {
    implementation("org.tukaani:xz:1.9")   // فك ضغط frida-inject.xz
}
