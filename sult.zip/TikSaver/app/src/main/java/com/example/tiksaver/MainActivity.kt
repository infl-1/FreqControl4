package com.example.tiksaver

import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var linkInput: EditText
    private lateinit var downloadBtn: Button
    private lateinit var updateBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    private var ready = false
    private val cookies = mutableMapOf<String, String>()
    private var lastResolvedUrl: String? = null
    private var photoDebug: String = ""
    private val USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val urlRegex = Regex("""https?://\S+""")
    private val videoExtensions = setOf("mp4", "mkv", "webm", "mov")
    private val supportedDomains = listOf(
        "tiktok.com",
        "snapchat.com",
        "x.com", "twitter.com", "t.co",
        "youtube.com", "youtu.be"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        linkInput = findViewById(R.id.linkInput)
        downloadBtn = findViewById(R.id.downloadBtn)
        updateBtn = findViewById(R.id.updateBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.pasteBtn).setOnClickListener { pasteFromClipboard() }
        downloadBtn.setOnClickListener { startDownload() }
        updateBtn.setOnClickListener { updateEngine() }

        handleShareIntent(intent)
        initEngine()
    }

    // لو التطبيق مفتوح وجاء رابط جديد من "مشاركة" ما نفتح نسخة ثانية، نستخدم نفس الشاشة
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    private fun handleShareIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT))?.let { linkInput.setText(it) }
        }
    }

    // ---------- المحرك ----------

    private fun initEngine() {
        busy(true)
        status.text = "جاري تجهيز المحرك (أول مرة فقط، ممكن ياخذ شوي)..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().init(applicationContext)
                    FFmpeg.getInstance().init(applicationContext)
                }
                ready = true
                status.text = "جاهز ✅"
            } catch (e: Exception) {
                status.text = "تعذر تجهيز المحرك: ${e.message}"
            } finally {
                busy(false)
            }
        }
    }

    private fun updateEngine() {
        busy(true)
        status.text = "جاري تحديث المحرك..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().updateYoutubeDL(applicationContext, YoutubeDL.UpdateChannel.STABLE)
                }
                status.text = "تم تحديث المحرك ✅"
            } catch (e: Exception) {
                status.text = "فشل التحديث، تأكد من الإنترنت"
            } finally {
                busy(false)
            }
        }
    }

    // ---------- التحميل ----------

    private fun startDownload() {
        val url = extractUrl(linkInput.text.toString())
        if (url == null || !isSupported(url)) {
            status.text = "الرابط غير مدعوم. المدعوم: تيك توك، سناب شات، X، يوتيوب"
            return
        }
        linkInput.setText(url)
        busy(true, determinate = true)
        status.text = "جاري التحميل..."
        lastResolvedUrl = null

        lifecycleScope.launch {
            try {
                // تيك توك: نفحص أول إذا كان البوست صور (سلايد شو)
                val photoPost = if (isTikTok(url)) {
                    withContext(Dispatchers.IO) { findPhotoPost(url) }
                } else null

                if (photoPost != null) {
                    val saved = withContext(Dispatchers.IO) { downloadPhotoPost(photoPost) }
                    status.text = "تم حفظ $saved صور في المعرض (Pictures/TikSaver) ✅"
                } else {
                    val file = downloadVideo(url)
                    withContext(Dispatchers.IO) {
                        saveToGallery(file)
                        file.delete()
                    }
                    status.text = "تم الحفظ في المعرض (Movies/TikSaver) ✅"
                }
            } catch (e: Exception) {
                val reason = e.message?.lineSequence()?.firstOrNull { it.isNotBlank() }?.take(160) ?: e.javaClass.simpleName
                val head = if (lastResolvedUrl?.contains("/photo/") == true) {
                    "هذا بوست صور وما قدرت أحمّله."
                } else {
                    "فشل التحميل. تأكد من الرابط، أو اضغط «تحديث المحرك» وحاول مرة ثانية."
                }
                val photoLine = if (photoDebug.isNotEmpty()) "\n[صور] $photoDebug" else ""
                status.text = "$head$photoLine\n[تفاصيل] $reason"
            } finally {
                busy(false)
            }
        }
    }

    private suspend fun downloadVideo(url: String): File = withContext(Dispatchers.IO) {
        val dir = File(cacheDir, "dl").apply {
            deleteRecursively()
            mkdirs()
        }
        val request = YoutubeDLRequest(url)
        request.addOption("-o", "${dir.absolutePath}/%(id)s.%(ext)s")
        request.addOption("-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b") // أعلى جودة
        request.addOption("--merge-output-format", "mp4")
        request.addOption("--no-playlist")

        YoutubeDL.getInstance().execute(request, "tiktok-download") { p, _, _ ->
            runOnUiThread { progress.progress = p.toInt().coerceIn(0, 100) }
        }

        dir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in videoExtensions }
            ?.maxByOrNull { it.length() }
            ?: throw IOException("لم يتم العثور على الملف")
    }

    private fun saveToGallery(file: File) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "video_${System.currentTimeMillis()}.${file.extension}")
            put(MediaStore.Video.Media.MIME_TYPE, mimeFor(file.extension))
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TikSaver")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri: Uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("تعذر إنشاء الملف في المعرض")

        resolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        } ?: throw IOException("تعذر الكتابة في المعرض")

        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
    }

    // ---------- بوستات الصور (تيك توك) ----------

    private class PhotoPost(val id: String, val imageUrls: List<String>)

    private class HttpResult(val body: ByteArray, val finalUrl: String)

    /**
     * يفتح صفحة البوست ويقرأ بياناتها ويدور على imagePost.
     * يرجع null إذا كان البوست فيديو عادي أو تعذر قراءة الصفحة (والسبب يتسجل في photoDebug)،
     * وبعدها يكمل التحميل بـ yt-dlp.
     */
    private fun findPhotoPost(url: String): PhotoPost? {
        lastResolvedUrl = null
        photoDebug = ""
        return try {
            cookies.clear()
            val page = httpGet(url, referer = null)
            lastResolvedUrl = page.finalUrl
            val html = String(page.body, Charsets.UTF_8)

            val data = extractPageData(html)
            var item: JSONObject? = data?.let { findItemWithImages(it) }
            if (item == null) {
                // محاولة ثانية: نقتطع كائن imagePost مباشرة من نص الصفحة
                val post = extractJsonObjectAfter(html, "\"imagePost\":")
                if (post != null && (post.optJSONArray("images")?.length() ?: 0) > 0) {
                    item = JSONObject().put("imagePost", post)
                }
            }
            if (item == null) {
                photoDebug = when {
                    html.contains("captcha", ignoreCase = true) -> "تيك توك طلب كابتشا"
                    data == null -> "الصفحة بدون بيانات (حجمها ${html.length})"
                    else -> "ما فيه صور بالبوست (فيديو عادي؟)"
                }
                return null
            }

            val images = item.getJSONObject("imagePost").getJSONArray("images")
            val urls = ArrayList<String>()
            for (i in 0 until images.length()) {
                val img = images.optJSONObject(i) ?: continue
                val list = img.optJSONObject("imageURL")?.optJSONArray("urlList")
                    ?: img.optJSONObject("displayImage")?.optJSONArray("urlList")
                    ?: continue
                val candidates = (0 until list.length()).map { list.getString(it) }
                val pick = candidates.firstOrNull { it.contains(".jpeg") || it.contains(".jpg") }
                    ?: candidates.firstOrNull()
                    ?: continue
                urls.add(pick)
            }
            if (urls.isEmpty()) {
                photoDebug = "لقيت imagePost بدون روابط صور"
                null
            } else {
                photoDebug = "ok"
                PhotoPost(item.optString("id", page.finalUrl.substringAfterLast('/').substringBefore('?')), urls)
            }
        } catch (e: Exception) {
            photoDebug = "تعذر فتح الصفحة: ${e.message}"
            null
        }
    }

    /** يقرأ كتلة JSON من الصفحة (التسميات المعروفة لتيك توك) */
    private fun extractPageData(html: String): JSONObject? {
        for (id in listOf("__UNIVERSAL_DATA_FOR_REHYDRATION__", "SIGI_STATE", "__NEXT_DATA__")) {
            val marker = html.indexOf("id=\"$id\"")
            if (marker < 0) continue
            val start = html.indexOf('>', marker) + 1
            val end = html.indexOf("</script>", start)
            if (start <= 0 || end < 0) continue
            try {
                return JSONObject(html.substring(start, end))
            } catch (e: Exception) {
                // نجرب التالي
            }
        }
        return null
    }

    /** يطلع أول كائن JSON يجي بعد النص المعطى (مع تجاهل الأقواس داخل النصوص) */
    private fun extractJsonObjectAfter(text: String, key: String): JSONObject? {
        val at = text.indexOf(key)
        if (at < 0) return null
        val begin = text.indexOf('{', at + key.length)
        if (begin < 0) return null
        var depth = 0
        var inString = false
        var escaped = false
        var i = begin
        while (i < text.length) {
            val c = text[i]
            if (inString) {
                if (escaped) escaped = false
                else if (c == '\\') escaped = true
                else if (c == '"') inString = false
            } else {
                when (c) {
                    '"' -> inString = true
                    '{' -> depth++
                    '}' -> {
                        depth--
                        if (depth == 0) {
                            return try { JSONObject(text.substring(begin, i + 1)) } catch (e: Exception) { null }
                        }
                    }
                }
            }
            i++
        }
        return null
    }

    /** يدور بشكل متداخل على الكائن اللي فيه imagePost.images */
    private fun findItemWithImages(node: Any?): JSONObject? {
        when (node) {
            is JSONObject -> {
                val images = node.optJSONObject("imagePost")?.optJSONArray("images")
                if (images != null && images.length() > 0) return node
                val keys = node.keys()
                while (keys.hasNext()) {
                    val found = findItemWithImages(node.opt(keys.next()))
                    if (found != null) return found
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    val found = findItemWithImages(node.opt(i))
                    if (found != null) return found
                }
            }
        }
        return null
    }

    private fun downloadPhotoPost(post: PhotoPost): Int {
        var saved = 0
        post.imageUrls.forEachIndexed { index, imageUrl ->
            val result = httpGet(imageUrl, referer = "https://www.tiktok.com/")
            val ext = imageExtension(imageUrl)
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "tiktok_${post.id}_${"%02d".format(index + 1)}.$ext")
                put(MediaStore.Images.Media.MIME_TYPE, imageMime(ext))
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TikSaver")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = contentResolver
            val uri: Uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("تعذر إنشاء الملف في المعرض")
            resolver.openOutputStream(uri)?.use { it.write(result.body) }
                ?: throw IOException("تعذر الكتابة في المعرض")
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            saved++

            val percent = (saved * 100) / post.imageUrls.size
            runOnUiThread { progress.progress = percent }
        }
        return saved
    }

    private fun imageExtension(url: String): String {
        val path = Uri.parse(url).path ?: return "jpg"
        val ext = path.substringAfterLast('.', "jpg").lowercase()
        return when {
            ext == "jpeg" -> "jpg"
            ext.length in 2..4 -> ext
            else -> "jpg"
        }
    }

    private fun imageMime(ext: String): String = when (ext) {
        "webp" -> "image/webp"
        "png" -> "image/png"
        "heic" -> "image/heic"
        else -> "image/jpeg"
    }

    /** GET بسيط مع تتبع التحويلات وحفظ الكوكيز بين الطلبات */
    private fun httpGet(startUrl: String, referer: String?): HttpResult {
        var current = startUrl
        repeat(10) {
            val conn = URL(current).openConnection() as HttpURLConnection
            try {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.setRequestProperty("User-Agent", USER_AGENT)
                conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                if (referer != null) conn.setRequestProperty("Referer", referer)
                if (cookies.isNotEmpty()) {
                    conn.setRequestProperty("Cookie", cookies.entries.joinToString("; ") { "${it.key}=${it.value}" })
                }

                val code = conn.responseCode
                conn.headerFields
                    .filterKeys { it?.equals("set-cookie", ignoreCase = true) == true }
                    .values.flatten()
                    .forEach { header ->
                        val pair = header.substringBefore(';')
                        val name = pair.substringBefore('=').trim()
                        if (name.isNotEmpty()) cookies[name] = pair.substringAfter('=', "")
                    }

                if (code in 300..399) {
                    val location = conn.getHeaderField("Location") ?: throw IOException("redirect without location")
                    current = URL(URL(current), location).toString()
                } else {
                    if (code !in 200..299) throw IOException("HTTP $code")
                    return HttpResult(conn.inputStream.use { it.readBytes() }, current)
                }
            } finally {
                conn.disconnect()
            }
        }
        throw IOException("too many redirects")
    }

    private fun isTikTok(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        return host == "tiktok.com" || host.endsWith(".tiktok.com")
    }

    // ---------- أدوات مساعدة ----------

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString()
        val url = extractUrl(text)
        if (url != null) linkInput.setText(url) else status.text = "ما لقيت رابط في الحافظة"
    }

    private fun extractUrl(text: String?): String? = text?.let { urlRegex.find(it)?.value }

    private fun isSupported(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        return supportedDomains.any { host == it || host.endsWith(".$it") }
    }

    private fun mimeFor(ext: String): String = when (ext.lowercase()) {
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        else -> "video/mp4"
    }

    private fun busy(on: Boolean, determinate: Boolean = false) {
        progress.visibility = if (on) View.VISIBLE else View.GONE
        progress.isIndeterminate = !determinate
        progress.progress = 0
        downloadBtn.isEnabled = !on && ready
        updateBtn.isEnabled = !on
    }
}
