package com.example.tiksaver

enum class Quality(
    val label: String,
    val height: Int? = null,
    val audioOnly: Boolean = false
) {
    ORIGINAL("الأصلية (أعلى جودة)"),
    P2160("2160p (4K)", 2160),
    P1440("1440p (2K)", 1440),
    P1080("1080p", 1080),
    P720("720p", 720),
    P480("480p", 480),
    P360("360p", 360),
    P240("240p", 240),
    P144("144p", 144),
    AUDIO("صوت فقط (MP3)", null, true);

    fun formatSelector(): String = when {
        audioOnly -> "ba/b"
        height == null -> "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b"
        else -> "bv*[height<=$height][ext=mp4]+ba[ext=m4a]/b[height<=$height][ext=mp4]/bv*[height<=$height]+ba/b[height<=$height]/b"
    }
}
