
# ===== MOD: fps + quality options (injected by apply_mod.py) =====
.field private mModFpsPref:Landroidx/preference/DropDownPreference;
.field private mModReady:Z
